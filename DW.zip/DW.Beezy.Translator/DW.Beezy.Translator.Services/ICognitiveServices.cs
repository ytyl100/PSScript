﻿using DW.Beezy.Translator.Common.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DW.Beezy.Translator.Services
{
    interface ICognitiveServices
    {
        Task<List<Translations>> TranslateNew(string text, string sourceLanguageCode, string targetLanguageCode);
        Task<string> Translate(string text, string sourceLanguageCode, string targetLanguageCode);
    }
}
