﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace DW.Beezy.Translator.Common.Models
{
    public class Translations
    {
        [JsonProperty("translations")]
        public List<Translation> Items { get; set; }
    }
}
