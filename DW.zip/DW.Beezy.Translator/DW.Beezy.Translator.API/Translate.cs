using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Microsoft.Extensions.Configuration;
using System.Net.Http;
using System.Text;
using DW.Beezy.Translator.Services;
using DW.Beezy.Translator.Common.Models;
using System.Collections.Generic;

namespace DW.Beezy.Translator.API
{
    public static class Translate
    {
        [FunctionName("Translate")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            try
            {
                var configurationSettigs = new ConfigurationBuilder()
                    .AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
                    .AddEnvironmentVariables()
                    .Build();

                var subscriptionKey = configurationSettigs["ATS_SUBSCRIPTION_KEY"];
                var endpoint = configurationSettigs["ATS_ENDPOINT"];
                var location = configurationSettigs["ATS_LOCATION"];


                CognitiveServices s = new CognitiveServices(subscriptionKey, endpoint, location);

                //List<Translations> res = await s.Translate("Hello World", "en", "de");

                string res = await s.Translate("Hello World", "en", "de");
                return new OkObjectResult(res);
            }
            catch (Exception ex)
            {
                log.LogError(ex.ToString());
                return new OkObjectResult(ex.ToString());
            }

            //var configurationSettigs = new ConfigurationBuilder()
            //    .AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
            //    .AddEnvironmentVariables()
            //    .Build();

            //var subscriptionKey = configurationSettigs["ATS_SUBSCRIPTION_KEY"];
            //var endpoint = configurationSettigs["ATS_ENDPOINT"];
            //var location = configurationSettigs["ATS_LOCATION"];


            //CognitiveServices s = new CognitiveServices(subscriptionKey, endpoint, location);

            ////List<Translations> res = await s.Translate("Hello World", "en", "de");

            //string res = await s.Translate("Hello World", "en", "de");


            //if(res == null)
            //{
            //    return new OkObjectResult("is null");
            //}

            //if(res.Count == 0)
            //{
            //    return new OkObjectResult("res is 0");
            //}

            //if(res[0].Items == null)
            //{
            //    return new OkObjectResult("items is null");
            //}

            //if(res[0].Items.Count == 0)
            //{
            //    return new OkObjectResult("items is 0");
            //}

            //return new OkObjectResult(res[0].Items[0].Text);
        }
    }
}
