Install-Module PnP.PowerShell -AllowPrerelease -Scope "CurrentUser" -Verbose -AllowClobber -Force
            
# Test by getting site name
Connect-PnPOnline -Url https://dwdev365.sharepoint.com/sites/beezy -ClientId $(clientId) -Tenant $(tenantId) -CertificateBase64Encoded $(SPFxDevOpsPipeline)      
$web = Get-PnPWeb
Write-Host "Site title: $($web.Title)"
            
# Deploy & Publish the SPFx package
Connect-PnPOnline -Url https://dwdev365.sharepoint.com -ClientId $(clientId) -Tenant $(tenantId) -CertificateBase64Encoded $(SPFxDevOpsPipeline)      
Write-Host "Package: $(spfxpackagename)"      
Add-PnPApp -Path "$(System.DefaultWorkingDirectory)/_DW.Tasks.SPO.Dashboard_SPFx/drop/$(spfxpackagename)" -Overwrite -Publish