import { Guid } from "@microsoft/sp-core-library";

export interface ITaskUpdateIdentifier{
    id: Guid;
    upn: string;
    status: number;
}