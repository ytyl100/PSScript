/// <reference types="jest" />

import * as React from "react";
import { configure, mount, ReactWrapper } from "enzyme";
import * as Adapter from "enzyme-adapter-react-16";

configure({ adapter: new Adapter() });

import TestComponent from "./TestComponent";
import { ITestComponentProps } from "./ITestComponentProps";
import { ITestComponentState } from "./ITestComponentState";

describe("Test Component", () => {
  let name: string;

  let testComponentWrapper: ReactWrapper<
    ITestComponentProps,
    ITestComponentState
  >;

  beforeEach(() => {
    name = "Test Name";

    testComponentWrapper = mount(
      React.createElement(TestComponent, { name: name })
    );
  });

  afterEach(() => {
    testComponentWrapper.unmount();
  });

  test(`should render correct name`, () => {
    let element = testComponentWrapper.find("h1").first();
    expect(element.text()).toBe(name);
  });

});
