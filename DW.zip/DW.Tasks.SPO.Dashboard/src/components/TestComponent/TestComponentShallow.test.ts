/// <reference types="jest" />

import * as React from "react";
import { configure, shallow, ShallowWrapper } from "enzyme";
import * as Adapter from "enzyme-adapter-react-16";
import { ITestComponentProps } from "./ITestComponentProps";
import { ITestComponentState } from "./ITestComponentState";
import TestComponent from "./TestComponent";

configure({ adapter: new Adapter() });

describe("Shallow Test", () => {
  let reactComponent: ShallowWrapper<ITestComponentProps, ITestComponentState>;

  beforeEach(() => {
    reactComponent = shallow(
      React.createElement(TestComponent, { name: "Test Test" })
    );
  });

  afterEach(()=>{
      reactComponent.unmount();
  });

  test('shallow test 123', ()=>{
      reactComponent.setState({counter: 1000});

      const instance = reactComponent.instance() as TestComponent;
      
      expect(instance.isEvenNumber()).toBeTruthy();
  });
});
