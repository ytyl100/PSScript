import * as React from "react";
import { ITestComponentProps } from "./ITestComponentProps";
import { ITestComponentState } from "./ITestComponentState";

class TestComponent extends React.Component<
  ITestComponentProps,
  ITestComponentState
> {
  constructor(props: ITestComponentProps) {
    super(props);
    this.state = { counter: 0 };
  }


  public isEvenNumber():boolean{
    return this.state.counter % 2 == 0;
  }



  public render() {
    return (
      <>
        <h1 id="header">{this.props.name}</h1>
        <div id="counter">{this.state.counter}</div>
      </>
    );
  }
}

export default TestComponent;
