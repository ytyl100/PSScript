export interface ITestComponentProps {
    name:string;
}