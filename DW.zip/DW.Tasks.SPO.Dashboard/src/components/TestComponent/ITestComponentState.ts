export interface ITestComponentState {
  counter:number;
}