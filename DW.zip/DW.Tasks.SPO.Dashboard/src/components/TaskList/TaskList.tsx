import {
  DetailsList,
  DetailsListLayoutMode,
  IColumn,
  SelectionMode,
} from "office-ui-fabric-react";
import * as React from "react";
import { Link } from "react-router-dom";
import { useEffect } from "react";
import { ITaskInfo } from "../../models";
import { DateToStringRenderer, TaskStatusRenderer } from "../../utils";


export interface ITaskListProps {
  tasks: ITaskInfo[];
}

const generateColumns = (): IColumn[] => {
  return [
    {
      key: "taskNumber",
      name: "Task No",
      fieldName: "taskNumber",
      minWidth: 80,
      maxWidth: 90,
    },
    {
      key: "title",
      name: "Title",
      fieldName: "title",
      minWidth: 120,
    },
    {
      key: "createdBy",
      name: "Created By",
      fieldName: "createdBy.userName",
      minWidth: 100,
      maxWidth: 100,
      onRender: (itm: ITaskInfo) => {
        return itm.createdBy.userName;
      },
    },
    {
      key: "region",
      name: "Region",
      fieldName: "region",
      minWidth: 80,
      maxWidth: 100,
    },
    {
      key: "dueDate",
      name: "Due Date",
      fieldName: "dueDate",
      minWidth: 100,
      maxWidth: 100,
      onRender: (itm: ITaskInfo) => {
        return DateToStringRenderer(itm.dueDate);
      },
    },
    {
      key: "status",
      name: "Status",
      fieldName: "status",
      minWidth: 50,
      maxWidth: 50,
      onRender: (itm: ITaskInfo) => {
        return TaskStatusRenderer(itm.status);
      },
    },
  ];
};

const itemColumnRenderer = (
  item: ITaskInfo,
  index: number,
  column: IColumn
) => {
  const fieldContent = item[column.fieldName as keyof ITaskInfo] as string;

  switch (column.key) {
    case "taskNumber":
      return (
        <Link to={`/tasks/${item.id}/view`}>
          {fieldContent}
        </Link>
      );
    default:
      return <span>{fieldContent}</span>;
  }
};

export const TaskList = (props: ITaskListProps) => {
  useEffect(() => {
    console.warn("TaskList useEffect props:", props);
  }, []);

  const columns = generateColumns();

  return (
    <div className="ms-Grid" dir="ltr">
      <div className="ms-Grid-row">
        <div className="ms-Grid-col ms-sm12">
          <DetailsList
            items={props.tasks}
            columns={columns}
            onRenderItemColumn={itemColumnRenderer}
            layoutMode={DetailsListLayoutMode.justified}
            selectionMode={SelectionMode.none}
          ></DetailsList>
        </div>
      </div>
    </div>
  );
};
