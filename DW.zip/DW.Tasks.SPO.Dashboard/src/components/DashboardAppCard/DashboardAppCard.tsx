import * as React from "react";
import {
  DocumentCard,
  DocumentCardTitle,
  DocumentCardDetails,
  DocumentCardImage,
  IDocumentCardStyles,
  DocumentCardActions,
} from "office-ui-fabric-react/lib/DocumentCard";
import { IIconProps } from "office-ui-fabric-react/lib/Icon";
import { ImageFit } from "office-ui-fabric-react/lib/Image";
import { IDashboardAppCardProps } from "..";

export const DashboardAppCard: React.FunctionComponent<IDashboardAppCardProps> = ({app,numberOfTasks}:IDashboardAppCardProps) => {

  const oneNoteIconProps: IIconProps = {
    iconName: app.iconName,
    styles: {
      root: { color: "#DB0011", fontSize: "40px", width: "40px", height: "40px" },
    },
  };
  

  const cardStyles: IDocumentCardStyles = {
    root: {
      display: "inline-block",
      marginBottom: 20,
      width: "100%",
      maxWidth: "100%",
      minWidth: "100%",
    },
  };

  const onActionClick = (action: string, ev: React.SyntheticEvent<HTMLElement>): void => {
    console.log(`You clicked the ${action} action`);
    ev.stopPropagation();
    ev.preventDefault();
  };
  const documentCardActions = [
    {
      iconProps: { iconName: 'Share' },
      onClick: onActionClick.bind(this, 'share'),
      ariaLabel: 'share action',
    },
    {
      iconProps: { iconName: 'Pin' },
      onClick: onActionClick.bind(this, 'pin'),
      ariaLabel: 'pin action',
    },
    {
      iconProps: { iconName: 'Ringer' },
      onClick: onActionClick.bind(this, 'notifications'),
      ariaLabel: 'notifications action',
    },
  ];

  const description: string = `My ${app.name} tasks and notifications`;

  return (
    
    <div>
      <DocumentCard styles={cardStyles} onClickHref={`#/tasks/${app.code}`}>
        <DocumentCardImage
          height={100}
          imageFit={ImageFit.centerCover}
          iconProps={oneNoteIconProps}
        />
        <DocumentCardDetails>
          <DocumentCardTitle title={description} shouldTruncate />
        </DocumentCardDetails>
        <DocumentCardActions actions={documentCardActions} views={numberOfTasks}>

        </DocumentCardActions>
      </DocumentCard>
    </div>
  );
};
