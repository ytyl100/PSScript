import { AppSettings } from "../../models";

export interface IDashboardAppCardProps{
    app:AppSettings;
    numberOfTasks:number;
}