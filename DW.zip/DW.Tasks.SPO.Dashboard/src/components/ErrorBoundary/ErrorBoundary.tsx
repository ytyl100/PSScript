import * as React from "react";

interface IProps {
  children: React.ReactNode;
}

interface IState {
  error: Error;
}

class ErrorBoundary extends React.Component<IProps, IState> {
  constructor(props: IProps) {
    super(props);
    this.state = { error: null };
  }

  public static getDerivedStateFromError(error: Error) {
    return { error: error.message };
  }

  public componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error("DW Dashboard error:", error, errorInfo);
  }

  public render() {
    if (this.state.error) {
      return (
        <div>
          <h1>Something went wrong</h1>
          <p>{this.state.error}</p>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
