import * as React from "react";
import { HashRouter, Route, Switch } from "react-router-dom";
import { HomePage, NotFoundPage, TasksPage } from "../../pages";
import { Header, NotificationBar } from "../../layout";
import { ErrorDetails, IAppProps } from "..";

require("./../../styles/dw.css");
import { useEffect, useReducer, useState } from "react";
import { AppContext } from "../../state/context";
import { appReducer, setAppStatus, setTasks } from "../../state/reducer";
import { AppStatus, initialAppState } from "../../state/state";
import { AppSettings, IAppUser } from "../../models";
import ErrorBoundary from "../ErrorBoundary/ErrorBoundary";
import { GlobalContext } from "../../hooks";
import Loader from "../Loader/Loader";
import { TaskApi } from "../../apis";


const App = (props: IAppProps) => {
  const user: IAppUser = props.user;
  const taskApi: TaskApi = new TaskApi(props.taskService);

  const [apps, setApps] = useState<AppSettings[]>([]);
  const [errorMessage, setErrorMessage] = useState<string>("");
  const [state, dispatch] = useReducer(appReducer, initialAppState);

  const fetchAppSettingsAsync = async () => {
    dispatch(setAppStatus(AppStatus.Loading));
    var res = await taskApi.loadAppSettings();

    setApps(res);
    dispatch(setAppStatus(AppStatus.Success));
  };

  const fetchTasksAsync = async () => {
    dispatch(setAppStatus(AppStatus.Loading));
    var res = await taskApi.loadTasks();
    dispatch(setTasks(res));
    dispatch(setAppStatus(AppStatus.Success));
  };

  useEffect(() => {
    console.warn("status change :", state.status);
  }, [state.status]);

  useEffect(() => {

    // setTimeout(() => {
    fetchAppSettingsAsync()
      .then(() => fetchTasksAsync())
      .catch((error: any) => {
        setErrorMessage(error);
        dispatch(setAppStatus(AppStatus.Error));
        console.error(error);
      });
    // }, 5000);
  }, []);

  return (
    <React.StrictMode>
      <GlobalContext.Provider value={{ user, apps, taskApi }}>
        <AppContext.Provider value={{ state, dispatch }}>

          <ErrorBoundary>
            <div className="dw-app">
              <HashRouter>

                <div className="dw-outer-container-header">
                  <div className="ms-Grid dw-container" dir="ltr">
                    <header className="ms-Grid-row">
                      <div className="ms-Grid-col ms-sm12">
                        <Header backLink={props.referrerUrl}></Header>
                      </div>
                    </header>
                  </div>
                </div>

                <div className="dw-outer-container-content">
                  <div className="ms-Grid dw-container" dir="ltr">
                    {(state.status === AppStatus.Loading ||
                      state.status === AppStatus.Empty) && (
                        <main className="ms-Grid-row">
                          <div className="ms-Grid-col ms-sm12">
                            <Loader></Loader>
                          </div>
                        </main>
                      )}


                    {(state.status === AppStatus.Error) && (
                      <main className="ms-Grid-row">
                        <div className="ms-Grid-col ms-sm12">
                          <ErrorDetails message={errorMessage}></ErrorDetails>
                        </div>
                      </main>
                    )}

                    {(state.status === AppStatus.Success) && (
                      <div className="ms-Grid-col ms-sm12">
                        <main className="ms-Grid-row">
                          <div className="ms-Grid-col ms-sm12">
                            <Switch>
                              <Route exact path="/" component={HomePage} />
                              <Route path="/tasks" component={TasksPage} />
                              <Route path="*">
                                <NotFoundPage></NotFoundPage>
                              </Route>
                            </Switch>
                          </div>
                        </main>
                      </div>
                    )}

                  </div>
                </div>


                {/* <div className="ms-Grid-row">
                    <div className="ms-Grid-col ms-sm12">
                      <NotificationBar
                        reset={() => console.warn("reset notification bar")}
                        refresh={() => fetchTasksAsync()}
                      ></NotificationBar>
                    </div>
                  </div> */}

              </HashRouter>
            </div>
          </ErrorBoundary>
        </AppContext.Provider>
      </GlobalContext.Provider>
    </React.StrictMode>
  );
};

export default App;
