import { IAppUser } from "../../models";
import { ITaskService } from "../../services";

export interface IAppProps {
  taskService: ITaskService;
  description: string;
  user: IAppUser;
  siteUrl?: string;
  referrerUrl?: string;
}
