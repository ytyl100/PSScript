declare interface IDashboardWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  TaskManagerApiUrlFieldLabel:string;
  DWLandingPageUrlFieldLabel:string;
  ApplicationIdFieldLabel:string;
  ScopesFieldLabel:string;
}

declare module 'DashboardWebPartStrings' {
  const strings: IDashboardWebPartStrings;
  export = strings;
}
