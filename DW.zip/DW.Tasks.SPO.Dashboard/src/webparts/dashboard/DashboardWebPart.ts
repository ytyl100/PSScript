import * as React from "react";
import * as ReactDom from "react-dom";
import { Version, Log } from "@microsoft/sp-core-library";
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField,
} from "@microsoft/sp-property-pane";
import { BaseClientSideWebPart } from "@microsoft/sp-webpart-base";

import * as strings from "DashboardWebPartStrings";
import { App, IAppProps } from "../../components";
import {
  ITaskService,
  ITokenService,
  TaskService,
  TokenService,
} from "../../services";
import { IAppUser } from "../../models";

export interface IDashboardWebPartProps {
  description: string;
  taskManagerApiUrl: string;
  dwLandingPageUrl: string;
  applicationId: string;
  scopes: string;  
}

export default class DashboardWebPart extends BaseClientSideWebPart<IDashboardWebPartProps> {
  private constructBackLinkUrl = (referrer: string): string => {
    if (referrer === "" || referrer === null || referrer === undefined) {
      return this.properties.dwLandingPageUrl;
    }

    return document.referrer;
  }

  private constructAppUser = (): IAppUser => {
    const user: IAppUser = {
      displayName: this.context.pageContext.user.displayName,
      email: this.context.pageContext.user.email,
      loginName: this.context.pageContext.user.loginName,
    };

    return user;
  }

  private constructTaskService = (): ITaskService => {

    let scopes: string[];
    if (this.properties.scopes !== null && this.properties.scopes !== undefined && this.properties.scopes !== '') {
      scopes = this.properties.scopes.split(',');
    }

    const tokenService: ITokenService = new TokenService(
      this.context.pageContext.aadInfo.tenantId,
      this.properties.applicationId,
      this.context.pageContext.user.email,
      scopes,
    );

    const taskService: ITaskService = new TaskService(
      this.context.serviceScope,
      this.context.httpClient,
      tokenService,
      this.properties.taskManagerApiUrl
    );
    return taskService;
  }

  public render(): void {

    Log.info('render()', 'this is a test message dwdev');
    Log.info('render()', 'this is a test message dwdev', this.context.serviceScope);    
    const taskService : ITaskService = this.constructTaskService();

    const element: React.ReactElement<IAppProps> = React.createElement(App, {
      taskService: taskService,
      description: this.properties.description,
      user: this.constructAppUser(),
      siteUrl: this.context.pageContext.web.absoluteUrl,
      referrerUrl: this.constructBackLinkUrl(document.referrer),
    });

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse("1.0");
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription,
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField("description", {
                  label: strings.DescriptionFieldLabel,
                }),
                PropertyPaneTextField("taskManagerApiUrl", {
                  label: strings.TaskManagerApiUrlFieldLabel,
                }),
                PropertyPaneTextField("dwLandingPageUrl", {
                  label: strings.DWLandingPageUrlFieldLabel,
                }),
                PropertyPaneTextField("applicationId", {
                  label: strings.ApplicationIdFieldLabel,
                }),
                PropertyPaneTextField("scopes", {
                  label: strings.ScopesFieldLabel,
                }),                
              ],
            },
          ],
        },
      ],
    };
  }
}
