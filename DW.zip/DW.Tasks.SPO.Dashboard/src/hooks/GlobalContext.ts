import { createContext, useContext } from "react";
import { TaskApi } from "../apis";
import { AppSettings, IAppUser } from "../models";



export type GlobalContent = {
  user: IAppUser;
  apps: AppSettings[];
  taskApi: TaskApi;
};

export const GlobalContext = createContext<GlobalContent>({
  user: undefined,
  apps: [],
  taskApi: undefined
});

export const useGlobalContext = () => useContext(GlobalContext);
