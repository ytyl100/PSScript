export class Helpers {
  public static DeserializeToDate(data: any): Date {
    return new Date(data);
  }
}