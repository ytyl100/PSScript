import { TaskStatus } from "../enums";

export const TaskStatusRenderer = (status: TaskStatus) => {
  switch (status) {
    case TaskStatus.Open:
      return "Open";
    case TaskStatus.Approved:
      return "Approved";
    case TaskStatus.Rejected:
      return "Rejected";
    default:
      console.error("Task Status unknown");
      return "Unknown";
  }
};

export const DateToStringRenderer = (date: Date) => {
    return date.toDateString();
};
