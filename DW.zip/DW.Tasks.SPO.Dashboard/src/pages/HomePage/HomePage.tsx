import * as React from "react";
import { DashboardAppCard } from "../../components";
import { useGlobalContext } from "../../hooks";
import { AppSettings } from "../../models";

export const HomePage = () => {
  const { apps } = useGlobalContext();

  return (
    <div className="ms-Grid" dir="ltr">
      <div className="ms-Grid-row">
        <div className="ms-Grid-col ms-sm12">
          <h2>Dashboard</h2>
        </div>
      </div>

      <div className="ms-Grid-row">
        {apps.map((app: AppSettings, idx: number) => (
          <div key={app.code} className="ms-Grid-col ms-sm12 ms-md6">
            <DashboardAppCard app={app} numberOfTasks={10}></DashboardAppCard>
          </div>
        ))}
      </div>
    </div>
  );
};
