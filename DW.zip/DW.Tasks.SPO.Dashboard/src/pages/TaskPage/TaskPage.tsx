import { Guid } from "@microsoft/sp-core-library";
import { update } from "lodash";
import {
  DefaultButton,
  IStackTokens,
  Stack,
  TextField,
} from "office-ui-fabric-react";
import * as React from "react";
import { useState } from "react";
import { Redirect } from "react-router-dom";
import { TaskStatus } from "../../enums";
import { useGlobalContext } from "../../hooks";
import { ITaskInfo } from "../../models";
import { useAppContext } from "../../state/context";
import { updateTask } from "../../state/reducer";
import { DateToStringRenderer } from "../../utils";

export interface ITaskPageProps {
  id: Guid;
}

export const TaskPage = ({ id }: ITaskPageProps) => {
  const { taskApi } = useGlobalContext();
  const { state, dispatch } = useAppContext();
  const [task, setTask] = useState<ITaskInfo>(undefined);

  const [redirect, setRedirect] = useState<string>("");

  React.useEffect(() => {
    console.log("TaskPage useEffect");
  }, []);

  React.useEffect(() => {
    console.log("use Effect... id change:", id);

    //const taskMatch = state.tasks.filter((t) => t.id === id);
    const taskMatch = state.tasks.filter((t) => t.id == id);
    if (taskMatch.length === 1) {
      setTask(taskMatch[0]);
    } else {
      setTask(undefined);
    }
  }, [id]);

  React.useEffect(() => {
    console.log("use Effect... redirect change:", redirect);
  }, [redirect]);

  const stackTokens: IStackTokens = { childrenGap: 10 };

  const updateTaskStatus = async (status: TaskStatus) => {
    const updatedTask : ITaskInfo = await taskApi.updateTask(task, status);
    console.log('task updated', updatedTask); 

    // NOTE - only works if it before the dispatch call
    const url = `/tasks/${task.app.code}`;
    console.log('redirect to url', url);
    setRedirect(url);
                  
    dispatch(updateTask(updatedTask));

    // await tasksService.updateTask(task.assignedTo.email, task.id, 1);
    // await fetchTasksDataAsync();
    // console.log("Approve", e);
    // // redirect back to the app tasks list
    // history.push(`/tasks/${task.app.code}`);
  };
  
  return redirect != "" ? <Redirect to={redirect} /> : (
    <div className="ms-Grid">
      <div className="ms-Grid-row">
        <div className="ms-Grid-col ms-sm12">
          <h2>Task Details</h2>
        </div>
      </div>

      {task === undefined ? (
        <div className="ms-Grid-row">
          <div className="ms-Grid-col ms-sm12">No task found</div>
        </div>
      ) : (
        <div className="ms-Grid-row">
          <div className="ms-Grid-col ms-sm6">
            <TextField
              label="Task No:"
              readOnly
              defaultValue={task.taskNumber}
            />
            <TextField label="Task:" readOnly defaultValue={task.title} />
            <TextField label="App:" readOnly defaultValue={task.app.name} />
            <TextField label="Region:" readOnly defaultValue={task.region} />
            <TextField
              label="Assigned To:"
              readOnly
              defaultValue={task.assignedTo.userName}
            />
            <TextField
              label="Due Date:"
              readOnly
              defaultValue={DateToStringRenderer(task.dueDate)}
            />
            <TextField
              label="Created By:"
              readOnly
              defaultValue={task.createdBy.userName}
            />
            <TextField
              label="Created:"
              readOnly
              defaultValue={DateToStringRenderer(task.created)}
            />
          </div>
          <div className="ms-Grid-col ms-sm6">
            <TextField
              label="Description"
              multiline
              rows={6}
              defaultValue={task.description}
            />
            <br></br>
            <hr></hr>
            <br></br>
            <TextField
              label="Comments"
              multiline
              rows={6}
              defaultValue="Your Comments"
            />
            <br></br>
            <hr></hr>
            <br></br>
            <Stack horizontal tokens={stackTokens}>
              <DefaultButton
                text="Approve"
                onClick={() => updateTaskStatus(TaskStatus.Approved)}
              />
              <DefaultButton
                text="Reject"
                onClick={() => updateTaskStatus(TaskStatus.Rejected)}
              />
            </Stack>
          </div>
        </div>
      )}
    </div>
  );
};
