import * as React from "react";
import { useEffect } from "react";
import { TaskList } from "../../components";
import { ITaskInfo } from "../../models";
import { useAppContext } from "../../state/context";

export interface ITaskListPageProps {
  app?: string;
}

export const TaskListPage = (props: ITaskListPageProps) => {
  const { state } = useAppContext();
  const [tasks, setTasks] = React.useState<ITaskInfo[]>([]);

  React.useEffect(() => {
    console.warn("TaskListPage useEffect app: ", props.app);

    if (props.app) {
      setTasks(state.tasks.filter(t => t.app.code === props.app));
    } else {
      setTasks(state.tasks);
    }
  }, [props.app]);

  return (
    <div className="ms-Grid" dir="ltr">
      <div className="ms-Grid-row">
        <div className="ms-Grid-col ms-sm12"><h2>Task List : {props.app}</h2></div>
      </div>
      <div className="ms-Grid-row">
        <div className="ms-Grid-col ms-sm12">
          <TaskList tasks={tasks}></TaskList>
        </div>
      </div>
    </div>
  );
};
