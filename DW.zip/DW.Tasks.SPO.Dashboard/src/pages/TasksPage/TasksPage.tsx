import { Guid } from "@microsoft/sp-core-library";
import * as React from "react";
import { Route, Switch, useParams } from "react-router-dom";
import { NotFoundPage, TaskPage } from "..";
import { ErrorBoundary } from "../../components";
import { ITaskInfo } from "../../models";
import { useAppContext } from "../../state/context";
import { TaskListPage } from "../TaskListPage/TaskListPage";
import { Link } from "react-router-dom";

type TaskParams = {
  app: string;
};

type TaskDetailParams = {
  id: string;
};

export const TasksPage = () => {
  const { state } = useAppContext();

  return (
    <ErrorBoundary>
      <div className="ms-Grid" dir="ltr">
        {/* <div className="ms-Grid-row">
          <div className="ms-Grid-col ms-sm12">
            <h3>Task Area links for testing</h3>
            <div>
              {state.tasks.slice(1,5).map((task: ITaskInfo, idx: number) => (
                <span key={idx}>
                  <Link to={`/tasks/${task.id}/view`}>{task.taskNumber}</Link>
                </span>
              ))}
            </div>
          </div>
        </div> */}
        <div className="ms-Grid-row">
          <div className="ms-Grid-col ms-sm12">
            <Switch>
              <Route
                exact
                path="/tasks"
                component={() => <TaskListPage></TaskListPage>}
              ></Route>
              <Route
                exact
                path="/tasks/:app"
                component={() => {
                  let { app } = useParams<TaskParams>();
                  console.warn("tasks app route string:", app);
                  return <TaskListPage app={app}></TaskListPage>;
                }}
              ></Route>
              <Route
                path="/tasks/:id/view"
                component={() => {
                  const { id } = useParams<TaskDetailParams>();
                  console.warn("tasks id route string:", id);
                  return <TaskPage id={Guid.parse(id)}></TaskPage>;
                }}
              />
              <Route path="/tasks/*">
                <NotFoundPage></NotFoundPage>
              </Route>
            </Switch>
          </div>
        </div>
      </div>
    </ErrorBoundary>
  );
};
