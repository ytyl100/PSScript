import { ITaskInfo } from "../models";

export interface AppState {
  tasks: ITaskInfo[];
  status: AppStatus;
}

export enum AppStatus {
  Empty = "Empty",
  Loading = "Loading",
  Error = "Error",
  Success = "Success",
}

export const initialAppState: AppState = {
  tasks: [],
  status: AppStatus.Empty,
};
