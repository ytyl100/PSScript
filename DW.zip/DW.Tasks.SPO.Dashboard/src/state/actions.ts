import { ITaskInfo } from "../models";
import { AppStatus } from "./state";

export enum ActionType {
    UpdateTask,
    SetTasks,
    SetAppStatus,
}

export interface UpdateTask{
    type: ActionType.UpdateTask;
    payload: ITaskInfo;
}

export interface SetTasks{
    type: ActionType.SetTasks;
    payload: ITaskInfo[];
}

export interface SetAppStatus {
    type:ActionType.SetAppStatus;
    payload: AppStatus;
}
export type AppActions = UpdateTask | SetTasks | SetAppStatus;

