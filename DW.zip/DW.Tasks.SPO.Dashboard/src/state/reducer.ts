import { ITaskInfo } from "../models";
import {
  ActionType,
  AppActions,
  SetAppStatus,
  SetTasks,
  UpdateTask,
} from "./actions";
import { AppState, AppStatus } from "./state";

export const appReducer = (state: AppState, action: AppActions): AppState => {
  console.warn("appreducer11", state, action);
  switch (action.type) {
    case ActionType.SetTasks:
      return {
        ...state,
        tasks: [...action.payload],
      };
    case ActionType.SetAppStatus:
      return {
        ...state,
        status: action.payload,
      };
    case ActionType.UpdateTask:
      console.warn('update task reducer....');
      const idx = state.tasks.findIndex((t) => t.id === action.payload.id);
      console.warn('update task idx: ', idx);
      const newArray = [...state.tasks];
      newArray[idx] = action.payload;

      return {
        ...state,
        tasks: newArray,
      };

    default:
      return state;
  }
};

export const setTasks = (tasks: ITaskInfo[]): SetTasks => ({
  type: ActionType.SetTasks,
  payload: tasks,
});

export const updateTask = (task: ITaskInfo): UpdateTask => ({
  type: ActionType.UpdateTask,
  payload: task,
});

export const setAppStatus = (status: AppStatus): SetAppStatus => ({
  type: ActionType.SetAppStatus,
  payload: status,
});
