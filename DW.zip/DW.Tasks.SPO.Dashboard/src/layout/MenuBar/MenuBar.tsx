import {
  IContextualMenuItemStyles,
  IContextualMenuStyles,
} from "office-ui-fabric-react";
import {
  CommandBar,
  ICommandBarItemProps,
} from "office-ui-fabric-react/lib/CommandBar";
import * as React from "react";
import { useGlobalContext } from "../../hooks";
import { AppSettings } from "../../models";
import { IMenuBarProps } from "./IMenuBarProps";

export const MenuBar = ({backLink}: IMenuBarProps) => {
  const { apps } = useGlobalContext();

  const itemStyles: Partial<IContextualMenuItemStyles> = {
    label: {},
    icon: { color: "red" },
    iconHovered: { color: "green" },
  };

  // For passing the styles through to the context menus
  const menuStyles: Partial<IContextualMenuStyles> = {
    root: {
      fontSize: 24,
      backgroundColor: "transparent",
      paddingTop: 20,
      paddingLeft: 0,
      paddingRight: 0,
    },
    subComponentStyles: { menuItem: itemStyles, callout: {} },
  };

  const buttonStylesLeft = {
    icon: {
      color: "#000000",
      fontSize: 24,
    },
    iconHovered: { color: "#FFFFFF" },
    root: {
      background: "transparent",
      color: "#000000",
      paddingRight: 12,
      fontSize: 16,
    },
    rootHovered: {
      background: "#DB0011",
      color: "#FFFFFF",
    },
  };

  const buttonStylesRight = {
    icon: {
      color: "#000000",
      fontSize: 24,
    },
    iconHovered: { color: "#FFFFFF" },
    root: {
      background: "transparent",
      color: "#000000",
      paddingRight: 0,
      fontSize: 16,
    },
    rootHovered: {
      background: "#DB0011",
      color: "#FFFFFF",
    },
  };

  const _items: ICommandBarItemProps[] = [
    {
      key: "home",
      text: "Home",
      iconProps: { iconName: "Home" },
      href: backLink,
      buttonStyles: buttonStylesLeft,
    },
    {
      key: "dashboard",
      text: "Dashboard",
      iconProps: { iconName: "BarChartVertical" },
      href: "#/",
      buttonStyles: buttonStylesLeft,
    },
  ];

  const _farItems: ICommandBarItemProps[] = [
    // {
    //   key: "tile",
    //   text: "Grid view",
    //   // This needs an ariaLabel since it's icon-only
    //   ariaLabel: "Grid view",
    //   iconOnly: true,
    //   iconProps: { iconName: "Tiles" },
    //   onClick: () => console.log("Tiles"),
    //   buttonStyles: buttonStyles,
    // },
    {
      key: "info",
      text: "Info",
      // This needs an ariaLabel since it's icon-only
      ariaLabel: "Info",
      iconOnly: true,
      iconProps: { iconName: "Info" },
      onClick: () => console.log("Info"),
      buttonStyles: buttonStylesRight,
    },
  ];

  apps.map((app: AppSettings) => {
    console.log(app);
    _items.push({
      key: app.code,
      text: app.name,
      iconProps: { iconName: app.iconName },
      href: `#/tasks/${app.code}`,
      buttonStyles: buttonStylesLeft,
    });
  });
  React.useEffect(() => {
    console.warn("useEffect menu bar...");
    apps.forEach((app: AppSettings) => {
      console.warn("app:", app);
    });
  }, []);

  return (
    <CommandBar
      items={_items}
      farItems={_farItems}
      styles={menuStyles}
    ></CommandBar>
  );
};
