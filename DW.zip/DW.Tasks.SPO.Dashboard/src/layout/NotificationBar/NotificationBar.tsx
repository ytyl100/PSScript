import * as React from 'react';
import {
  Link,
  Stack,
  StackItem,
  MessageBar,
  MessageBarType,
  ChoiceGroup,
  IStackProps,
  MessageBarButton,
  Text,
  IChoiceGroupStyles,
} from 'office-ui-fabric-react';

interface INotificationBarProps {
  reset: () => void;
  refresh: () => void;
}

export const NotificationBar = (props: INotificationBarProps) => (
  <MessageBar
    messageBarType={MessageBarType.warning}
    isMultiline={false}
    onDismiss={props.reset}
    dismissButtonAriaLabel="Close"
    actions={
      <div>
        <MessageBarButton onClick={props.refresh}>Refresh</MessageBarButton>
      </div>
    }
  >
    Warning MessageBar content.
    <Link href="www.bing.com" target="_blank" underline>
      Visit our website.
    </Link>
  </MessageBar>
);
