import { Guid, ServiceScope } from "@microsoft/sp-core-library";
import {
  HttpClient,
  HttpClientResponse,
  IHttpClientOptions,
} from "@microsoft/sp-http";
import { ITaskService } from ".";
import { Helpers } from "../utils/Helpers";
import { TaskStatus } from "../enums";
import { AppSettings, ITaskInfo, ITaskUpdateIdentifier } from "../models";
import { ITokenService } from "./ITokenService";

export class TaskService implements ITaskService {
  // public static readonly serviceKey: ServiceKey<ITaskService> =
  //   ServiceKey.create<ITaskService>("dw-app:ITaskService", TaskService);

  constructor(
    private serviceScope: ServiceScope,
    private client: HttpClient,
    private tokenService: ITokenService,
    private taskManagerApiUrl: string
  ) {
    //serviceScope.whenFinished(() => {});
  }
  public async updateTask(
    task: ITaskInfo,
    status: TaskStatus
  ): Promise<ITaskInfo> {
    try {
      const accessToken = await this.tokenService.getToken();
      console.warn("access token:", accessToken);

      const endpoint: string = `${this.taskManagerApiUrl}/api/UpdateTask`;

      const requestHeaders: Headers = new Headers();
      requestHeaders.append("accept", "application/json");
      requestHeaders.append("Authorization", `Bearer ${accessToken}`);

      let taskUpdateIdentifier: ITaskUpdateIdentifier = {
        upn: task.assignedTo.email,
        id: task.id,
        status: status,
      };
      const body: string = JSON.stringify(taskUpdateIdentifier);

      const clientOptions: IHttpClientOptions = {
        headers: requestHeaders,
        body: body,
      };

      const clientResponse: HttpClientResponse = await this.client.post(
        endpoint,
        HttpClient.configurations.v1,
        clientOptions
      );

      if (clientResponse.status !== 200) {
        console.error(
          "client response status:",
          clientResponse.status,
          clientResponse.statusText
        );
        //return [];
        throw new Error(
          `status: ${clientResponse.status} - response: ${clientResponse.statusText}`
        );
      }

      const updatedTask: ITaskInfo = await clientResponse.json();

      // TODO: JSON reviver
      updatedTask.created = Helpers.DeserializeToDate(updatedTask.created);
      updatedTask.dueDate = Helpers.DeserializeToDate(updatedTask.dueDate);

      console.warn("task:", updatedTask);

      return updatedTask;
    } catch (error) {
      console.error(error);
      throw new Error(error);
    }
  }

  public async getApps(): Promise<AppSettings[]> {
    const currentApps: AppSettings[] = [
      {
        code: "hr",
        description: "My HR",
        name: "HR",
        iconName: "D365TalentHRCore",
      },
      {
        code: "itid",
        description: "My ITID",
        name: "ITID",
        iconName: "AccountActivity",
      },
      {
        code: "fusion",
        description: "My Fusion",
        name: "Fusion",
        iconName: "RecruitmentManagement",
      },
      {
        code: "clarity",
        description: "My Clarity",
        name: "Clarity",
        iconName: "Financial",
      },
    ];
    return currentApps;
  }

  public async getTasks(): Promise<ITaskInfo[]> {
    try {
      const accessToken = await this.tokenService.getToken();
      console.warn("access token:", accessToken);

      const endpoint: string = `${this.taskManagerApiUrl}/api/GetTasks`;

      const requestHeaders: Headers = new Headers();
      requestHeaders.append("accept", "application/json");
      requestHeaders.append("Authorization", `Bearer ${accessToken}`);

      const clientOptions: IHttpClientOptions = {
        headers: requestHeaders,
      };

      const clientResponse: HttpClientResponse = await this.client.get(
        endpoint,
        HttpClient.configurations.v1,
        clientOptions
      );

      if (clientResponse.status !== 200) {
        console.error(
          "client response status:",
          clientResponse.status,
          clientResponse.statusText
        );

        throw new Error(
          `status: ${clientResponse.status} - response: ${clientResponse.statusText}`
        );
      }

      const tasks: ITaskInfo[] = await clientResponse.json();

      // TODO: JSON reviver
      tasks.forEach((t) => {
        t.created = Helpers.DeserializeToDate(t.created);
        t.dueDate = Helpers.DeserializeToDate(t.dueDate);
      });

      console.warn("tasks:", tasks);

      return tasks;
    } catch (error) {
      console.error(error);
      throw new Error(error);
    }
  }
}
