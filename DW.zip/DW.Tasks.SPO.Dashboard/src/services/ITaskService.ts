import { Guid } from "@microsoft/sp-core-library";
import { TaskStatus } from "../enums";
import { AppSettings, ITaskInfo } from "../models";

export interface ITaskService {
  updateTask: (task: ITaskInfo, status: TaskStatus) => Promise<ITaskInfo>;
  getTasks: () => Promise<ITaskInfo[]>;
  getApps: () => Promise<AppSettings[]>;
}
