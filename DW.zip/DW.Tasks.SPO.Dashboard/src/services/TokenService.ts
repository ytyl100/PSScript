import {
  AccountInfo,
  AuthenticationResult,
  Configuration,
  LogLevel,
  PublicClientApplication,
  SilentRequest,
  SsoSilentRequest,
} from "@azure/msal-browser";

import { ITokenService } from "./ITokenService";

export class TokenService implements ITokenService {

  private MSAL_CONFIG: Configuration = {
    auth: {
      authority: null,
      clientId: null,
    },
    cache: {
      cacheLocation: "sessionStorage", // This configures where your cache will be stored
      storeAuthStateInCookie: false, // Set this to "true" if you are having issues on IE11 or Edge
    },
    system: {
      // windowHashTimeout: 60000,
      // iframeHashTimeout: 6000,
      // loadFrameTimeout: 0,
      loggerOptions: {
        loggerCallback: (level, message, containsPii) => {
          if (containsPii) {
            return;
          }
          switch (level) {
            case LogLevel.Error:
              console.error("MSAL Log", message);  
              return;
            case LogLevel.Info:
              console.log("MSAL Log", message);  
              return;
            case LogLevel.Verbose:
              console.debug("MSAL Log", message);  
              return;
            case LogLevel.Warning:
              console.warn("MSAL Log", message);  
              return;
          }
        },
      },
    },
  };


  private myMSALObj: PublicClientApplication;

  private silentLoginRequest: SsoSilentRequest;

  constructor(
    private tenantId: string,
    private applicationId: string,
    private email: string,
    private scopes: string[]
  ) {
    this.MSAL_CONFIG.auth.authority = `https://login.microsoftonline.com/${this.tenantId}`;
    this.MSAL_CONFIG.auth.clientId = this.applicationId;

    this.myMSALObj = new PublicClientApplication(this.MSAL_CONFIG);

    this.silentLoginRequest = {
      loginHint: email,
      scopes: this.scopes,
    };
  }

  private getAccount = (email: string): AccountInfo => {
    const accounts = this.myMSALObj.getAllAccounts();
    if (accounts === null || accounts.length === 0) {
      return null;
    } else {
      return this.myMSALObj.getAccountByUsername(email);
    }
  }

  private acquireTokenSilent = async (
    account: AccountInfo
  ): Promise<AuthenticationResult> => {
    const sRequest: SilentRequest = {
      scopes: this.scopes,
      account: account,
    };

    try {
      const res: AuthenticationResult = await this.myMSALObj.acquireTokenSilent(
        sRequest
      );

      return res;
    } catch (error) {
      console.error("acquireTokenSilent:", error);
      throw error;
    }
  }

  private ssoSilent = async (): Promise<AuthenticationResult> => {
    try {
      const silentResult = await this.myMSALObj.ssoSilent(
        this.silentLoginRequest
      );

      return silentResult;
    } catch (error) {
      console.error("ssoSilent:", error);
      throw error;
    }
  }

  public async getToken(): Promise<string> {
    const account = this.getAccount(this.email);

    let res: AuthenticationResult;

    try {
      res =
        account !== null
          ? await this.acquireTokenSilent(account)
          : await this.ssoSilent();

      return res.accessToken;
    } catch (error) {
      console.error("getToken", error);
      throw error;
    }
  }
}
