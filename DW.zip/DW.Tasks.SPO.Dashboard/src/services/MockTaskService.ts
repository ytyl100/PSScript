import { Guid } from "@microsoft/sp-core-library";
import { ITaskService } from ".";
import { TaskStatus } from "../enums";
import { ITaskInfo, AppSettings } from "../models";

export class MockTaskService implements ITaskService {
  public updateTask(task: ITaskInfo, status: TaskStatus): Promise<ITaskInfo>{
    return Promise.resolve<ITaskInfo>(undefined);
  }

  public async getApps(): Promise<AppSettings[]> {
    return Promise.resolve<AppSettings[]>([]);
  }

  public async getTasks(): Promise<ITaskInfo[]> {
    return Promise.resolve<ITaskInfo[]>([]);
  }
}
