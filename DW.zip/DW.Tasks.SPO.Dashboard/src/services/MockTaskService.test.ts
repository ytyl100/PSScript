/// <reference types="jest" />

import { ITaskInfo } from "../models";
import { ITaskService } from "./ITaskService";
import { MockTaskService } from "./MockTaskService";


let sut: ITaskService;

beforeEach(()=>{
    sut = new MockTaskService();
});

describe('Task Service', ()=>{

  describe('GetTasks()', ()=>{

    test('GetTasks() returns correct result', ()=>{
      expect.assertions(1);

      return sut.getTasks()
      .then((result:ITaskInfo[]) => {
        expect(result.length).toBe(0);
      });

    });
        
  });
});