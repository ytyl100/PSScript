import { TaskStatus } from "../enums";
import { AppSettings, ITaskInfo } from "../models";
import { ITaskService } from "../services";

export class TaskApi {
  constructor(private taskService: ITaskService) {
    console.warn("Task Api constructor");
  }

  public async loadTasks(): Promise<ITaskInfo[]> {
    const tasks = await this.taskService.getTasks();
    return tasks;
  }

  public async updateTask(task:ITaskInfo, status: TaskStatus) : Promise<ITaskInfo>{
    const updatedTask = await this.taskService.updateTask(task, status);
    return updatedTask;
  }


  public async loadAppSettings(): Promise<AppSettings[]> {
    const settings = await this.taskService.getApps();
    return settings;
  }
}