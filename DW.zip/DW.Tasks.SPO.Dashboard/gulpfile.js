'use strict';

const gulp = require('gulp');
const build = require('@microsoft/sp-build-web');
const { webpack } = require('@microsoft/sp-build-web');

build.addSuppression(`Warning - [sass] The local CSS class 'ms-Grid' is not camelCase and will not be type-safe.`);


// build.configureWebpack.mergeConfig({


//   additionalConfiguration: (generatedConfig) => {
//     const WebpackAutoInject = require('webpack-auto-inject-version');

//     generatedConfig.plugins.push(new WebpackAutoInject({
//       components:{
//         AutoIncreaseVersion:false,
//         InjectAsComment: true,
//         InjectAsTag:false,
//       },
//       InjectAsComment:{
//         tag: 'Version: {version} - {date}',
//         dateFormat: 'h:MM:ss TTT'
//       },
//       SILENT:true
//     }));

//     return generatedConfig;
//   }
// });



const dwMessage = (msg) => {
  return build.subTask('dw-message', (gulp, buildOptions, done) => {
    build.log('DW: ', msg);
    done();
  })
}

// build.rig.addPostBuildTask(build.task('dw-message', dwMessage('addPostBuildTask')));
// build.rig.addPostBundleTask(build.task('dw-message', dwMessage('addPostBundleTask')));
// build.rig.addPostTelemetryTask(build.task('dw-message', dwMessage('addPostTelemetryTask')));
// build.rig.addPostTypescriptTask(build.task('dw-message', dwMessage('addPostTypescriptTask')));
// build.rig.addPreBuildTask(build.task('dw-message', dwMessage('addPreBuildTask')));
// build.rig.addPreTelemetryTask(build.task('dw-message', dwMessage('addPreTelemetryTask')));

var getTasks = build.rig.getTasks;
build.rig.getTasks = function () {
  var result = getTasks.call(build.rig);

  //console.warn(result);
  result.set('serve', result.get('serve-deprecated'));

  return result;
};

build.initialize(gulp);
