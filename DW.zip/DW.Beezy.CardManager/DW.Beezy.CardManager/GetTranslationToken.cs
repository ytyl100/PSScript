using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using DW.Beezy.CardManager.Services;
using System.Net.Http;
using System.Net;
using System.Security.Claims;

namespace DW.Beezy.CardManager
{
    public class GetTranslationTokenResponse
    {
        public string AccessToken { get; set; }

        public long Expires { get; set; }
    }

    public class GetTranslationToken
    {
        private IAzureTranslationService _azureTranslationService;

        public GetTranslationToken(IAzureTranslationService azureTranslationService)
        {
            _azureTranslationService = azureTranslationService;
        }

        // http://localhost:7071/api/GetTranslationToken
        [FunctionName("GetTranslationToken")]
        public async Task<HttpResponseMessage> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            try
            {
                //ClaimsPrincipal authUser = req.HttpContext.User;
                //string authUserName = authUser?.Identity?.Name;

                // confirm the user is authenticated
                if (!req.HttpContext.User.Identity.IsAuthenticated)
                {
                    throw new Exception("Request is not authenticated");
                }

                // get the access token for this request
                // string authHeader = req.Headers["Authorization"];
                // string accessToken = string.IsNullOrEmpty(authHeader) ? "" : authHeader.Substring("Bearer ".Length);

                // provide a response
                string accessToken = await _azureTranslationService.GetAccessToken();
                long javascriptTime = (DateTime.Now.AddMinutes(10).Ticks - 621355968000000000) / 10000;
                var responseObject = new GetTranslationTokenResponse { AccessToken = accessToken, Expires = javascriptTime };
                var responseJson = JsonConvert.SerializeObject(responseObject, Formatting.Indented);
                var response = new HttpResponseMessage(HttpStatusCode.OK);
                response.Content = new StringContent(responseJson, System.Text.Encoding.UTF8, "application/json");
                return response;
            }
            catch (Exception ex)
            {
                var response = new HttpResponseMessage(HttpStatusCode.InternalServerError);
                response.Content = new StringContent(ex.ToString(), System.Text.Encoding.UTF8, "text/plain");
                return response;
            }
        }
    }
}
