using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Net.Http;
using System.Net;
using DW.Beezy.CardManager.Services;

namespace DW.Beezy.CardManager
{
    public class TranslateTextResponse
    {
        public string Text { get; set; }

        public string Language { get; set; }
    }

    public class TranslateText
    {
        private IAzureTranslationService _azureTranslationService;

        public TranslateText(IAzureTranslationService azureTranslationService)
        {
            _azureTranslationService = azureTranslationService;
        }

        // http://localhost:7071/api/TranslateText
        [FunctionName("TranslateText")]
        public async Task<HttpResponseMessage> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            try
            {
                // allow text to be set through a query string for testing
                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                dynamic data = JsonConvert.DeserializeObject(requestBody);
                string text = req.Query["text"];
                text ??= data?.text;
                string from = req.Query["from"];
                from ??= data?.from;
                string to = req.Query["to"];
                to ??= data?.to;

                //ClaimsPrincipal authUser = req.HttpContext.User;
                //string authUserName = authUser?.Identity?.Name;

                // confirm the user is authenticated
                if (!req.HttpContext.User.Identity.IsAuthenticated)
                {
                    throw new Exception("Request is not authenticated");
                }

                // get the access token for this request
                // string authHeader = req.Headers["Authorization"];
                // string accessToken = string.IsNullOrEmpty(authHeader) ? "" : authHeader.Substring("Bearer ".Length);

                // for debug testing only
                // accessToken = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Im5PbzNaRHJPRFhFSzFqS1doWHNsSFJfS1hFZyIsImtpZCI6Im5PbzNaRHJPRFhFSzFqS1doWHNsSFJfS1hFZyJ9.eyJhdWQiOiJodHRwczovL2Z1bmMtamltLWNzeC5henVyZXdlYnNpdGVzLm5ldCIsImlzcyI6Imh0dHBzOi8vc3RzLndpbmRvd3MubmV0LzYwZjAwNDhlLTEzYTctNGM0MC04ZjQ0LTcxNDRhMDA3NGNjZS8iLCJpYXQiOjE2MjkxOTg5MTcsIm5iZiI6MTYyOTE5ODkxNywiZXhwIjoxNjI5MjAyODE3LCJhY3IiOiIxIiwiYWlvIjoiQVRRQXkvOFRBQUFBKzBpbmkzRVdYQ0YxeVY1Q2RnTXhFYWpIT0dwRi80SlN1U25SUWl6TTBjbThyVFNZd1pmd1FqaHA4cGVjdENjUiIsImFtciI6WyJwd2QiXSwiYXBwaWQiOiI1YmJmNGRmYy0wZjc5LTRkMDktOWYwMS1mMWYwODM3MzU4YmUiLCJhcHBpZGFjciI6IjAiLCJmYW1pbHlfbmFtZSI6IkdyaWZmaXRocyIsImdpdmVuX25hbWUiOiJKaW0iLCJpcGFkZHIiOiIyMTIuMTU5Ljc4LjI0IiwibmFtZSI6IkppbSBHcmlmZml0aHMiLCJvaWQiOiIwYWM1NTIxOS05MzNmLTRiMzItODA5Zi1lYjc3OGRkODM1ZGUiLCJyaCI6IjAuQVM4QWpnVHdZS2NUUUV5UFJIRkVvQWRNenZ4TnYxdDVEd2xObndIeDhJTnpXTDR2QURZLiIsInNjcCI6InVzZXJfaW1wZXJzb25hdGlvbiIsInN1YiI6IlR0bjJUenZ4TzZDSmw1bUlfblJBWE9TWTBQUVJPY0NRREI4WE1Gc3o4X28iLCJ0aWQiOiI2MGYwMDQ4ZS0xM2E3LTRjNDAtOGY0NC03MTQ0YTAwNzRjY2UiLCJ1bmlxdWVfbmFtZSI6ImppbS5ncmlmZml0aHNAZHdkZXYzNjUub25taWNyb3NvZnQuY29tIiwidXBuIjoiamltLmdyaWZmaXRoc0Bkd2RldjM2NS5vbm1pY3Jvc29mdC5jb20iLCJ1dGkiOiJVTl8wcDUyT2owdWFMM3BFcGVWX0FBIiwidmVyIjoiMS4wIn0.cmdvS56tGIqtaKnKFNVdODe_lpDNfaAEBFVPxVnDI-bj3xuyBu48m4ViAAIrx0sMOG1F8Q6YsxQA3BmRSwI_TXvfCw_gg3PL7m4WCosfPj31F-bEKJMM7lIenWniSCeFfTkQ5_1TGrJNsm3kL6YTwvWl81wKstLUlsckZsrohZpr6AalvKbCGYXe2WQjdh8BUlRLbIWuCHtkFxNb7ytxJ0fHZLBYjDt86QscluY3bPNC5lLVUfR0HkWpN9LjtYhtj_73VNF_M0Sp5IdJotjjcEO0KlFtPzxpBzGbKb3p7RvDX_trJ_dGP7rrYHfM7NnCcjXw28okgkIxW4XruRQl8w";

                // provide a response
                string translatedText = await _azureTranslationService.TranslateText(text, from, to);
                var responseObject = new TranslateTextResponse { Text = translatedText, Language = to };
                var responseJson = JsonConvert.SerializeObject(responseObject, Formatting.Indented);
                var response = new HttpResponseMessage(HttpStatusCode.OK);
                response.Content = new StringContent(responseJson, System.Text.Encoding.UTF8, "application/json");
                return response;
            }
            catch (Exception ex)
            {
                var response = new HttpResponseMessage(HttpStatusCode.InternalServerError);
                response.Content = new StringContent(ex.ToString(), System.Text.Encoding.UTF8, "text/plain");
                return response;
            }
        }
    }
}
