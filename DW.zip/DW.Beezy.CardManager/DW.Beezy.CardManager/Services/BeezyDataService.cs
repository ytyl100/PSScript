﻿using DW.Beezy.CardManager.Authentication;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace DW.Beezy.CardManager.Services
{
    public class BeezyDataServiceSettings
    {
        public string TenantName { get; set; }

        public string BeezyApiSiteName { get; set; }

        public string BeezySharePointSiteName { get; set; }
    }

    public interface IBeezyDataService
    {
        Task<string> CreateActivityCard(string user, string tag, string title, string message1, string message2, string link);
    }

    public class BeezyDataService : BaseDataService, IBeezyDataService
    {
        protected BeezyDataServiceSettings _settings;

        protected override string AcceptHeader => "application/json";

        protected override string Scope => $"https://{_settings.TenantName}.sharepoint.com/.default";

        protected override JToken GetJsonRoot(string json) => JToken.Parse(json);

        public BeezyDataService(UserTokenClient tokenClient, HttpClient httpClient, BeezyDataServiceSettings settings) : base(tokenClient, httpClient)
        {
            _settings = settings;
        }

        public async Task<string> CreateActivityCard(string user, string tag, string title, string message1, string message2, string link)
        {
            string siteCollectionUrl = $"https://{_settings.TenantName}.sharepoint.com/sites/{_settings.BeezySharePointSiteName}";
            string url = $"https://{_settings.BeezyApiSiteName}.azurewebsites.net/BeezyApi.svc/Workflow/ActionCard?SPHostUrl={siteCollectionUrl}&languageId=1033";

            // create template string
            var template = "{\"$schema\":\"http://adaptivecards.io/schemas/adaptive-card.json\",\"type\":\"AdaptiveCard\",\"version\":\"1.0\",\"brandBorderColor\":\"#F29330\",\"body\":[{\"type\":\"Container\",\"items\":[{\"type\":\"ColumnSet\",\"columns\":[{\"type\":\"Column\",\"width\":\"auto\",\"items\":[{\"type\":\"Image\",\"size\":\"small\",\"url\":\"https://public.beezy.net/design/actions/workday.png\"}]},{\"type\":\"Column\",\"width\":\"stretch\",\"verticalContentAlignment\":\"center\",\"items\":[{\"type\":\"TextBlock\",\"text\":\""
                + title + "\",\"weight\":\"bolder\",\"wrap\":true,\"color\":\"accent\",\"size\":\"small\"}]}]}]},{\"type\":\"Container\",\"items\":[{\"type\":\"TextBlock\",\"weight\":\"bolder\",\"text\":\""
                + message1 + "\",\"wrap\":true,\"color\":\"accent\"},{\"type\":\"TextBlock\",\"text\":\""
                + message2 + "\",\"wrap\":true,\"color\":\"accent\"}]}],\"actions\":[{\"type\":\"Action.OpenUrl\",\"title\":\"View\",\"url\":\""
                + link + "\"}]}";

            // encode so that we can include this JSON string within the JSON body
            string encodedTemplate = System.Web.HttpUtility.JavaScriptStringEncode(template);

            // NOTE {{ and }} escaped for interpolated string
            string payload = $"{{\"Template\":\"{encodedTemplate}\", \"Users\": \"{user}\", \"Tags\": \"{tag}\"}}";
            var body = new StringContent(payload, Encoding.UTF8, "application/json");

            var response = await PostAsync(url, body);
            return response;
        }
    }
}
