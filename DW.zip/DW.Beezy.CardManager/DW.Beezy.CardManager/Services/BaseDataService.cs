﻿using DW.Beezy.CardManager.Authentication;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace DW.Beezy.CardManager.Services
{
    public class DataServiceException : Exception
    {
        public int StatusCode { get; set; }

        public string Content { get; set; }

        public override string Message
        {
            get { return $"Status: {StatusCode}. Error Message Content: {Content}"; }
        }
    }

    public abstract class BaseDataService
    {
        private ITokenClient _tokenClient;
        private HttpClient _httpClient;

        protected abstract string AcceptHeader { get; }

        protected abstract string Scope { get; }

        protected abstract JToken GetJsonRoot(string json);

        protected BaseDataService(ITokenClient tokenClient, HttpClient httpClient)
        {
            _tokenClient = tokenClient;
            _httpClient = httpClient;
            _httpClient.DefaultRequestHeaders.Add("Accept", AcceptHeader);
        }

        protected async Task<T> GetAsync<T>(string url)
        {
            await EnsureAccessToken();

            var response = await _httpClient.GetAsync(url);
            var json = await response.Content.ReadAsStringAsync();

            // NOTE: calling EnsureSuccessStatusCode() throws an HttpRequestException exception whenever the HttpStatusCode represents an error
            if (response.IsSuccessStatusCode == false)
            {
                throw new DataServiceException
                {
                    StatusCode = (int)response.StatusCode,
                    Content = json
                };
            }

            var jsonRoot = GetJsonRoot(json);
            var responseObjects = JsonConvert.DeserializeObject<T>(jsonRoot.ToString());
            return responseObjects;
        }

        protected async Task<string> PostAsync(string url, StringContent body)
        {
            await EnsureAccessToken();

            var response = await _httpClient.PostAsync(url, body);
            var json = await response.Content.ReadAsStringAsync();

            // NOTE: calling EnsureSuccessStatusCode() throws an HttpRequestException exception whenever the HttpStatusCode represents an error
            if (response.IsSuccessStatusCode == false)
            {
                throw new DataServiceException
                {
                    StatusCode = (int)response.StatusCode,
                    Content = json
                };
            }

            return json;
        }

        protected async Task<T> PostAsync<T>(string url, StringContent body, Func<string, JToken> getJsonRoot = null)
        {
            await EnsureAccessToken();

            var responseMessage = await _httpClient.PostAsync(url, body);
            string json = await responseMessage.Content.ReadAsStringAsync();

            // NOTE: calling EnsureSuccessStatusCode() throws an HttpRequestException exception whenever the HttpStatusCode represents an error
            if (!responseMessage.IsSuccessStatusCode)
            {
                throw new DataServiceException
                {
                    StatusCode = (int)responseMessage.StatusCode,
                    Content = json
                };
            }

            var jsonRoot = getJsonRoot != null ? getJsonRoot(json) : GetJsonRoot(json);
            var responseObjects = JsonConvert.DeserializeObject<T>(jsonRoot.ToString());
            return responseObjects;
        }

        private async Task EnsureAccessToken()
        {
            if (_httpClient.DefaultRequestHeaders.Authorization == null)
            {
                string accessToken = await GetAccessToken();
                _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
            }
        }

        private async Task<string> GetAccessToken()
        {
            return await _tokenClient.GetTokenAsync(new string[] { Scope });
        }
    }
}
