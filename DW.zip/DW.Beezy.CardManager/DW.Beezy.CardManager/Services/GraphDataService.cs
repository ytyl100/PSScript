﻿using DW.Beezy.CardManager.Authentication;
using Microsoft.Graph;
using Microsoft.Identity.Client;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace DW.Beezy.CardManager.Services
{
    public class GraphDataServiceSettings
    {
        public string TenantName { get; set; }
    }

    public interface IGraphDataService
    {
        public void SetInitialAccessToken(string accessToken);

        public string GetOnBehalfOfAccessToken();

        Task<User> GetUser();
    }

    public class GraphDataService : IGraphDataService
    {
        protected GraphDataServiceSettings _settings;

        //protected string Scope => "https://graph.microsoft.com/user.read";
        protected string Scope => "https://graph.microsoft.com/.default";

        protected JToken GetJsonRoot(string json) => JToken.Parse(json);

        private GraphServiceClient _graphServiceClient;

        public GraphDataService(OnBehalfOfAuthProvider authProvider, GraphDataServiceSettings settings)
        {
            _graphServiceClient = new GraphServiceClient(authProvider);
            authProvider.Scope = Scope;
            _settings = settings;
        }

        public void SetInitialAccessToken(string accessToken)
        {
            ((OnBehalfOfAuthProvider)_graphServiceClient.AuthenticationProvider).InitialAccessToken = accessToken;
        }

        public string GetOnBehalfOfAccessToken()
        {
            return ((OnBehalfOfAuthProvider)_graphServiceClient.AuthenticationProvider).OnBehalfOfAccessToken;
        }

        public async Task<User> GetUser()
        {
            return await _graphServiceClient.Me.Request().Select(e => new
            {
                e.UserPrincipalName,
                e.DisplayName,
                e.EmployeeId
            }).GetAsync();
        }
    }
}
