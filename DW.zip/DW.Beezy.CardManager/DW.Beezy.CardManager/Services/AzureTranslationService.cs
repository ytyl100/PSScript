﻿using DW.Beezy.CardManager.Authentication;
using DW.Beezy.CardManager.Data;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace DW.Beezy.CardManager.Services
{
    public class AzureTranslationServiceSettings
    {
        public string AzureTranslationUrl { get; set; }

        public string AzureTranslationRegion { get; set; }

        public string AzureTranslationKey { get; set; }
    }

    public interface IAzureTranslationService
    {
        Task<string> GetAccessToken();

        Task<string> DetectLanguage(string text);

        Task<string> TranslateText(string text, string fromLanguage, string toLanguage);
    }

    public class AzureTranslationService : BaseDataService, IAzureTranslationService
    {
        protected AzureTranslationServiceSettings _settings;

        protected override string AcceptHeader => "application/json";

        protected override string Scope => $"";

        protected override JToken GetJsonRoot(string json) => JToken.Parse(json);

        public AzureTranslationService(TranslationTokenProvider tokenClient, HttpClient httpClient, AzureTranslationServiceSettings settings) : base(tokenClient, httpClient)
        {
            _settings = settings;
            httpClient.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Region", _settings.AzureTranslationRegion);
            httpClient.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", _settings.AzureTranslationKey);
        }

        public async Task<string> GetAccessToken()
        {
            string translationTokenUrlRegionPrefix = string.IsNullOrEmpty(_settings.AzureTranslationRegion) ? string.Empty : $"{_settings.AzureTranslationRegion}.";

            var body = new StringContent("", Encoding.UTF8, "application/json");
            var response = await PostAsync($"https://{translationTokenUrlRegionPrefix}api.cognitive.microsoft.com/sts/v1.0/issueToken", body);
            return response;
        }

        public async Task<string> DetectLanguage(string text)
        {
            // NOTE {{ and }} escaped for interpolated string
            string payload = $"[{{\"Text\":\"{text}\"}}]";
            var body = new StringContent(payload, Encoding.UTF8, "application/json");
            string url = $"{_settings.AzureTranslationUrl}/detect?api-version=3.0";
            var response = await PostAsync<List<AzureTranslationLanguage>>(url, body);
            return response.First().Language;
        }

        public async Task<string> TranslateText(string text, string fromLanguage, string toLanguage)
        {
            // NOTE {{ and }} escaped for interpolated string
            string payload = $"[{{\"Text\":\"{text}\"}}]";
            var body = new StringContent(payload, Encoding.UTF8, "application/json");
            string url = $"{_settings.AzureTranslationUrl}/translate?api-version=3.0&from={fromLanguage}&to={toLanguage}";
            var response = await PostAsync<List<AzureTranslations>>(url, body);
            return response.First().Translations.First().Text;
        }
    }
}
