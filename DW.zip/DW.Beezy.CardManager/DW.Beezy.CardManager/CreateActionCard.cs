using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using DW.Beezy.CardManager.Services;
using System.Net.Http;
using System.Net;
using System.Security.Claims;
using Microsoft.Graph;
using System.Collections.Generic;
using System.Net.Http.Headers;
using DW.Beezy.CardManager.Authentication;
using Microsoft.Identity.Client;

namespace DW.Beezy.CardManager
{
    public class CreateActionCard
    {
        private IGraphDataService _graphDataService;
        private IBeezyDataService _beezyDataService;


        public CreateActionCard(IGraphDataService graphDataService, IBeezyDataService beezyDataService)
        {
            _graphDataService = graphDataService;
            _beezyDataService = beezyDataService;
        }

        // http://localhost:7071/api/CreateActionCard
        [FunctionName("CreateActionCard")]
        public async Task<HttpResponseMessage> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            try
            {
                // allow link url & hash to be set through a query string for testing
                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                dynamic data = JsonConvert.DeserializeObject(requestBody);
                string linkUrl = req.Query["linkUrl"];
                linkUrl = (linkUrl ?? data?.linkUrl) ?? "https://dwdev365.sharepoint.com/sites/beezytest/SitePages/spa.aspx";
                string linkHash = req.Query["linkHash"];
                linkHash = (linkHash ?? data?.linkHash);

                // get the authenticated user e.g. jim.griffiths@dwdev365.onmicrosoft.com
                // ClaimsPrincipal authUser = req.HttpContext.User;
                // string authUserName = authUser?.Identity?.Name;
                // bool requestIsAuthenticated = req.HttpContext.User.Identity.IsAuthenticated;

                // get the access token for this request
                string authHeader = req.Headers["Authorization"];
                string accessToken = string.IsNullOrEmpty(authHeader) ? "" : authHeader.Substring("Bearer ".Length);

                // for debug testing only
                // accessToken = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Im5PbzNaRHJPRFhFSzFqS1doWHNsSFJfS1hFZyIsImtpZCI6Im5PbzNaRHJPRFhFSzFqS1doWHNsSFJfS1hFZyJ9.eyJhdWQiOiJodHRwczovL2Z1bmMtamltLWNzeC5henVyZXdlYnNpdGVzLm5ldCIsImlzcyI6Imh0dHBzOi8vc3RzLndpbmRvd3MubmV0LzYwZjAwNDhlLTEzYTctNGM0MC04ZjQ0LTcxNDRhMDA3NGNjZS8iLCJpYXQiOjE2MjkxOTg5MTcsIm5iZiI6MTYyOTE5ODkxNywiZXhwIjoxNjI5MjAyODE3LCJhY3IiOiIxIiwiYWlvIjoiQVRRQXkvOFRBQUFBKzBpbmkzRVdYQ0YxeVY1Q2RnTXhFYWpIT0dwRi80SlN1U25SUWl6TTBjbThyVFNZd1pmd1FqaHA4cGVjdENjUiIsImFtciI6WyJwd2QiXSwiYXBwaWQiOiI1YmJmNGRmYy0wZjc5LTRkMDktOWYwMS1mMWYwODM3MzU4YmUiLCJhcHBpZGFjciI6IjAiLCJmYW1pbHlfbmFtZSI6IkdyaWZmaXRocyIsImdpdmVuX25hbWUiOiJKaW0iLCJpcGFkZHIiOiIyMTIuMTU5Ljc4LjI0IiwibmFtZSI6IkppbSBHcmlmZml0aHMiLCJvaWQiOiIwYWM1NTIxOS05MzNmLTRiMzItODA5Zi1lYjc3OGRkODM1ZGUiLCJyaCI6IjAuQVM4QWpnVHdZS2NUUUV5UFJIRkVvQWRNenZ4TnYxdDVEd2xObndIeDhJTnpXTDR2QURZLiIsInNjcCI6InVzZXJfaW1wZXJzb25hdGlvbiIsInN1YiI6IlR0bjJUenZ4TzZDSmw1bUlfblJBWE9TWTBQUVJPY0NRREI4WE1Gc3o4X28iLCJ0aWQiOiI2MGYwMDQ4ZS0xM2E3LTRjNDAtOGY0NC03MTQ0YTAwNzRjY2UiLCJ1bmlxdWVfbmFtZSI6ImppbS5ncmlmZml0aHNAZHdkZXYzNjUub25taWNyb3NvZnQuY29tIiwidXBuIjoiamltLmdyaWZmaXRoc0Bkd2RldjM2NS5vbm1pY3Jvc29mdC5jb20iLCJ1dGkiOiJVTl8wcDUyT2owdWFMM3BFcGVWX0FBIiwidmVyIjoiMS4wIn0.cmdvS56tGIqtaKnKFNVdODe_lpDNfaAEBFVPxVnDI-bj3xuyBu48m4ViAAIrx0sMOG1F8Q6YsxQA3BmRSwI_TXvfCw_gg3PL7m4WCosfPj31F-bEKJMM7lIenWniSCeFfTkQ5_1TGrJNsm3kL6YTwvWl81wKstLUlsckZsrohZpr6AalvKbCGYXe2WQjdh8BUlRLbIWuCHtkFxNb7ytxJ0fHZLBYjDt86QscluY3bPNC5lLVUfR0HkWpN9LjtYhtj_73VNF_M0Sp5IdJotjjcEO0KlFtPzxpBzGbKb3p7RvDX_trJ_dGP7rrYHfM7NnCcjXw28okgkIxW4XruRQl8w";

                // get the authenticated user profile from the graph service
                // we need to get the user employee ID as this will be used to call ServiceNow / Fusion etc
                // can get the OBO token used with _graphDataService.GetOnBehalfOfAccessToken()
                _graphDataService.SetInitialAccessToken(accessToken);
                var user = await _graphDataService.GetUser();

                // create an activity card for this user
                // output the user display name & employee ID to show that we have got them
                string cardLinkUrl = $"{linkUrl}#{linkHash}";
                string activityId = await _beezyDataService.CreateActivityCard(user.UserPrincipalName, "ServiceNow", "SERVICE NOW", $"Test activity card created for {user.DisplayName} ({user.EmployeeId})", "", cardLinkUrl);

                // provide a response (useful for testing)
                var response = new HttpResponseMessage(HttpStatusCode.OK);
                response.Content = new StringContent($"Activity Id: {activityId} ({cardLinkUrl}) created for User: {user.DisplayName} ({user.UserPrincipalName}) with ID: {user.EmployeeId}", System.Text.Encoding.UTF8, "application/json");
                return response;
            }
            catch (Exception ex)
            {
                var response = new HttpResponseMessage(HttpStatusCode.InternalServerError);
                response.Content = new StringContent(ex.ToString(), System.Text.Encoding.UTF8, "text/plain");
                return response;
            }
        }
    }
}
