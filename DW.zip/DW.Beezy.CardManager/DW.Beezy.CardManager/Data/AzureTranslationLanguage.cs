﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DW.Beezy.CardManager.Data
{
    public class AzureTranslationLanguage
    {
        public string Language { get; set; }

        public float Score { get; set; }

        public bool IsTranslationSupported { get; set; }

        public bool isTransliterationSupported { get; set; }
    }
}
