﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace DW.Beezy.CardManager.Data
{
    public class AzureTranslations
    {
        public List<AzureTranslation> Translations { get; set; }
    }

    public class AzureTranslation
    {
        public string Text { get; set; }

        [JsonProperty("To")]
        public string Language { get; set; }
    }
}
