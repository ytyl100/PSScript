﻿using DW.Beezy.CardManager.Authentication;
using DW.Beezy.CardManager.Services;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Graph;
using System;
using System.Collections.Generic;
using System.Text;

// To register the method, add the FunctionsStartup assembly attribute that specifies the type name used during startup
// Add nuget package Microsoft.Azure.Functions.Extensions
[assembly: FunctionsStartup(typeof(DW.Beezy.CardManager.Startup))]

namespace DW.Beezy.CardManager
{
    public class Startup : FunctionsStartup
    {
        private IConfigurationRoot configurationSettings;

        public Startup()
        {
            // read configuration values from local settings json & environment variables
            configurationSettings = new ConfigurationBuilder()
                .AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
                .AddEnvironmentVariables()
                .Build();
        }

        // NOTE: the following settings should be defined in the function app configuration using a key vault reference
        // NOTE: this requires function app authentication to key vault using a system managed identity
        // AppRegistrationClientSecret: @Microsoft.KeyVault(SecretUri=https://kv-beezy-card-manager.vault.azure.net/secrets/AppRegistrationClientSecret/)
        // ServiceAccount: @Microsoft.KeyVault(SecretUri=https://kv-beezy-card-manager.vault.azure.net/secrets/ServiceAccount/)
        // ServiceAccountPassword: @Microsoft.KeyVault(SecretUri=https://kv-beezy-card-manager.vault.azure.net/secrets/ServiceAccountPassword/)
        public override void Configure(IFunctionsHostBuilder builder)
        {
            // beezy data service
            // need these definitions otherwise these components will share the same HttpClient (which will not work as they need to request their own access tokens)
            // this call removes the need for a separate AddTransient() call for each of the data access components
            // requires NuGet extension Microsoft.Extensions.Http (version 2) - this is included in Microsoft.Azure.WebJobs.Extensions.DurableTask
            builder.Services.AddHttpClient<IBeezyDataService, BeezyDataService>();
            builder.Services.AddSingleton(configurationSettings.Get<BeezyDataServiceSettings>());

            // graph data service (does not use HttpClient)
            builder.Services.AddSingleton<IGraphDataService, GraphDataService>();
            builder.Services.AddSingleton(configurationSettings.Get<GraphDataServiceSettings>());

            // user access token retrieval
            // the app registration which we are using for the username / password authentication flow required to call the beezy API
            // also contains app registration secret and username / password for the service account
            builder.Services.AddSingleton<UserTokenClient, UserTokenClient>();
            builder.Services.AddSingleton(configurationSettings.Get<UserTokenClientSettings>());

            // on behalf of access token retrieval
            // uses the back end app registration
            builder.Services.AddSingleton<OnBehalfOfAuthProvider, OnBehalfOfAuthProvider>();
            builder.Services.AddSingleton(configurationSettings.Get<OnBehalfOfAuthProviderSettings>());

            // azure translation
            builder.Services.AddSingleton<TranslationTokenProvider, TranslationTokenProvider>();
            builder.Services.AddSingleton(configurationSettings.Get<TranslationTokenProviderSettings>());
            builder.Services.AddHttpClient<IAzureTranslationService, AzureTranslationService>();
            builder.Services.AddSingleton(configurationSettings.Get<AzureTranslationServiceSettings>());
        }
    }
}

