﻿using Microsoft.Graph;
using Microsoft.Identity.Client;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace DW.Beezy.CardManager.Authentication
{
    public class OnBehalfOfAuthProviderSettings
    {
        public string TenantId { get; set; }

        public string OnBehalfOfUserAuthAppClientId { get; set; }

        public string OnBehalfOfUserAuthAppClientSecret { get; set; }
    }

    public class OnBehalfOfAuthProvider : IAuthenticationProvider
    {
        private readonly OnBehalfOfAuthProviderSettings _settings;

        public string Scope { get; set; }

        public string InitialAccessToken { get; set; }

        public string OnBehalfOfAccessToken { get; set; }

        public OnBehalfOfAuthProvider(OnBehalfOfAuthProviderSettings settings)
        {
            _settings = settings;
        }

        public async Task AuthenticateRequestAsync(HttpRequestMessage request)
        {
            var app = ConfidentialClientApplicationBuilder
                .Create(_settings.OnBehalfOfUserAuthAppClientId)
                .WithTenantId(_settings.TenantId)
                .WithClientSecret(_settings.OnBehalfOfUserAuthAppClientSecret)
                .Build();

            AuthenticationResult result = await app.AcquireTokenOnBehalfOf(new string[] { Scope }, new UserAssertion(InitialAccessToken)).ExecuteAsync();
            OnBehalfOfAccessToken = result.AccessToken;
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", OnBehalfOfAccessToken);
        }
    }
}
