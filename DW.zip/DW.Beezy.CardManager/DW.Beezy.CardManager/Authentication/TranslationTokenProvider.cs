﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DW.Beezy.CardManager.Authentication
{
    public class TranslationTokenProviderSettings
    {
    }

    public class TranslationTokenProvider : ITokenClient
    {
        public Task<string> GetTokenAsync(IEnumerable<string> scopes)
        {
            return Task.FromResult(string.Empty);
        }
    }
}
