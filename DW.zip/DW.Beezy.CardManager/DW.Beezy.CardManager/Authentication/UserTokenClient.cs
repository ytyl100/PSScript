﻿using Microsoft.Identity.Client;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace DW.Beezy.CardManager.Authentication
{
    // APP REGISTRATION:
    // - Allow Public Client Flows (Manage > Authentication > Advanced Settings)
    // - Create Client Secret (Manage > Certificates & secrets)
    // - Microsoft.Graph User.Read Delegated permission (Manage > API Permissions)
    public class UserTokenClientSettings
    {
        public string TenantId { get; set; }

        public string ServiceAccountAuthAppClientId { get; set; }

        public string ServiceAccountAuthAppClientSecret { get; set; }

        public string ServiceAccount { get; set; }

        public string ServiceAccountPassword { get; set; }
    }

    public class UserTokenClient : ITokenClient
    {
        private readonly UserTokenClientSettings _settings;

        public UserTokenClient(UserTokenClientSettings settings)
        {
            _settings = settings;
        }

        public async Task<string> GetTokenAsync(IEnumerable<string> scopes)
        {
            var app = PublicClientApplicationBuilder
                .Create(_settings.ServiceAccountAuthAppClientId)
                .WithTenantId(_settings.TenantId)
                .WithExtraQueryParameters($"client_secret={_settings.ServiceAccountAuthAppClientSecret}")
                .Build();

            AuthenticationResult result = await app.AcquireTokenByUsernamePassword(scopes, _settings.ServiceAccount, new NetworkCredential(string.Empty, _settings.ServiceAccountPassword).SecurePassword).ExecuteAsync();
            var userToken = result.AccessToken;
            return userToken;
        }
    }
}
