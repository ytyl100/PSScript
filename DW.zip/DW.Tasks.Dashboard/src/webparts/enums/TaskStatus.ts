export enum TaskStatus{
    Open,
    Approved,
    Rejected
}