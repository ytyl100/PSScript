import { ITask } from "./ITask";

export interface ITaskData {
  tasks: ITask[];
}
