export interface ITaskListItem {
  key: number;
  title: string;
  id: number;
}
