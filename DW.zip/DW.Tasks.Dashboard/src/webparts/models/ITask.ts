export interface ITask {
  id: number;
  title: string;
}
