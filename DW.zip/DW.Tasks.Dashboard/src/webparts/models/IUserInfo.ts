export interface IUserInfo {
  userName: string;
  email: string;
}
