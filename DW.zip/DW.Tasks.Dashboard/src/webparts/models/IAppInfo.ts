export interface IAppInfo {
  code: string;
  name: string;
  taskUrl: string;
}
