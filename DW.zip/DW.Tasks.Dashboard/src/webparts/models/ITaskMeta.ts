export interface ITaskMeta{
    id:number;
    title:string;
}