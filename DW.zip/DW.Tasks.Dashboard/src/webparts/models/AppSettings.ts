export class AppSettings {
  constructor(
    public name: string,
    public code: string,
    public description: string,
    public iconName: string
  ) {}
}
