import { Guid } from "@microsoft/sp-core-library";
import { TaskStatus } from "../enums/TaskStatus";
import { IAppInfo } from "./IAppInfo";
import { IUserInfo } from "./IUserInfo";

export interface ITaskInfo{
    id:Guid;
    assignedTo: IUserInfo;
    app:IAppInfo;
    taskId:number;
    title:string;
    description:string;
    region:string;
    taskNumber:string;
    created:Date;
    createdBy:IUserInfo;
    dueDate:Date;
    status: TaskStatus;
}