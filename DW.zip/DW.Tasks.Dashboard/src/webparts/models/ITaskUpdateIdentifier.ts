import { Guid } from "@microsoft/sp-core-library";

export interface ITaskUpdateIdentifier{
    id: string;
    upn: string;
    status: number;
}