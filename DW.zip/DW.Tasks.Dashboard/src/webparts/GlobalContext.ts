import { createContext, useContext } from "react";
import { ITaskInfo } from "./models/ITaskInfo";
import { GlobalContent } from "./types/GlobalContent";

export const GlobalContext = createContext<GlobalContent>({
  userName: "",
  setUserName: () => {},
  tasks: [],
  setTasks: (tasks: ITaskInfo[]) => {
    console.warn("Global Content: set Tasks", tasks);
  },
  apps: [],
  tasksService: null
});

export const useGlobalContext = () => useContext(GlobalContext);
