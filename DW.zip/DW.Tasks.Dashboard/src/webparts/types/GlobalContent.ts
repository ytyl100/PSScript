import { AppSettings } from "../models/AppSettings";
import { ITaskInfo } from "../models/ITaskInfo";
import { ITaskService } from "../services/ITaskService";

export type GlobalContent = {
  userName: string;
  setUserName: (userName: string) => void;
  tasks: ITaskInfo[];
  setTasks: (tasks: ITaskInfo[]) => void;
  apps: AppSettings[];
  tasksService: ITaskService;
};
