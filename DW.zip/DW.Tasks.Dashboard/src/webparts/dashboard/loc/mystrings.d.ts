declare interface IDashboardWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  TaskManagerApiUrlFieldLabel:string;
  DWLandingPageUrlFieldLabel:string;
  ApplicationIdFieldLabel:string;
}

declare module 'DashboardWebPartStrings' {
  const strings: IDashboardWebPartStrings;
  export = strings;
}
