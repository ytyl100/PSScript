define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    "TaskManagerApiUrlFieldLabel": "Task Manager Api Url",
    "DWLandingPageUrlFieldLabel" : "Digital Workplace Landing Page Url",
    "ApplicationIdFieldLabel":"Application Registration Id"
  }
});