import * as React from "react";
import { useState } from "react";
import { useGlobalContext } from "../../../GlobalContext";
import AppCard from "../AppCard/AppCard";
import { IAppCardProps } from "../AppCard/IAppCardProps";
import { DocumentCardImageExample } from "../DocumentCardExamples/DocumentCardImageExample";

export default function HomePage() {
  const { apps, tasks } = useGlobalContext();
  const [numberOfTasks] = useState(10);

  return (
    <div className="ms-Grid">
      <div className="ms-Grid-row">
        <div className="ms-Grid-col ms-sm12">
          <h1>Dashboard</h1>
        </div>
      </div>

      <div className="ms-Grid-row">
        {apps.map((app) => {
          let n: number = tasks.filter((t) => t.app.code === app.code).length;
          const appCardProps : IAppCardProps = {
            app: app,
            numberOfTasks: n,
          };

          return (
            <div key={app.code} className="ms-Grid-col ms-sm12 ms-md6 ms-lg-3">
              {/* <AppCard app={app} numberOfTasks={n}></AppCard> */}
              <DocumentCardImageExample app={appCardProps.app} numberOfTasks={appCardProps.numberOfTasks}></DocumentCardImageExample>
            </div>
          );
        })}
      </div>
    </div>
  );
}
