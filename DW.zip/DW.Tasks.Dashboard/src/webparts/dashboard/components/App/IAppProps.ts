import { WebPartContext } from "@microsoft/sp-webpart-base";
import { ITaskInfo } from "../../../models/ITaskInfo";
import { ITaskService } from "../../../services/ITaskService";

export interface IAppProps {
  taskService: ITaskService;
  description: string;
  context: WebPartContext;
  userName: string;
  siteUrl?: string;
  Urlvalue?: string;
  referrerUrl?: string;
}
