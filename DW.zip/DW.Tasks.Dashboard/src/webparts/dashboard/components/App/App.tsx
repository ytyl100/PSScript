import * as React from "react";
import styles from "./App.module.scss";
import { IAppProps } from "./IAppProps";

import { HashRouter } from "react-router-dom";

import Footer from "../Footer/Footer";

import Main from "../Main/Main";
import Header from "../Header/Header";
import { GlobalContext } from "../../../GlobalContext";
import { useEffect, useState } from "react";
import { ITaskInfo } from "../../../models/ITaskInfo";
import { AppSettings } from "../../../models/AppSettings";
import { IHeaderProps } from "../Header/IHeaderProps";
import Loading from "../Loading/Loading";
import ErrorBoundary from "../ErrorBoundary/ErrorBoundary";
import { ITaskService } from "../../../services/ITaskService";

require("./../Styles/dw.css");

export default function App(props: IAppProps) {
  const [userName, setUserName] = useState<string>(props.userName);
  const [apps, setApps] = useState<AppSettings[]>([]);
  const [tasks, setTasks] = useState<ITaskInfo[]>([]);
  const [loaded, setLoaded] = useState<boolean>(false);
  const [tasksService] = useState<ITaskService>(props.taskService);

  const fetchAppsDataAsync = async () => {
    var allApps = await props.taskService.getApps();
    setApps(allApps);
    console.log("fetchAppsDataAsync finished");
  };

  const fetchTasksDataAsync = async () => {
    var allTasks = await props.taskService.getTasks();
    setTasks(allTasks);
    setLoaded(true);
    console.log("fetchTasksDataAsync finished");
  };

  useEffect(() => {
    console.log("App useEffect");

    fetchAppsDataAsync().then(() =>
      fetchTasksDataAsync().then(() => {
        // const interval = setInterval(() => {
        //   console.log('fetch task data async. . ...');
        //   fetchTasksDataAsync();
        // }, 60000);
      })
    );
  }, []);

  const headerProps: IHeaderProps = {
    backLink: props.referrerUrl,
  };

  return (
    <React.StrictMode>
      <GlobalContext.Provider
        value={{
          userName,
          setUserName,
          tasks,
          setTasks,
          apps,
          tasksService
        }}
      >
        <ErrorBoundary>
          <div className={styles.app}>
            <HashRouter>
              <Header backLink={headerProps.backLink}></Header>
              {/* <AppMessageBar></AppMessageBar> */}
              {loaded ? <Main></Main> : <Loading></Loading>}
              {/* <Footer></Footer> */}
            </HashRouter>
          </div>
        </ErrorBoundary>
      </GlobalContext.Provider>
    </React.StrictMode>
  );
}
