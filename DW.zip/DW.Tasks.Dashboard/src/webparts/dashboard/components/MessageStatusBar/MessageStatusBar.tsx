import * as React from "react";
import {
  MessageBar,
  MessageBarType,
  Toggle,
  Text,
  mergeStyles,
} from "office-ui-fabric-react";
import { useBoolean } from "@uifabric/react-hooks";

const wrapperClass = mergeStyles({
  "> *:not(:last-child)": { marginBottom: "1.5em" },
  "> * > *:not(:last-child)": { marginBottom: "0.5em" },
});

export const MessageStatusBar: React.FunctionComponent = () => {
  const [showAlert, { toggle: toggleShowAlert }] = useBoolean(false);
  const [showStatus, { toggle: toggleShowStatus }] = useBoolean(false);

  return (
    <div className={wrapperClass}>
      <Text block>Test Text Block</Text>
      <div>
        <Toggle
          inlineLabel
          label="Show alert example"
          checked={showAlert}
          onChange={toggleShowAlert}
        />
      </div>
    </div>
  );
};
