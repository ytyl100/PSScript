import * as React from "react";
import { Link } from "react-router-dom";
import { IAppProps } from "../App/IAppProps";
import styles from "./Footer.module.scss";

const Footer = () => {
  return (
    <footer className={styles.footer}>
      <div className="ms-Grid dw-container">
        <div className="ms-Grid-row">
          <div className="ms-Grid-col ms-sm12">
            <nav>
              <ul>
                <li>
                  <Link to="/">Home 123</Link>
                </li>
                <li>
                  <Link to="/tasks">Tasks</Link>
                </li>
                <li>
                  <Link to="/2">2</Link>
                </li>
                <li>
                  <Link to="/3">3</Link>
                </li>
              </ul>
            </nav>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
