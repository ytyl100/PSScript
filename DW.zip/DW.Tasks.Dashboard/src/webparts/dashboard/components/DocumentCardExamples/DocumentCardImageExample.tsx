import * as React from "react";
import {
  DocumentCard,
  DocumentCardActivity,
  DocumentCardTitle,
  DocumentCardDetails,
  DocumentCardImage,
  IDocumentCardStyles,
  IDocumentCardActivityPerson,
  DocumentCardActions,
} from "office-ui-fabric-react/lib/DocumentCard";
import { IIconProps } from "office-ui-fabric-react/lib/Icon";
import { ImageFit } from "office-ui-fabric-react/lib/Image";
import { TestImages } from "office-ui-fabric-react/lib/common/TestImages";
import { IAppCardProps } from "../AppCard/IAppCardProps";

const people: IDocumentCardActivityPerson[] = [
  { name: "Test User 1", profileImageSrc: TestImages.personaFemale },
  { name: "Test User 2", profileImageSrc: "", initials: "RK" },
  { name: "Test User 3", profileImageSrc: TestImages.personaMale },
  { name: "Test User 4", profileImageSrc: "", initials: "CB" },
];

export const DocumentCardImageExample: React.FunctionComponent<IAppCardProps> = ({app,numberOfTasks}:IAppCardProps) => {

  const oneNoteIconProps: IIconProps = {
    iconName: app.iconName,
    styles: {
      root: { color: "#4560EB", fontSize: "60px", width: "60px", height: "60px" },
    },
  };
  

  const cardStyles: IDocumentCardStyles = {
    root: {
      display: "inline-block",
      marginBottom: 20,
      width: "100%",
      maxWidth: "100%",
      minWidth: "100%",
    },
  };

  const onActionClick = (action: string, ev: React.SyntheticEvent<HTMLElement>): void => {
    console.log(`You clicked the ${action} action`);
    ev.stopPropagation();
    ev.preventDefault();
  };
  const documentCardActions = [
    {
      iconProps: { iconName: 'Share' },
      onClick: onActionClick.bind(this, 'share'),
      ariaLabel: 'share action',
    },
    {
      iconProps: { iconName: 'Pin' },
      onClick: onActionClick.bind(this, 'pin'),
      ariaLabel: 'pin action',
    },
    {
      iconProps: { iconName: 'Ringer' },
      onClick: onActionClick.bind(this, 'notifications'),
      ariaLabel: 'notifications action',
    },
  ];

  const description: string = `My ${app.name} tasks and notifications`;

  return (
    
    <div>
      <DocumentCard styles={cardStyles} onClickHref={`#/tasks/${app.code}`}>
        <DocumentCardImage
          height={100}
          imageFit={ImageFit.centerCover}
          iconProps={oneNoteIconProps}
        />
        <DocumentCardDetails>
          <DocumentCardTitle title={description} shouldTruncate />
        </DocumentCardDetails>
        <DocumentCardActions actions={documentCardActions} views={numberOfTasks}>

        </DocumentCardActions>
        {/* <DocumentCardActivity
          activity="There are X number of tasks waiting for approval"
          people={[people[3]]}
        /> */}
      </DocumentCard>
    </div>
  );
};
