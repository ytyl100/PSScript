import { AppSettings } from "../../../models/AppSettings";

export interface IAppCardProps{
    app: AppSettings;
    numberOfTasks: number;
}