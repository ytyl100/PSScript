import * as React from "react";
import { useEffect } from "react";
import { IAppCardProps } from "./IAppCardProps";

import {
  DocumentCard,
  DocumentCardTitle,
  DocumentCardLocation,
  DocumentCardActions,
  IDocumentCardLogoProps,
  IDocumentCardStyles,
  DocumentCardLogo,
} from "office-ui-fabric-react/lib/DocumentCard";

export default function AppCard(props: IAppCardProps) {
  const logoProps: IDocumentCardLogoProps = {
    logoIcon: props.app.iconName,
  };

  const cardStyles: IDocumentCardStyles = {
    root: { display: "inline-block", marginRight: 20, width: '100%', minWidth: '100%', maxWidth: '100%' },
  };

  const documentCardActions = [];

  useEffect(() => {}, []);

  return (
    <DocumentCard styles={cardStyles}>
      <DocumentCardLogo {...logoProps} />
      <DocumentCardLocation
        location={`${props.app.name} tasks`}
        locationHref={`#/tasks/${props.app.code}`}
      />      
      <DocumentCardTitle title={`${props.app.description}`}></DocumentCardTitle>
      <DocumentCardActions
        actions={documentCardActions}
        views={props.numberOfTasks}
      />
    </DocumentCard>
  );
}
