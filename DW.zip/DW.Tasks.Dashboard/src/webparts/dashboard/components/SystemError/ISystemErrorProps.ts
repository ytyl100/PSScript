export interface ISystemErrorProps {
    error:Error;
}