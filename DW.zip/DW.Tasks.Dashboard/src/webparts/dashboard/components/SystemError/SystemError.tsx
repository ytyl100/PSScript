import * as React from "react";
import { ISystemErrorProps } from "./ISystemErrorProps";

export default function SystemError({error}: ISystemErrorProps){
    console.warn('System Error: ', error);
    return (
        <React.StrictMode>
            <div>Error: {error.message}</div>
        </React.StrictMode>
    );
}