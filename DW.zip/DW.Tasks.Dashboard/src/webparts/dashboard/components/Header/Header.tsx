import * as React from "react";
import { Link } from "react-router-dom";
import { useGlobalContext } from "../../../GlobalContext";
import { IAppProps } from "../App/IAppProps";

import {
  CommandBar,
  ICommandBarItemProps,
} from "office-ui-fabric-react/lib/CommandBar";
import { IButtonProps } from "office-ui-fabric-react/lib/Button";
import styles from "./Header.module.scss";

import {
  Nav,
  initializeIcons,
  IContextualMenuItemStyles,
  IContextualMenuStyles,
  IStyleFunctionOrObject,
} from "office-ui-fabric-react";
import { AppSettings } from "../../../models/AppSettings";
import { IHeaderProps } from "./IHeaderProps";

export default function Header({backLink}:IHeaderProps) {
  const { userName, tasks, apps } = useGlobalContext();


  console.warn('header component back link property: ', backLink);
  initializeIcons();

  const itemStyles: Partial<IContextualMenuItemStyles> = {
    label: {},
    icon: { color: "red" },
    iconHovered: { color: "green" },
  };

  // For passing the styles through to the context menus
  const menuStyles: Partial<IContextualMenuStyles> = {
    root: {
      fontSize: 24,
      backgroundColor: "transparent",
      paddingLeft: 0,
      paddingRight: 0,
    },
    subComponentStyles: { menuItem: itemStyles, callout: {} },
  };

  const buttonStylesLeft = {

    icon: {
      color: "white",
      fontSize: 24,
    },
    iconHovered: { color: "#FFFFFF" },
    root: {
      background: "transparent",
      color: "#FFFFFF",
      paddingRight: 12,
      fontSize:16,      
    },
    rootHovered: {
      background: "#384EA3",
      color: "#FFFFFF",
    },
  };

  const buttonStylesRight = {

    icon: {
      color: "white",
      fontSize: 24,
    },
    iconHovered: { color: "#FFFFFF" },
    root: {
      background: "transparent",
      color: "#FFFFFF",
      paddingRight: 0,
      fontSize:16,      
    },
    rootHovered: {
      background: "#384EA3",
      color: "#FFFFFF",
    },
  };


  const _items: ICommandBarItemProps[] = [
    {
      key: "home",
      text: "Home",
      iconProps: { iconName: "Home" },
      href: backLink,
      buttonStyles: buttonStylesLeft,
    },
    {
      key: "dashboard",
      text: "Dashboard",
      iconProps: { iconName: "BarChartVertical" },
      href: "#/",
      buttonStyles: buttonStylesLeft,
    },
  ];

  const _farItems: ICommandBarItemProps[] = [
    // {
    //   key: "tile",
    //   text: "Grid view",
    //   // This needs an ariaLabel since it's icon-only
    //   ariaLabel: "Grid view",
    //   iconOnly: true,
    //   iconProps: { iconName: "Tiles" },
    //   onClick: () => console.log("Tiles"),
    //   buttonStyles: buttonStyles,
    // },
    {
      key: "info",
      text: "Info",
      // This needs an ariaLabel since it's icon-only
      ariaLabel: "Info",
      iconOnly: true,
      iconProps: { iconName: "Info" },
      onClick: () => console.log("Info"),
      buttonStyles: buttonStylesRight,
    },
  ];

  apps.map((app: AppSettings) => {
    console.log(app);
    _items.push({
      key: app.code,
      text: app.name,
      iconProps: { iconName: app.iconName },
      href: `#/tasks/${app.code}`,
      buttonStyles: buttonStylesLeft,
    });
  });

  return (
    <header className={styles.header}>
      <div className="ms-Grid dw-container">
        <div className="ms-Grid-row">
          <div className="ms-Grid-col ms-sm12">
            <div className="dw-header-padding">
              <CommandBar
                items={_items}
                farItems={_farItems}
                styles={menuStyles}
              />
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
