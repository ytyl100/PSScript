export interface IAppTasksProps{
    code:string;
    title:string;
}