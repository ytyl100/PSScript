import {
  Announced,
  DetailsList,
  DetailsListLayoutMode,
  IColumn,
  SelectionMode,
  Text,
} from "office-ui-fabric-react";
import * as React from "react";
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { TaskStatus } from "../../../enums/TaskStatus";
import { useGlobalContext } from "../../../GlobalContext";
import { AppSettings } from "../../../models/AppSettings";
import { ITaskInfo } from "../../../models/ITaskInfo";
import { ITaskListItem } from "../../../models/ITaskListItem";
import { IAppTasksProps } from "./IAppTasksProps";

export default function AppTasks(props: IAppTasksProps) {
  const { tasks, apps } = useGlobalContext();

  const [appTasks, setAppTasks] = useState<ITaskInfo[]>([]);
  const [currentAppLabel, setCurrentAppLabel] = useState<string>("");

  // const [items, setItems] = useState<ITaskListItem[]>([]);

  useEffect(() => {
    console.log("App Tasks useEffect");

    const c = apps.filter(cc => cc.code === props.code);
    if(c.length !== 0){
      setCurrentAppLabel(c[0].name);
    }

    const t = tasks.filter((ts) => ts.app.code === props.code);
    setAppTasks(t);
  }, [tasks]);

  const _columns: IColumn[] = [
    {
      key: "taskNumber",
      name: "Task No",
      fieldName: "taskNumber",
      minWidth: 80,
      maxWidth: 90,
    },    {
      key: "title",
      name: "Title",
      fieldName: "title",
      minWidth: 120
    },
    {
      key: "createdBy",
      name: "Created By",
      fieldName: "createdBy.userName",
      minWidth:100,
      maxWidth:100,
      onRender:(itm: ITaskInfo) => {
        return itm.createdBy.userName;
      },
    },
    {
      key: "region",
      name: "Region",
      fieldName: "region",
      minWidth: 80,
      maxWidth:100,
    },
    {
      key: "dueDate",
      name: "Due Date",
      fieldName: "dueDate",
      minWidth: 100,
      maxWidth: 100,
      onRender: (itm: ITaskInfo) => {
        let ds: any = itm.dueDate;

        return new Date(ds).toDateString();
      },
    },
    {
      key: "status",
      name: "Status",
      fieldName: "status",
      minWidth: 80,
      maxWidth: 80,
      onRender: (itm : ITaskInfo) => {
        switch(itm.status){
          case TaskStatus.Open:
            return "Open";
          case TaskStatus.Approved:
            return "Approved";
          case TaskStatus.Rejected:
            return "Rejected";
          default:
            return "Unknown";
        }
      },
    },
  ];

  return (
    <div className="ms-Grid">
      <div className="ms-Grid-row">
        <div className="ms-Grid-col ms-sm12">
          <h1>{currentAppLabel} Tasks</h1>
        </div>
      </div>
      <div className="ms-Grid-row">
        <div className="ms-Grid-col ms-sm12">
          <DetailsList
            items={appTasks}
            columns={_columns}
            onRenderItemColumn={(
              item: ITaskInfo,
              index: number,
              column: IColumn
            ) => {
              console.log("render item column");
              const fieldContent = item[
                column.fieldName as keyof ITaskInfo
              ] as string;

              switch (column.key) {
                case "taskNumber":
                  return (
                    <Link to={`/tasks/${item.app.code}/${item.taskId}`}>
                      {fieldContent}
                    </Link>
                  );
                default:
                  return <span>{fieldContent}</span>;
              }
            }}
            layoutMode={DetailsListLayoutMode.justified} 
            selectionMode={SelectionMode.none}
            onItemInvoked={(item, index) =>
              alert(`Item ${item.name} at index ${index} has been invoked.`)
            }
          ></DetailsList>
        </div>
      </div>
    </div>
  );
}
