import * as React from "react";
import { Link } from "react-router-dom";

const Tasks = () => (
  <div>
    <div>tasks.....</div>
    <ul>
      <li>
        <Link to="/tasks/1">Task 1</Link>
      </li>
      <li>
        <Link to="/tasks/2">Task 2</Link>
      </li>
      <li>
        <Link to="/tasks/100">Task 100</Link>
      </li>
    </ul>
  </div>
);

export default Tasks;
