import { IStackTokens, Label, Spinner, SpinnerSize, Stack } from "office-ui-fabric-react";
import * as React from "react";


const Loading: React.FunctionComponent = () => {
  const stackTokens: IStackTokens = {
    childrenGap: 20,
  };

  return (
    <Stack tokens={stackTokens}>

      <div>
        <Spinner label="Loading..." ariaLive="assertive" labelPosition="top" size={SpinnerSize.large} />
      </div>

    </Stack>
  );
};

// const Loading = () => {
//   return (
//       <div>Please wait while data is loaded ...
//       </div>
//   );
// };

 export default Loading;