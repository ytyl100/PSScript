import * as React from "react";
import { Route, Switch } from "react-router-dom";
import HomePage from "../HomePage/HomePage";
import { MessageStatusBar } from "../MessageStatusBar/MessageStatusBar";
import TasksPage from "../TasksPage/TasksPage";

import styles from "./Main.module.scss";

const Main = () => (
  <main className={styles.main}>
    <div className="ms-Grid dw-container">
      <div className="ms-Grid-row">
        <div className="ms-Grid-col ms-sm12">
          {/* <div>
            <MessageStatusBar></MessageStatusBar>
          </div> */}
          <Switch>
            <Route exact path="/" component={HomePage} />
            <Route path="/tasks" component={TasksPage} />
          </Switch>
        </div>
      </div>
    </div>
  </main>
);

export default Main;
