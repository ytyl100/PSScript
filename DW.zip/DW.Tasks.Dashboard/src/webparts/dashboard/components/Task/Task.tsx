import {
  DefaultButton,
  IStackTokens,
  Label,
  PrimaryButton,
  Stack,
  TextField,
} from "office-ui-fabric-react";
import * as React from "react";
import { useHistory } from 'react-router-dom';
import { useState, useEffect } from "react";
import { useGlobalContext } from "../../../GlobalContext";
import { ITaskInfo } from "../../../models/ITaskInfo";

import { ITaskProps } from "./ITaskProps";


export default function Task({ task }: ITaskProps) {
  const stackTokens: IStackTokens = { childrenGap: 10 };

  const dueDateString: string = new Date(task.dueDate as any).toDateString();
  const createdString: string = new Date(task.created as any).toDateString();

  const { tasksService, setTasks } = useGlobalContext();  

  const history = useHistory();

  useEffect(() => {
    console.warn('useeffect empty array......');
  },[]);

  useEffect(() => {
    console.log('use Effect task: ', task);
  }, [task]);

  const fetchTasksDataAsync = async () => {
    var allTasks = await tasksService.getTasks();
    setTasks(allTasks);
    //setLoaded(true);
    console.log("fetchTasksDataAsync finished");
  };

  return (
    <>
      <div className="ms-Grid">
        <div className="ms-Grid-row">
          <div className="ms-Grid-col ms-sm12">
            <h1>Task Details</h1>
          </div>
        </div>
        <div className="ms-Grid-row">
          <div className="ms-Grid-col ms-sm6">
            <TextField
              label="Task No:"
              readOnly
              defaultValue={task.taskNumber}
            />
            <TextField label="Task:" readOnly defaultValue={task.title} />
            <TextField label="App:" readOnly defaultValue={task.app.name} />
            <TextField label="Region:" readOnly defaultValue={task.region} />
            <TextField
              label="Assigned To:"
              readOnly
              defaultValue={task.assignedTo.userName}
            />
            <TextField
              label="Due Date:"
              readOnly
              defaultValue={dueDateString}
            />
            <TextField
              label="Created By:"
              readOnly
              defaultValue={task.createdBy.userName}
            />
            <TextField label="Created:" readOnly defaultValue={createdString} />
          </div>
          <div className="ms-Grid-col ms-sm6">
            <TextField
              label="Description"
              multiline
              rows={6}
              defaultValue={task.description}
            />
            <br></br>
            <hr></hr>
            <br></br>
            <TextField
              label="Comments"
              multiline
              rows={6}
              defaultValue="Your Comments"
            />
            <br></br>
            <hr></hr>
            <br></br>
            <Stack horizontal tokens={stackTokens}>
              <DefaultButton
                text="Approve"
                onClick={async (e) => 
                {
                  await tasksService.updateTask(task.assignedTo.email, task.id, 1);
                  await fetchTasksDataAsync();
                  console.log("Approve", e);

                  // redirect back to the app tasks list
                  history.push(`/tasks/${task.app.code}`);
                }}
              />
              <DefaultButton
                text="Reject"
                onClick={async (e) => 
                  {
                    await tasksService.updateTask(task.assignedTo.email, task.id, 2);
                    await fetchTasksDataAsync();
                    console.log("Reject", e);
  
                  // redirect back to the app tasks list
                  history.push(`/tasks/${task.app.code}`);
                  }}
                />
            </Stack>
          </div>
        </div>
      </div>
    </>
  );
}
