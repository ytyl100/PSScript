import { Guid } from "@microsoft/sp-core-library";
import { ITaskInfo } from "../../../models/ITaskInfo";
import { ITaskMeta } from "../../../models/ITaskMeta";

export interface ITaskProps{
    task: ITaskInfo;
}