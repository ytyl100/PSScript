import { PrimaryButton } from "office-ui-fabric-react/lib/Button";
import * as React from "react";
import { Route, Switch, useParams } from "react-router-dom";
import { useGlobalContext } from "../../../GlobalContext";
import { ITaskInfo } from "../../../models/ITaskInfo";


import { ITaskProps } from "../Task/ITaskProps";
import Task from "../Task/Task";
import AppTasks from "../Tasks/AppTasks";
import { IAppTasksProps } from "../Tasks/IAppTasksProps";
import Tasks from "../Tasks/Tasks";

export default function TasksPage() {
  const { tasks } = useGlobalContext();  

  return (


    <main>
      <Switch>
        <Route exact path="/tasks" component={() => <Tasks></Tasks>}></Route>

        <Route path="/tasks/:app/:id"
          component={() => {
            let { app, id } = useParams();
            console.warn("app and id...: ", app, id);

            // find task
            const match : ITaskInfo[] = tasks.filter(t=>t.app.code === app && t.taskId === parseInt(id));

            if(match.length === 0){
              throw Error('Could not find task');
            }

            const info: ITaskProps = {
              task: match[0]
            };

            return <Task task={info.task}></Task>;
          }}
        />

        <Route
          exact
          path="/tasks/:app"

          component={() => {

            let { app } = useParams();
            console.warn("app and id...: ", app);

            const info: IAppTasksProps = {

              title: `app ${app} task`,
              code: app

            };
            return <AppTasks code={info.code} title={info.title}></AppTasks>;
          }}
        ></Route>
      </Switch>


    </main>
  );
}
