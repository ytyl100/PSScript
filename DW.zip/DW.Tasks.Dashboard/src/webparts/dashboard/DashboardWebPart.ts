import * as React from "react";
import * as ReactDom from "react-dom";
import {
  Log,
  Version,
  Environment,
  EnvironmentType,
} from "@microsoft/sp-core-library";
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField,
} from "@microsoft/sp-property-pane";
import { BaseClientSideWebPart } from "@microsoft/sp-webpart-base";

import * as strings from "DashboardWebPartStrings";

import { IAppProps } from "./components/App/IAppProps";
import App from "./components/App/App";
import { TaskService } from "../services/TaskService";
import { ITaskService } from "../services/ITaskService";
import { MockTaskService } from "../services/MockTaskService";
import { ITaskInfo } from "../models/ITaskInfo";
import { ITokenService } from "../services/ITokenService";
import { TokenService } from "../services/TokenService";
import SystemError from "./components/SystemError/SystemError";
import { ISystemErrorProps } from "./components/SystemError/ISystemErrorProps";

export interface IDashboardWebPartProps {
  description: string;
  taskManagerApiUrl: string;
  dwLandingPageUrl: string;
  applicationId: string;
}

export default class DashboardWebPart extends BaseClientSideWebPart<IDashboardWebPartProps> {
  private _taskService: ITaskService;

  public currentError : Error = null;

  constructor() {
    super();
    console.warn("constructor event....");
  }

  public render(): void {
    console.warn("render event....");
    console.log(Environment.type);

    // var taskService: ITaskService;
    // // if (Environment.type === EnvironmentType.Local) {
    // //   taskService = new MockTaskService();
    // // } else {
    // taskService = new TaskService(
    //   this.context.httpClient,
    //   this.properties.taskManagerApiUrl
    // );
    // }
    console.warn('Dashboard WebPart properties', this.properties);
    console.warn('Dashboard WebPart context', this.context);

    let referrerUrl: string = "";
    console.warn("document referrer: ", document.referrer);
    if (document.referrer) {
      referrerUrl = document.referrer;
    } else {
      referrerUrl = this.properties.dwLandingPageUrl;
    }

    if(this.currentError === null){
      this.renderApp(referrerUrl);
    }else{
      this.renderSystemError();
    }

    // const element: React.ReactElement<IAppProps> = React.createElement(App, {
    //   tasks: this._tasks,
    //   taskService: this._taskService,
    //   description: this.properties.description,
    //   context: this.context,
    //   siteUrl: this.context.pageContext.web.absoluteUrl,
    //   userName: this.context.pageContext.user.displayName,
    //   referrerUrl: referrerUrl,
    // });

    // ReactDom.render(element, this.domElement);
  }

  private renderApp = (referrerUrl:string) => {
    const element: React.ReactElement<IAppProps> = React.createElement(App, {
      taskService: this._taskService,
      description: this.properties.description,
      context: this.context,
      siteUrl: this.context.pageContext.web.absoluteUrl,
      userName: this.context.pageContext.user.displayName,
      referrerUrl: referrerUrl,
    });

    ReactDom.render(element, this.domElement);
  }

  private renderSystemError = () => {
    const element : React.ReactElement<ISystemErrorProps> = React.createElement(SystemError, {error: this.currentError});
    ReactDom.render(element, this.domElement);
  }

  protected async onInit(): Promise<void> {
    console.warn("onInit event....");

    const tokenService: ITokenService = new TokenService(this.context.pageContext.aadInfo.tenantId, 
      this.properties.applicationId, 
      this.context.pageContext.user.email, 
      `${this.properties.taskManagerApiUrl}/user_impersonation`);

    this._taskService = new TaskService(
      this.context.httpClient,
      tokenService,
      this.properties.taskManagerApiUrl,
    );

    return Promise.resolve();
  }

  protected onDispose(): void {
    console.warn("onDispose event....");
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse("1.0");
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription,
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField("description", {
                  label: strings.DescriptionFieldLabel,
                }),
                PropertyPaneTextField("taskManagerApiUrl", {
                  label: strings.TaskManagerApiUrlFieldLabel,
                }),
                PropertyPaneTextField("dwLandingPageUrl", {
                  label: strings.DWLandingPageUrlFieldLabel,
                }),
                PropertyPaneTextField("applicationId", {
                  label: strings.ApplicationIdFieldLabel,
                }),
              ],
            },
          ],
        },
      ],
    };
  }
}
