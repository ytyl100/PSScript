import { Guid } from "@microsoft/sp-core-library";
import { AppSettings } from "../models/AppSettings";
import { ITaskInfo } from "../models/ITaskInfo";

export interface ITaskService {
  getTasks: () => Promise<ITaskInfo[]>;
  getApps: () => Promise<AppSettings[]>;
  updateTask: (upn: string, taskId: Guid, status: number) => Promise<ITaskInfo>;
}
