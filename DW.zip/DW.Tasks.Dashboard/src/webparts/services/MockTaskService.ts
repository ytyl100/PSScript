import { Guid } from "@microsoft/sp-core-library";
import { AppSettings } from "../models/AppSettings";
import { ITaskInfo } from "../models/ITaskInfo";
import { ITaskService } from "./ITaskService";

export class MockTaskService implements ITaskService {
  public updateTask: (upn: string, taskId: Guid) => Promise<ITaskInfo>;
  public async getApps(): Promise<AppSettings[]>{
    return Promise.resolve([]);
  }
  public async getTasks(): Promise<ITaskInfo[]> {
    return Promise.resolve([]);
  }
}
