import { ITaskInfo } from "../models/ITaskInfo";
import { ITaskService } from "./ITaskService";
import {
  HttpClient,
  IHttpClientOptions,
  HttpClientResponse,
} from "@microsoft/sp-http";

import { ITokenService } from "./ITokenService";
import { AppSettings } from "../models/AppSettings";
import { ITaskUpdateIdentifier } from "../models/ITaskUpdateIdentifier";
import { Guid } from "@microsoft/sp-core-library";

export class TaskService implements ITaskService {
  constructor(
    private client: HttpClient,
    private tokenService: ITokenService,
    private taskManagerApiUrl: string
  ) {}

  public async updateTask(upn: string, taskId: Guid, status: number): Promise<ITaskInfo> {
    try {
      const accessToken = await this.tokenService.getToken();
      console.warn("access token:", accessToken);

      const endpoint: string = `${this.taskManagerApiUrl}/api/UpdateTask`;

      const requestHeaders: Headers = new Headers();
      requestHeaders.append("accept", "application/json");
      requestHeaders.append("Authorization", `Bearer ${accessToken}`);

      let taskUpdateIdentifier: ITaskUpdateIdentifier = {
        upn: upn,
        id: taskId.toString(),
        status: status
      };
      const body: string = JSON.stringify(taskUpdateIdentifier);
      
      const clientOptions: IHttpClientOptions = {
        headers: requestHeaders,
        body: body
      };

      const clientResponse: HttpClientResponse = await this.client.post(
        endpoint,
        HttpClient.configurations.v1,
        clientOptions
      );

      if (clientResponse.status !== 200) {
        console.error(
          "client response status:",
          clientResponse.status,
          clientResponse.statusText
        );
        //return [];
        throw new Error(
          `status: ${clientResponse.status} - response: ${clientResponse.statusText}`
        );
      }

      const task: ITaskInfo = await clientResponse.json();
      console.warn("task:", task);

      return task;
    } catch (error) {
      console.error(error);
      throw new Error(error);
    }
  }

  public async getApps():Promise<AppSettings[]>{
    const currentApps : AppSettings[] = [
      {
        code: 'hr',
        description: 'My HR',
        name: 'HR',
        iconName: 'D365TalentHRCore',
      },
      {
        code: 'itid',
        description: 'My ITID',
        name: 'ITID',
        iconName: 'AccountActivity'
      },      
      {
        code: 'fusion',
        description: 'My Fusion',
        name: 'Fusion',
        iconName : 'RecruitmentManagement'
      },
      {
        code: 'clarity',
        description: 'My Clarity',
        name: 'Clarity',
        iconName: 'Financial'
      }      
    ];
    return currentApps;
  }

  public async getTasks(): Promise<ITaskInfo[]> {
    try {
      const accessToken = await this.tokenService.getToken();
      console.warn("access token:", accessToken);

      const endpoint: string = `${this.taskManagerApiUrl}/api/GetTasks`;

      const requestHeaders: Headers = new Headers();
      requestHeaders.append("accept", "application/json");
      requestHeaders.append("Authorization", `Bearer ${accessToken}`);

      const clientOptions: IHttpClientOptions = {
        headers: requestHeaders,
      };

      const clientResponse: HttpClientResponse = await this.client.get(
        endpoint,
        HttpClient.configurations.v1,
        clientOptions
      );

      if (clientResponse.status !== 200) {
        console.error(
          "client response status:",
          clientResponse.status,
          clientResponse.statusText
        );
        //return [];
        throw new Error(
          `status: ${clientResponse.status} - response: ${clientResponse.statusText}`
        );
      }

      const tasks: ITaskInfo[] = await clientResponse.json();
      console.warn("tasks:", tasks);

      return tasks;
    } catch (error) {
      console.error(error);
      throw new Error(error);
    }
  }
}
