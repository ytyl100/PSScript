import {
  AccountInfo,
  AuthenticationResult,
  Configuration,
  EndSessionRequest,
  InteractionRequiredAuthError,
  LogLevel,
  PopupRequest,
  PublicClientApplication,
  RedirectRequest,
  SilentRequest,
  SsoSilentRequest,
} from "@azure/msal-browser";
import { ITokenService } from "./ITokenService";

const MSAL_CONFIG: Configuration = {
  auth: {
    authority: null,
    clientId: null,
  },
  cache: {
    cacheLocation: "sessionStorage", // This configures where your cache will be stored
    storeAuthStateInCookie: false, // Set this to "true" if you are having issues on IE11 or Edge
  },
  system: {
    windowHashTimeout: 60000,
    iframeHashTimeout: 6000,
    loadFrameTimeout: 0,
    loggerOptions: {
      loggerCallback: (level, message, containsPii) => {
        if (containsPii) {
          return;
        }
        switch (level) {
          case LogLevel.Error:
            console.error(message);
            return;
          case LogLevel.Info:
            console.info(message);
            return;
          case LogLevel.Verbose:
            console.debug(message);
            return;
          case LogLevel.Warning:
            console.warn(message);
            return;
        }
      },
    },
  },
};

export class TokenService implements ITokenService {
  private myMSALObj: PublicClientApplication; // https://azuread.github.io/microsoft-authentication-library-for-js/ref/msal-browser/classes/_src_app_publicclientapplication_.publicclientapplication.html
  private loginRequest: PopupRequest; // https://azuread.github.io/microsoft-authentication-library-for-js/ref/msal-browser/modules/_src_request_popuprequest_.html

  private silentLoginRequest: SsoSilentRequest;

  constructor(
    private tenantId: string,
    private applicationId: string,
    private email: string,
    private scope: string
  ) {
    MSAL_CONFIG.auth.authority = `https://login.microsoftonline.com/${this.tenantId}`;
    MSAL_CONFIG.auth.clientId = this.applicationId;

    this.myMSALObj = new PublicClientApplication(MSAL_CONFIG);

    this.loginRequest = {
      scopes: [],
    };

    // Add here scopes for access token to be used at MS Graph API endpoints.
    this.silentLoginRequest = {
      loginHint: email,
      scopes: [scope],
    };
  }

  // private async getTokenABC(): Promise<AuthenticationResult> {
  //   try {
  //     const silentResult = await this.myMSALObj.ssoSilent(
  //       this.silentLoginRequest
  //     );
  //     console.warn("silent result get Token ABC:", silentResult);
  //     return silentResult;
  //   } catch (silentError) {
  //     if (silentError instanceof InteractionRequiredAuthError) {
  //       console.error(silentError);

  //       try {
  //         const popupResult = await this.myMSALObj.loginPopup(
  //           this.loginRequest
  //         );
  //         return popupResult;
  //       } catch (popupError) {
  //         console.error("login popup error:", popupError);
  //         return null;
  //       }
  //     }
  //   }
  // }

  private getAccount = (email: string): AccountInfo => {
    const accounts = this.myMSALObj.getAllAccounts();
    if (accounts === null || accounts.length === 0) {
      return null;
    } else {
      return this.myMSALObj.getAccountByUsername(email);
    }
  }

  private acquireTokenSilent = async (
    account: AccountInfo
  ): Promise<AuthenticationResult> => {
    const sRequest: SilentRequest = {
      scopes: [this.scope],
      account: account,
    };

    try {
      const res: AuthenticationResult = await this.myMSALObj.acquireTokenSilent(
        sRequest
      );
      return res;
    } catch (error) {
      console.error('acquireTokenSilent:', error);
      throw error;
    }
  }

  private ssoSilent = async (): Promise<AuthenticationResult> => {
    try {
      const silentResult = await this.myMSALObj.ssoSilent(
        this.silentLoginRequest
      );
  
      return silentResult;
    } catch (error) {
      console.error('ssoSilent:', error);
      throw error;
    }
  }

  private loginPopup = async (): Promise<AuthenticationResult> => {
    try {
      const popupResult = await this.myMSALObj.loginPopup(
        this.loginRequest
      );
      return popupResult;      
    } catch (error) {
      console.error('loginPopup:', error);
      throw error;
    }
  }

  public async getToken(): Promise<string> {
    const account = this.getAccount(this.email);

    let res: AuthenticationResult;

    try {
      res = account !== null ? await this.acquireTokenSilent(account) : await this.ssoSilent();       
      return res.accessToken;
    } catch (error) {
      console.log(error);
      throw error;
    }


    // if (account !== null) {
    //   try {
    //     const res = await this.acquireTokenSilent(account);
    //     return res.accessToken;
    //   } catch (error) {
    //     console.error('getToken Error - acquireTokenSilent: ', error);
    //     throw new Error(error);
    //   }
    // } else {
    //   try {
    //     const res = await this.ssoSilent();
    //     return res.accessToken;
    //   } catch (error) {
    //     console.error('getToken Error - ssoSilent: ', error); 
    //     throw new Error(error);
    //     // TODO: check if loginPopup functionality needs to be added or not       
    //   }
    // }

    // const accounts = this.myMSALObj.getAllAccounts();

    // if (accounts === null || accounts.length === 0) {
    //   console.warn('No Accounts found in getToken getAllAccounts');
    //   console.warn('now checking getTokenABC....');
    //   const result: AuthenticationResult = await this.getTokenABC();
    //   return result.accessToken;
    // }

    // let account: AccountInfo = null;

    // console.warn('accounts found...', accounts);

    // if (accounts.length > 1) {
    //   account = this.myMSALObj.getAccountByUsername(this.email);
    //   console.warn('account selected for email', this.email, account);
    // } else {
    //   account = accounts[0];
    //   console.warn('accounts[0] selected...', account);
    // }

    // if (account != null) {
    //   const sRequest: SilentRequest = {
    //     scopes: [this.scope],
    //     account: account
    //   };

    //   try {
    //     console.warn('aquire Token Silent for request', sRequest);
    //     const res: AuthenticationResult = await this.myMSALObj.acquireTokenSilent(sRequest);
    //     console.warn('acquire Token Silent result:', res);
    //     return res.accessToken;
    //   } catch (error) {
    //     console.error('acquire token silent error:', error);
    //     return null;
    //   }
    // }
  }
}
