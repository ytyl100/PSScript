import { ServiceScope } from "@microsoft/sp-core-library";
import {
  HttpClient,
  HttpClientResponse,
  IHttpClientOptions,
} from "@microsoft/sp-http";
import { IBeezyAdminService, ILogService } from ".";
import { ActionResultStatus, BeezyResultStatus } from "../enums";
import { ITokenService } from "./ITokenService";
import { IBeezyCurrentUser, ILocalEntity, ILocalEntityExtended, ILocalEntityJoinResult, ILocalEntityUpdateIdentifier } from "../models";
import { IBeezyResult } from "../models/IBeezyResult";
import { IActionResult } from "../models/IActionResult";
import { ErrorUtils } from "../utils";


export class BeezyAdminService implements IBeezyAdminService {
  // public static readonly serviceKey: ServiceKey<ITaskService> =
  //   ServiceKey.create<ITaskService>("dw-app:ITaskService", TaskService);


  constructor(
    private serviceScope: ServiceScope,
    private client: HttpClient,
    private tokenService: ITokenService,
    private logService: ILogService,
    private beezyAdminApiUrl: string,
    private authenticationEnabled: boolean,
    private UPN: string,
    private targetUPN: string,
  ) {
    //serviceScope.whenFinished(() => {});
  }

  private async configureRequestHeaders(): Promise<Headers> {
    const requestHeaders: Headers = new Headers();
    requestHeaders.append("accept", "application/json");

    if (this.authenticationEnabled === false) {
      return requestHeaders;
    }

    const accessToken = await this.tokenService.getToken();
    requestHeaders.append("Authorization", `Bearer ${accessToken}`);

    return requestHeaders;
  }

  private constructEndpoint(functionName: string): string {
    let endpoint = `${this.beezyAdminApiUrl}/api/${functionName}`;
    return endpoint;
  }

  public async getUser(): Promise<IActionResult<IBeezyCurrentUser>> {
    try {

      let endpoint: string = this.constructEndpoint('GetUser');

      if (this.authenticationEnabled) {
        if (this.targetUPN) {
          endpoint += "?" + `userLoginId=${this.targetUPN}`;
        }
      } else {
        endpoint += "?" + `userLoginId=${this.targetUPN ?? this.UPN}`;
      }

      const requestHeaders: Headers = await this.configureRequestHeaders();

      const clientOptions: IHttpClientOptions = {
        headers: requestHeaders,
      };

      const clientResponse: HttpClientResponse = await this.client.get(
        endpoint,
        HttpClient.configurations.v1,
        clientOptions
      );

      this.logService.debug("client response", clientResponse);

      if (clientResponse.status !== 200) {
        return {
          status: ActionResultStatus.Error,
          errorMessage: ErrorUtils.GenerateHttpResponseErrorMessage(clientResponse.status, clientResponse.statusText),
        };
      }

      const beezyResult: IBeezyResult<IBeezyCurrentUser> = await clientResponse.json();

      this.logService.debug("Beezy GetUser result", beezyResult);

      if (beezyResult.Status === BeezyResultStatus.Success) {
        return {
          authenticatedUser: beezyResult.AuthenticatedUser,
          status: ActionResultStatus.Success,
          data: beezyResult.ResponseItem,
        };
      } else {
        return {
          authenticatedUser: beezyResult.AuthenticatedUser,
          status: ActionResultStatus.Error,
          errorMessage: ErrorUtils.GenerateBeezyResultExceptionErrorMessage(beezyResult),
        };
      }
    }
    catch (error) {
      return {
        status: ActionResultStatus.Error,
        errorMessage: ErrorUtils.GenerateGenericErrorMessage(error),
      };
    }
  }


  public async joinLocalEntity(localEntity: ILocalEntity): Promise<IActionResult<ILocalEntityJoinResult>> {
    try {
      const endpoint: string = this.constructEndpoint('ChangeUserLocalEntity');

      const requestHeaders: Headers = await this.configureRequestHeaders();

      let updateIdentifier: ILocalEntityUpdateIdentifier = {
        targetLocalEntityId: localEntity.Id,
      };

      if (this.authenticationEnabled) {
        if (this.targetUPN) {
          updateIdentifier.userLoginId = this.targetUPN;
        }
      } else {
        updateIdentifier.userLoginId = this.targetUPN ?? this.UPN;
      }

      const body: string = JSON.stringify(updateIdentifier);

      const clientOptions: IHttpClientOptions = {
        headers: requestHeaders,
        body: body,
      };

      const clientResponse: HttpClientResponse = await this.client.post(
        endpoint,
        HttpClient.configurations.v1,
        clientOptions
      );

      this.logService.debug("client response", clientResponse);

      if (clientResponse.status !== 200) {
        return {
          status: ActionResultStatus.Error,
          errorMessage: ErrorUtils.GenerateHttpResponseErrorMessage(clientResponse.status, clientResponse.statusText),
        };
      }


      const beezyResult: IBeezyResult<ILocalEntityJoinResult> = await clientResponse.json();

      this.logService.debug("Beezy ChangeUserLocalEntity result", beezyResult);

      if (beezyResult.Status === BeezyResultStatus.Success) {
        return { authenticatedUser: beezyResult.AuthenticatedUser, status: ActionResultStatus.Success, data: beezyResult.ResponseItem };
      } else {
        return { authenticatedUser: beezyResult.AuthenticatedUser, status: ActionResultStatus.Error, errorMessage: ErrorUtils.GenerateBeezyResultExceptionErrorMessage(beezyResult) };
      }
    } catch (error) {
      return {
        status: ActionResultStatus.Error,
        errorMessage: ErrorUtils.GenerateGenericErrorMessage(error),
      };
    }
  }

  public async getLocalEntities(): Promise<IActionResult<ILocalEntityExtended[]>> {
    try {
      let endpoint: string = this.constructEndpoint('GetLocalEntities');

      if (this.authenticationEnabled) {
        if (this.targetUPN) {
          endpoint += "?" + `userLoginId=${this.targetUPN}`;
        }
      } else {
        endpoint += "?" + `userLoginId=${this.targetUPN ?? this.UPN}`;
      }

      const requestHeaders: Headers = await this.configureRequestHeaders();

      const clientOptions: IHttpClientOptions = {
        headers: requestHeaders,
      };

      const clientResponse: HttpClientResponse = await this.client.get(
        endpoint,
        HttpClient.configurations.v1,
        clientOptions
      );

      this.logService.debug("client response", clientResponse);

      if (clientResponse.status !== 200) {
        return {
          status: ActionResultStatus.Error,
          errorMessage: ErrorUtils.GenerateHttpResponseErrorMessage(clientResponse.status, clientResponse.statusText),
        };
      }

      const beezyResult: IBeezyResult<ILocalEntityExtended[]> = await clientResponse.json();

      this.logService.debug("Beezy GetLocalEntities result", beezyResult);


      if (beezyResult.Status === BeezyResultStatus.Success) {
        return { authenticatedUser: beezyResult.AuthenticatedUser, status: ActionResultStatus.Success, data: beezyResult.ResponseItem };
      } else {
        return { authenticatedUser: beezyResult.AuthenticatedUser, status: ActionResultStatus.Error, errorMessage: ErrorUtils.GenerateBeezyResultExceptionErrorMessage(beezyResult) };
      }

    } catch (error) {
      return {
        status: ActionResultStatus.Error,
        errorMessage: ErrorUtils.GenerateGenericErrorMessage(error),
      };
    }
  }
}