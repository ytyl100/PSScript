/// <reference types="jest" />


import { IBeezyAdminService } from ".";
import { IBeezyCurrentUser, ILocalEntity, ILocalEntityExtended, ILocalEntityJoinResult } from "../models";
import { IActionResult } from "../models/IActionResult";
import { MockBeezyAdminService } from "./MockBeezyAdminService";


let sut: IBeezyAdminService;

beforeEach(() => {
  sut = new MockBeezyAdminService();
});

describe('Beezy Admin Service', () => {

  describe('User', () => {
    test('GetUser()', () => {
      return sut.getUser().then((user: IActionResult<IBeezyCurrentUser>) => {
        expect(user.data.Id).toBe(1);
      });
    });
  });

  describe('Local Entities', () => {
    test('GetLocalEntities() returns correct result', () => {
      expect.assertions(1);

      return sut.getLocalEntities()
        .then((result: IActionResult<ILocalEntityExtended[]>) => {
          expect(result.data.length).toBe(0);
        });
    });

    test('JoinLocalEntity() returns .....', () => {
      return sut.joinLocalEntity(null).then((result: IActionResult<ILocalEntityJoinResult>) => {
        expect(result.data.UserId).toBe(1);
      });
    });
  });
});