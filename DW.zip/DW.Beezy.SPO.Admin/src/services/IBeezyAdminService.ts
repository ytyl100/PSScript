import { IAppUser, IBeezyCurrentUser, ILocalEntity, ILocalEntityExtended, ILocalEntityJoinResult } from "../models";
import { IActionResult } from "../models/IActionResult";

export interface IBeezyAdminService {
  getLocalEntities: () => Promise<IActionResult<ILocalEntityExtended[]>>;
  joinLocalEntity: (localEntity: ILocalEntity) => Promise<IActionResult<ILocalEntityJoinResult>>;
  getUser: () => Promise<IActionResult<IBeezyCurrentUser>>;
}
