/// <reference types="jest" />

import { ITokenService, MockTokenService } from ".";

let sut: ITokenService;

beforeEach(() => {
    sut = new MockTokenService();
});

describe('Token Service', () => {
    test('GetToken() returns test access token', () => {
        expect.assertions(1);

        return sut.getToken().then((token: string) => {
            expect(token).toBe('test access token');
        });
    });
});