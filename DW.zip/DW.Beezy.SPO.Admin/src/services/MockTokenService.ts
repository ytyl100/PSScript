import { ITokenService } from "./ITokenService";

export class MockTokenService implements ITokenService {
  constructor() {}

  public async getToken(): Promise<string> {
    return Promise.resolve<string>("test access token");
  }
}
