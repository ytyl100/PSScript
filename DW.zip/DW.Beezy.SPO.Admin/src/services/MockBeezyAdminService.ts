import { Guid } from "@microsoft/sp-core-library";
import { IBeezyAdminService } from ".";
import { ActionResultStatus } from "../enums";
import { IAppUser, IBeezyCurrentUser, ILocalEntity, ILocalEntityExtended, ILocalEntityJoinResult } from "../models";
import { IActionResult } from "../models/IActionResult";
import { IBeezyResult } from "../models/IBeezyResult";


export class MockBeezyAdminService implements IBeezyAdminService {
  // private mockUser: IBeezyCurrentUser = {
  //   LoginName: string;
  //   LocalEntity: IBeezyUserLocalEntity;
  // }


  public async joinLocalEntity(localEntity: ILocalEntity) : Promise<IActionResult<ILocalEntityJoinResult>>{
    
    var result : IActionResult<ILocalEntityJoinResult> = {
      status: ActionResultStatus.Success
    };

    return Promise.resolve(result);
  }

  public async getUser(): Promise<IActionResult<IBeezyCurrentUser>>{
    var result : IActionResult<IBeezyCurrentUser> = {
      status: ActionResultStatus.Success,

    };

    return Promise.resolve(result);
  }
  public async getLocalEntities(): Promise<IActionResult<ILocalEntityExtended[]>>{
    var result : IActionResult<ILocalEntityExtended[]> = {
      status: ActionResultStatus.Success,
      data: []
    };

    return Promise.resolve(result);
  }
}
