import { ILogService } from ".";
import { AppMode } from "../enums";



export class LogService implements ILogService {
    constructor(protected prefix: string, readonly mode: AppMode) {
        if (mode === AppMode.Debug) {
            this.warn("App in debug mode");
        }
    }

    public debug(message: string, ...args: any[]): void {
        if (this.mode === AppMode.Debug) {
            console.debug(`${this.prefix}: ${message}`, ...args);
        }
    }

    public log(message: string, ...args: any[]): void {
        console.log(`${this.prefix}: ${message}`, ...args);
    }

    public warn(message: string, ...args: any[]): void {
        console.warn(`${this.prefix}: ${message}`, ...args);
    }

    public error(message: string, ...args: any[]): void {
        console.error(`${this.prefix}: ${message}`, ...args);
    }
}