export enum ActionResultStatus{
    Success,
    Error
}