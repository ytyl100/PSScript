export enum BeezyResultStatus {
    Success = 0,
    InvalidRequestError = 100,
    BeezyServiceError = 200,
    UnknownError = 300,
}