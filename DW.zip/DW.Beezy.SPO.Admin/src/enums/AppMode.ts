export enum AppMode{
    Normal,
    Debug
}