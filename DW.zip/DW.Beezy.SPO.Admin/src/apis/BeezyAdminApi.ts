
import { ActionResultStatus } from "../enums";
import { IBeezyCurrentUser, IBeezyUser, ILocalEntity, ILocalEntityExtended, ILocalEntityJoinResult } from "../models";
import { IActionResult } from "../models/IActionResult";
import { IBeezyAdminService, ILogService } from "../services";

export class BeezyAdminApi {
  constructor(private beezyAdminService: IBeezyAdminService, private logService: ILogService) {

  }

  public async loadUser(): Promise<IActionResult<IBeezyCurrentUser>> {
    const result = await this.beezyAdminService.getUser();

    if (result.status === ActionResultStatus.Error) {
      this.logService.log("loadUser error");
      return result;
    }

    return result;
  }


  private enrichLocalEntity(user: IBeezyCurrentUser, localEntity: ILocalEntityExtended): void {
    if (user.LocalEntity && user.LocalEntity.Id === localEntity.Id) {
      localEntity.IsMember = true;
      return;
    }

    if (localEntity.Admins && localEntity.Admins.length > 0) {
      if (localEntity.Admins.findIndex((beezyUser: IBeezyUser) => user.Id === beezyUser.Id) !== -1) {
        localEntity.IsMember = true;
        return;
      }
    }

    localEntity.IsMember = false;
    return;
  }

  public async loadLocalEntities(user: IBeezyCurrentUser): Promise<IActionResult<ILocalEntityExtended[]>> {
    const result = await this.beezyAdminService.getLocalEntities();

    if (result.status !== ActionResultStatus.Success) {
      this.logService.log("loadLocalEntities error");
      return result;
    }

    result.data.forEach((localEntity: ILocalEntityExtended) => this.enrichLocalEntity(user, localEntity));
    return result;
  }

  public async joinLocalEntity(localEntity: ILocalEntity): Promise<IActionResult<ILocalEntityJoinResult>> {
    const result = await this.beezyAdminService.joinLocalEntity(localEntity);

    if(result.status !== ActionResultStatus.Success){
      this.logService.log("joinLocalEntity error");
      return result;
    }
    return result;
  }
}