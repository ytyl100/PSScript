import { createContext, useContext } from "react";
import { BeezyAdminApi } from "../apis";
import { AppMode } from "../enums";
import { IAppUser } from "../models";
import { ILogService } from "../services";




export type GlobalContent = {
  user: IAppUser;
  beezyAdminApi: BeezyAdminApi;
  logService: ILogService;
  mode: AppMode;
};

export const GlobalContext = createContext<GlobalContent>({
  user: undefined,
  beezyAdminApi: undefined,
  logService: undefined,
  mode: AppMode.Normal
});

export const useGlobalContext = () => useContext(GlobalContext);
