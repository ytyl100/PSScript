
export interface IMenuBarProps {
  backLink: string;
}
