import {
  IContextualMenuItemStyles,
  IContextualMenuStyles,
} from "office-ui-fabric-react";
import {
  CommandBar,
  ICommandBarItemProps,
} from "office-ui-fabric-react/lib/CommandBar";
import * as React from "react";
import { useGlobalContext } from "../../hooks";
import { IMenuBarProps } from "./IMenuBarProps";
import { Helpers } from "../../utils";
import { AppStatus } from "../../state/state";
import { setAppStatus, setLocalEntities, setUser } from "../../state/reducer";
import { useAppContext } from "../../state/context";

export const MenuBar = ({ backLink }: IMenuBarProps) => {
  const { beezyAdminApi, logService } = useGlobalContext();
  const { state, dispatch } = useAppContext();  

  const startAsync = () => {
    reloadData();
  };

  const reloadData = async () => {
    dispatch(setAppStatus(AppStatus.Loading));
    const currentUser = await beezyAdminApi.loadUser();
    dispatch(setUser(currentUser.data));
    const localEntities = await beezyAdminApi.loadLocalEntities(currentUser.data);
    dispatch(setLocalEntities(localEntities.data));
    dispatch(setAppStatus(AppStatus.Success));
    return;
  };



  const itemStyles: Partial<IContextualMenuItemStyles> = {
    label: {},
    icon: { color: "red" },
    iconHovered: { color: "green" },
  };

  // For passing the styles through to the context menus
  const menuStyles: Partial<IContextualMenuStyles> = {
    root: {
      fontSize: 24,
      backgroundColor: "transparent",
      paddingTop: 20,
      paddingLeft: 0,
      paddingRight: 0,
    },
    subComponentStyles: { menuItem: itemStyles, callout: {} },
  };

  const buttonStylesLeft = {
    icon: {
      color: "#000000",
      fontSize: 24,
    },
    iconHovered: { color: "#FFFFFF" },
    root: {
      background: "transparent",
      color: "#000000",
      paddingRight: 12,
      fontSize: 16,
    },
    rootHovered: {
      background: "#DB0011",
      color: "#FFFFFF",
    },
  };

  const buttonStylesRight = {
    icon: {
      color: "#000000",
      fontSize: 24,
    },
    iconHovered: { color: "#FFFFFF" },
    root: {
      background: "transparent",
      color: "#000000",
      paddingRight: 0,
      fontSize: 16,
    },
    rootHovered: {
      background: "#DB0011",
      color: "#FFFFFF",
    },
  };

  const _items: ICommandBarItemProps[] = [
    // {
    //   key: "home",
    //   text: "Home",
    //   iconProps: { iconName: "Home" },
    //   href: backLink,
    //   buttonStyles: buttonStylesLeft,
    // },
    // {
    //   key: "dashboard",
    //   text: "Dashboard",
    //   iconProps: { iconName: "BarChartVertical" },
    //   href: "#/",
    //   buttonStyles: buttonStylesLeft,
    // },
    {
      key: "home",
      text: "Home",
      iconProps: { iconName: "Home" },
      href: "#/",
      buttonStyles: buttonStylesLeft,
    },
    {
      key: "user",
      text: "My Details",
      iconProps: { iconName: "UserOptional" },
      href: "#/user",
      buttonStyles: buttonStylesLeft,
    },
    {
      key: "localentities",
      text: "Local Entities",
      iconProps: { iconName: "CheckList" },
      href: "#/local-entities",
      buttonStyles: buttonStylesLeft,
    },
  ];

  const _farItems: ICommandBarItemProps[] = [
    // {
    //   key: "tile",
    //   text: "Grid view",
    //   // This needs an ariaLabel since it's icon-only
    //   ariaLabel: "Grid view",
    //   iconOnly: true,
    //   iconProps: { iconName: "CheckList" },
    //   onClick: () => logService.log("CheckList"),
    //   buttonStyles: buttonStyles,
    // },
    {
      key: "reload",
      text: "Reload",
      // This needs an ariaLabel since it's icon-only
      ariaLabel: "Reload",
      iconOnly: true,
      iconProps: { iconName: "Refresh" },
      onClick: () => startAsync(),
      buttonStyles: buttonStylesRight,
    },
  ];

  React.useEffect(() => {

  }, []);

  return (
    <CommandBar
      items={_items}
      farItems={_farItems}
      styles={menuStyles}
    ></CommandBar>
  );
};

