import * as React from "react";
import * as ReactDOM from "react-dom";
import { TestWidget } from "./TestWidget";


describe("Test Widget Test", () => {
    test("renders header", () => {
        const root = document.createElement("div");
        ReactDOM.render(<TestWidget name="Test Widget 123" age={1}></TestWidget>, root);
    
        expect(root.querySelector("h1").textContent).toBe("Test Widget 123"); 
    });

});