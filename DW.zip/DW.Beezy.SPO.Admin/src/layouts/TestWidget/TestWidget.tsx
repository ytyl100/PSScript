import * as React from "react";

export interface ITestWidgetProps {
    name: string;
    age: number;
}

export const TestWidget = ({ name, age }: ITestWidgetProps) => {

    return (
        <div>
            <h1>{name}</h1>
            <h2>{age}</h2>
        </div>
    );
};
