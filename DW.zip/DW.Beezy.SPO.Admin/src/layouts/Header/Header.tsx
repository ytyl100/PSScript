import * as React from "react";
import { MenuBar } from "../MenuBar/MenuBar";
import { IHeaderProps } from "./IHeaderProps";

export const Header = ({ backLink }: IHeaderProps) => {
  
  return (
    <div className="ms-Grid dw-header" dir="ltr">
      <nav className="ms-Grid-row">
        <div className="ms-Grid-col ms-sm12">
          <MenuBar backLink={backLink}></MenuBar>
        </div>
      </nav>
    </div>
  );
};
