import { IButtonStyles } from "@microsoft/office-ui-fabric-react-bundle";
import {
  IStackTokens,
  Label,
  PrimaryButton,
  Separator,
  Stack,
  TextField,
} from "office-ui-fabric-react";
import * as React from "react";
import { useState } from "react";
import { ADGroupList, AdminList, ErrorBoundary } from "../../components";
import AnswerDialog from "../../components/AnswerDialog/AnswerDialog";
import ProcessingDialog from "../../components/ProcessingDialog/ProcessingDialog";
import { ActionResultStatus, AppMode } from "../../enums";
import { useGlobalContext } from "../../hooks";
import { ILocalEntityExtended } from "../../models";

import { useAppContext } from "../../state/context";
import { setLocalEntities, setUser } from "../../state/reducer";
import { AppStatus } from "../../state/state";
import { BooleanRenderer, Helpers } from "../../utils";

export interface ILocalEntityPageProps {
  id: number;
}

export const LocalEntityPage = ({ id }: ILocalEntityPageProps) => {
  const { beezyAdminApi, mode, logService } = useGlobalContext();
  const { state, dispatch } = useAppContext();
  const [localEntity, setLocalEntity] = useState<ILocalEntityExtended>(undefined);

  React.useEffect(() => {
    logService.debug("LocalEntityPage useEffect");
  }, []);

  React.useEffect(() => {
    const match = state.localEntities.filter((t) => t.Id == id);
    if (match.length === 1) {
      setLocalEntity(match[0]);
    } else {
      setLocalEntity(undefined);
    }
  }, [id]);

  const stackTokens: IStackTokens = { childrenGap: 10 };


  const reloadData = async () => {
    const currentUser = await beezyAdminApi.loadUser();
    dispatch(setUser(currentUser.data));
    const localEntities = await beezyAdminApi.loadLocalEntities(currentUser.data);
    dispatch(setLocalEntities(localEntities.data));
    return;
  };


  const joinLocalEntity = async () => {
    const answerDialog = new AnswerDialog(`Join Local Entity ${localEntity.Title}?`, "Confirm Processing");
    await answerDialog.show();

    if (answerDialog.answer !== true) {
      return;
    }

    const processingDialog = new ProcessingDialog(`Joining Local Entity ${localEntity.Title} - Please wait.`, "Processing", false);
    processingDialog.show();
    const result = await beezyAdminApi.joinLocalEntity(localEntity);

    if (result.status === ActionResultStatus.Success) {
      await reloadData();
      processingDialog.close();

      let msg : string = `You successfully joined Local Entity: ${result.data.TargetLocalEntityTitle}`;

      const resultDialog = new ProcessingDialog(msg, "Processing Succeeded", true);
      await resultDialog.show();
      return;
    } else {
      processingDialog.close();
      const resultDialog = new ProcessingDialog(result.errorMessage,"Processing Failed", true);
      await resultDialog.show();
      return;
    }
  };

  const canJoin = (): boolean => {
    if (localEntity.IsMember) {
      return false;
    }

    if (!localEntity.CanJoin) {
      return false;
    }

    if (state.isImpersonated && !localEntity.CanOverride) {
      return false;
    }

    return true;
  };

  return (
    <ErrorBoundary message="Local Entity Boundary" logService={logService}>
      <>
        {localEntity &&
          <div className="ms-Grid" dir="ltr" >
            <div className="ms-Grid-row">
              <div className="ms-Grid-col ms-sm6">
                <Stack>
                  <TextField
                    label="Title:"
                    readOnly
                    defaultValue={localEntity.Title}
                  />
                  {
                    canJoin() &&
                    <>
                      <Label>Join Local Entity:</Label>
                      <PrimaryButton text={`Join: ${localEntity.Title}`} onClick={() => joinLocalEntity()} />
                    </>
                  }
                </Stack>
              </div>
              <div className="ms-Grid-col ms-sm6">
                <Stack>
                  <TextField
                    label="Is Default:"
                    readOnly
                    defaultValue={BooleanRenderer(localEntity.IsDefault)}
                  />
                  <TextField
                    label="Default LCID:"
                    readOnly
                    defaultValue={localEntity.DefaultLcid}
                  />
                </Stack>
              </div>
            </div>
            <div className="ms-Grid-row">
              <div className="ms-Grid-col ms-sm12">
                <Separator />
                <Stack>
                  <Label>Admins:</Label>
                  <AdminList admins={localEntity.Admins}></AdminList>

                  <Label>AD Groups:</Label>
                  <ADGroupList adGroups={localEntity.AdGroups}></ADGroupList>
                </Stack>
              </div>
            </div>

            {
              mode === AppMode.Debug &&
              <div className="ms-Grid-row">
                <div className="ms-Grid-col ms-sm6">

                  <Stack tokens={stackTokens}>
                    <TextField
                      label="Beezy ID:"
                      readOnly
                      defaultValue={localEntity.Id.toString()}
                    />
                    <TextField
                      label="Branding:"
                      readOnly
                      defaultValue={localEntity.Branding}
                    />
                    <TextField
                      label="Hero Module Enabled:"
                      readOnly
                      defaultValue={BooleanRenderer(localEntity.HeroModuleEnabled)}
                    />
                    <TextField
                      label="Navigation Module Enabled:"
                      readOnly
                      defaultValue={BooleanRenderer(localEntity.NavigationModuleEnabled)}
                    />
                  </Stack>
                </div>
                <div className="ms-Grid-col ms-sm6">
                  <Stack>
                    <TextField
                      label="Stories Module Enabled:"
                      readOnly
                      defaultValue={BooleanRenderer(localEntity.StoriesModuleEnabled)}
                    />
                    {localEntity.StoriesModuleEnabled && <TextField
                      label="Stories Module ID:"
                      readOnly
                      defaultValue={localEntity.EditorialModuleId}
                    />}
                    <TextField
                      label="Pages Module Enabled:"
                      readOnly
                      defaultValue={BooleanRenderer(localEntity.PagesModuleEnabled)}
                    />
                    {localEntity.PagesModuleEnabled && <TextField
                      label="Pages Module ID:"
                      readOnly
                      defaultValue={localEntity.CorporateModuleId}
                    />}
                    <TextField
                      label="Apps Module Enabled:"
                      readOnly
                      defaultValue={BooleanRenderer(localEntity.AppsModuleEnabled)}
                    />
                    <TextField
                      label="Discovery Cards Module Enabled:"
                      readOnly
                      defaultValue={BooleanRenderer(localEntity.DiscoveryCardsModuleEnabled)}
                    />
                  </Stack>
                </div>
              </div>
            }
          </div>
        }
      </>
    </ErrorBoundary>
  );
};
