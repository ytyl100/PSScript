import * as React from "react";
import { useEffect } from "react";
import { LocalEntityList } from "../../components";

import { useAppContext } from "../../state/context";

export interface ILocalEntityListPageProps {
  app?: string;
}

export const LocalEntityListPage = (props: ILocalEntityListPageProps) => {
  const { state } = useAppContext();
  
  useEffect(() => {

  }, []);

  return (
    <div className="ms-Grid" dir="ltr">
      <div className="ms-Grid-row">
        <div className="ms-Grid-col ms-sm12">
          {
            <LocalEntityList localEntities={state.localEntities}></LocalEntityList>
          }
        </div>
      </div>
    </div>
  );
};
