import * as React from "react";
import { useEffect } from "react";
import { LocalEntitiesCard, UserCard } from "../../components";
import { useGlobalContext } from "../../hooks";

import { useAppContext } from "../../state/context";

export const HomePage = () => {
  const { logService } = useGlobalContext();
  const { state } = useAppContext();

  useEffect(() => {
    logService.debug("Home Page useEffect state:", state);
  }, []);

  return (
    <div className="ms-Grid" dir="ltr">
      <div className="ms-Grid-row">
        <div className="ms-Grid-col ms-sm12">
        <h2>Home</h2>
        </div>
      </div>

      <div className="ms-Grid-row">
        <div className="ms-Grid-col ms-sm12 ms-md6">
          <UserCard user={state.user} isImersonated={state.isImpersonated}></UserCard>
        </div>
        <div className="ms-Grid-col ms-sm12 ms-md6">
          <LocalEntitiesCard localEntities={state.localEntities}></LocalEntitiesCard>
        </div>        
      </div>
    </div>
  );
};
