import * as React from "react";
import { Route, Switch, useParams } from "react-router-dom";
import { LocalEntityListPage, LocalEntityPage, NotFoundPage } from "..";
import { ErrorBoundary } from "../../components";
import { useGlobalContext } from "../../hooks";


type LocalEntityDetailParams = {
  id: string;
};

export const LocalEntitiesPage = () => {
  const {logService} = useGlobalContext();

  return (
    <ErrorBoundary message="Local Entities Boundary" logService={logService}>
      <div className="ms-Grid" dir="ltr">
        <div className="ms-Grid-row">
          <div className="ms-Grid-col ms-sm12">
            <h2>Local Entities</h2>
          </div>
        </div>
        <div className="ms-Grid-row">
          <div className="ms-Grid-col ms-sm12">
            <Switch>
              <Route
                exact
                path="/local-entities"
                component={() => <LocalEntityListPage></LocalEntityListPage>}
              ></Route>
              <Route
                path="/local-entities/:id/view"
                component={() => {
                  const { id } = useParams<LocalEntityDetailParams>();
                  return <LocalEntityPage id={Number.parseInt(id)}></LocalEntityPage>;
                }}
              />
              <Route path="/local-entities/*">
                <NotFoundPage></NotFoundPage>
              </Route>
            </Switch>
          </div>
        </div>
      </div>
    </ErrorBoundary>
  );
};
