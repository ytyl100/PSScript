import * as React from "react";
import { ErrorBoundary } from "../../components";
import { useAppContext } from "../../state/context";

import { Stack, TextField } from "office-ui-fabric-react";
import { BooleanRenderer } from "../../utils";
import { useGlobalContext } from "../../hooks";
import { AppMode } from "../../enums";

export const UserPage = () => {
  const { logService, mode } = useGlobalContext();
  const { state } = useAppContext();

  let headerText: string = `My Details`;
  if (state.isImpersonated) {
    headerText += ` (Impersonated)`;
  }

  return (
    <ErrorBoundary message="User Page Boundary" logService={logService}>
      <div className="ms-Grid" dir="ltr">
        <div className="ms-Grid-row">
          <div className="ms-Grid-col ms-sm12">
            <h2>{headerText}</h2>
          </div>
        </div>
        <div className="ms-Grid-row">
          <div className="ms-Grid-col ms-sm6">
            <Stack>
              <TextField
                label="Full Name:"
                readOnly
                defaultValue={state.user.FullName}
              />
              <TextField
                label="Email:"
                readOnly
                defaultValue={state.user.Email}
              />
              <TextField
                label="Login Name:"
                readOnly
                defaultValue={state.user.LoginName}
              />
              {mode === AppMode.Debug &&
                <TextField
                  label="Beezy ID:"
                  readOnly
                  defaultValue={state.user.Id.toString()}
                />
              }
            </Stack>
          </div>
          <div className="ms-Grid-col ms-sm6">
            {
              state.user.LocalEntity &&
              <Stack>
                <TextField
                  label="Local Entity:"
                  readOnly
                  defaultValue={state.user.LocalEntity.Title}
                />
                {mode === AppMode.Debug &&
                  <>
                    <TextField
                      label="Local Entity ID:"
                      readOnly
                      defaultValue={state.user.LocalEntity.Id.toString()}
                    />
                    <TextField
                      label="Is Default Local Entity:"
                      readOnly
                      defaultValue={BooleanRenderer(state.user.LocalEntity.IsDefaultLocalEntity)}
                    />
                  </>}
              </Stack>
            }
          </div>
        </div>
      </div>
    </ErrorBoundary>
  );
};
