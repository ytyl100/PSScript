import * as React from 'react';

export const NotFoundPage = () => {
    return(<div>not found page</div>);
};
