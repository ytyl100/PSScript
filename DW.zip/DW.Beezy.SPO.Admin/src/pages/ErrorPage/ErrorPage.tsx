import * as React from 'react';

export const ErrorPage = () => {
    return(<div>errorpage</div>);
};
