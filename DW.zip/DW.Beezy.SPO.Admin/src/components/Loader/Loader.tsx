import {
  IStackTokens,
  Spinner,
  SpinnerSize,
  Stack,
} from "office-ui-fabric-react";
import * as React from "react";

interface ILoaderProps {
  message: string;
}

export const Loader: React.FunctionComponent<ILoaderProps> = (props: ILoaderProps) => {
  const stackTokens: IStackTokens = {
    childrenGap: 20,
  };

  return (
    <Stack tokens={stackTokens}>
      <div>
        <Spinner
          label={props.message}
          ariaLive="assertive"
          labelPosition="top"
          size={SpinnerSize.large}
        />
      </div>
    </Stack>
  );
};