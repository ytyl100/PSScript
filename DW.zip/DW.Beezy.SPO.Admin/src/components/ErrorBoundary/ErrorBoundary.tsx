import * as React from "react";
import { ILogService } from "../../services";

interface IProps {
  message: string;
  logService: ILogService;
  children: React.ReactNode;
}

interface IState {
  error: Error;
}

class ErrorBoundary extends React.Component<IProps, IState> {
  constructor(props: IProps) {
    super(props);
    this.state = { error: null };
  }

  public static getDerivedStateFromError(error: Error) {
    return { error: error.message };
  }

  public componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    this.props.logService.error(this.props.message, error, errorInfo);
    console.error(this.props.message, error, errorInfo);
  }

  public render() {
    if (this.state.error) {
      return (
        <div>
          <h1>{`${this.props.message} - Something went wrong`}</h1>
          <p>{this.state.error}</p>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
