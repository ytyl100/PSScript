import {
    DetailsList,
    DetailsListLayoutMode,
    IColumn,
    SelectionMode,
} from "office-ui-fabric-react";
import * as React from "react";

import { useEffect } from "react";
import { useGlobalContext } from "../../hooks";

import { IBeezyCurrentUser } from "../../models";


export interface IUserDetailsProps {
    user: IBeezyCurrentUser;
}

export const UserDetails = (props: IUserDetailsProps) => {
    const { logService } = useGlobalContext();    
    useEffect(() => {
        logService.debug("UserDetails useEffect props", props);
    }, []);


    return (
        <div className="ms-Grid" dir="ltr">
            <div className="ms-Grid-row">
                <div className="ms-Grid-col ms-sm12">User</div>
            </div>
            <div className="ms-Grid-row">
                <div className="ms-Grid-col ms-sm12">

                    {props.user &&
                        <div>
                            <div>Full Name: {props.user.FullName}</div>
                            <div>Email: {props.user.Email}</div>
                            <div>Beezy User Id: {props.user.Id}</div>
                            <div>Login Name: {props.user.LoginName}</div>
                        </div>
                    }
                </div>
            </div>
        </div>
    );
};
