import { DefaultButton, DialogContent, DialogFooter, PrimaryButton } from 'office-ui-fabric-react';
import * as React from 'react';
import { IAnswerDialogContentProps } from '..';
import styles from './AnswerDialogContent.module.scss';
export class AnswerDialogContent extends React.Component<IAnswerDialogContentProps, {}> {

  constructor(props: IAnswerDialogContentProps) {
    super(props);
  }

  public render(): JSX.Element {
    return (<div className={styles.dwDialog}><DialogContent
      title={this.props.question}
      subText={this.props.message}
      onDismiss={() => this.props.submit(false)}
      showCloseButton={false}
    >
      <DialogFooter>
        <DefaultButton text='No' title='No' onClick={() => { this.props.submit(false); }} />
        <PrimaryButton text='Yes' title='Yes' onClick={() => { this.props.submit(true); }} />
      </DialogFooter>
    </DialogContent></div>);
  }

  // private _onColorChange = (ev: React.SyntheticEvent<HTMLElement, Event>, answer: boolean) => {
  //   this._answer = answer;
  // }
}