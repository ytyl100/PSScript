import * as React from 'react';
import * as ReactDOM from 'react-dom';
import { BaseDialog, IDialogConfiguration } from '@microsoft/sp-dialog';
import { AnswerDialogContent } from '..';

export default class AnswerDialog extends BaseDialog {
    public answer: boolean = false;

    constructor(public message: string, public question: string) {
        super({ isBlocking: true });
    }

    public render(): void {
        ReactDOM.render(<AnswerDialogContent
            close={this.close}
            message={this.message}
            question={this.question}
            submit={this._submit}
        />, this.domElement);
    }

    // public getConfig(): IDialogConfiguration {
    //     return { isBlocking: this.isBlocking };
    // }

    protected onAfterClose(): void {
        super.onAfterClose();

        // Clean up the element for the next dialog
        ReactDOM.unmountComponentAtNode(this.domElement);
    }

    private _submit = (answer: boolean) => {
        this.answer = answer;
        this.close();
    }
}