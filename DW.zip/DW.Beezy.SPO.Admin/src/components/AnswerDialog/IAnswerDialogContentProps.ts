export interface IAnswerDialogContentProps {
    message: string;
    question: string;
    close: () => void;
    submit: (answer: boolean) => void;
}