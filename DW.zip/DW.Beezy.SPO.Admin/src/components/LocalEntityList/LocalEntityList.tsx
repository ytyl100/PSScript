import {
  DetailsList,
  DetailsListLayoutMode,
  IColumn,
  SelectionMode,
} from "office-ui-fabric-react";
import * as React from "react";
import { Link } from "react-router-dom";
import { useEffect } from "react";
import { BooleanRenderer } from "../../utils";
import { ILocalEntityExtended } from "../../models";
import { useGlobalContext } from "../../hooks";


export interface ILocalEntityListProps {
  localEntities: ILocalEntityExtended[];
}

const generateColumns = (): IColumn[] => {
  return [
    {
      key: "Title",
      name: "Title",
      fieldName: "Title",
      minWidth: 80,
    },
    {
      key: "isdefault",
      name: "Is Default",
      fieldName: "IsDefault",
      minWidth: 70,
      maxWidth: 70,
    },
    {
      key: "ismember",
      name: "Is Member",
      fieldName: "IsMember",
      minWidth: 70,
      maxWidth: 70,
    },
    // {
    //   key: "canjoin",
    //   name: "Can Join",
    //   fieldName: "CanJoin",
    //   minWidth: 70,
    //   maxWidth: 70,
    // },     
    {
      key: "defaultlcid",
      name: "Default LCID",
      fieldName: "DefaultLcid",
      minWidth: 80,
      maxWidth: 80,
    },
    {
      key: "admins",
      name: "#Admins",
      fieldName: "Admins",
      minWidth: 70,
      maxWidth: 70,
    },
    {
      key: "adgroups",
      name: "#AD Groups",
      fieldName: "AdGroups",
      minWidth: 70,
      maxWidth: 70,
    },    
  ];
};

const itemColumnRenderer = (
  item: ILocalEntityExtended,
  index: number,
  column: IColumn
) => {
  const fieldContent = item[column.fieldName as keyof ILocalEntityExtended] as string;

  switch (column.key) {
    case "isdefault":
      return BooleanRenderer(item.IsDefault);
    case "ismember":
      return BooleanRenderer(item.IsMember);
      case "canjoin":
        return BooleanRenderer(item.CanJoin);      
    case "Title":
      return (
        <Link to={`/local-entities/${item.Id}/view`}>
          {fieldContent}
        </Link>
      );
    case "admins":
      return item.Admins.length.toString();
      case "adgroups":
        return item.AdGroups.length.toString();      
    default:
      return <span>{fieldContent}</span>;
  }
};

export const LocalEntityList = (props: ILocalEntityListProps) => {
  const {logService} = useGlobalContext();
  
  useEffect(() => {
    logService.debug("TaskList useEffect props:", props);
  }, []);

  const columns = generateColumns();

  return (
    <div className="ms-Grid" dir="ltr">
      <div className="ms-Grid-row">
        <div className="ms-Grid-col ms-sm12">
          <DetailsList
            items={props.localEntities}
            columns={columns}
            onRenderItemColumn={itemColumnRenderer}
            layoutMode={DetailsListLayoutMode.justified}
            selectionMode={SelectionMode.none}
          ></DetailsList>
        </div>
      </div>
    </div>
  );
};
