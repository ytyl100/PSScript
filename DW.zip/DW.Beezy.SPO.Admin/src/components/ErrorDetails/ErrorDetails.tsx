
import * as React from "react";

export interface IErrorDetailsProps {
  message: string;
}

export const ErrorDetails: React.FunctionComponent<IErrorDetailsProps> = (props: IErrorDetailsProps) => {
  return (
    <div>
      <h3>Error:</h3>
      <div>{props.message}</div>
    </div>
  );
};