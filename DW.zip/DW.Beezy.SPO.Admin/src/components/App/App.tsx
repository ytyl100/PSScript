import * as React from "react";
import { useState } from "react";


import { HashRouter, Route, Switch } from "react-router-dom";
import { HomePage, NotFoundPage, UserPage } from "../../pages";
import { Header } from "../../layouts";
import { ErrorDetails, IAppProps, Loader } from "..";

//import "office-ui-fabric-react/dist/css/fabric.css";

require("./../../styles/dw.css");
import { useEffect, useReducer } from "react";
import { AppContext } from "../../state/context";
import { appReducer, setAppStatus, setLocalEntities, setUser, setIsImpersonated } from "../../state/reducer";
import { AppStatus, initialAppState } from "../../state/state";
import ErrorBoundary from "../ErrorBoundary/ErrorBoundary";
import { GlobalContext } from "../../hooks";
import { BeezyAdminApi } from "../../apis";
import { IAppUser } from "../../models";
import { LocalEntitiesPage } from "../../pages/LocalEntitiesPage/LocalEntitiesPage";
import { ActionResultStatus, AppMode } from "../../enums";
import { ILogService } from "../../services";


const App = (props: IAppProps) => {
  const mode: AppMode = props.mode;
  const user: IAppUser = props.user;
  const beezyAdminApi: BeezyAdminApi = new BeezyAdminApi(props.beezyAdminService, props.logService);
  const logService: ILogService = props.logService;

  const [errorMessage, setErrorMessage] = useState<string>("");
  const [loadingMessage, setLoadingMessage] = useState<string>("");
  const [state, dispatch] = useReducer(appReducer, initialAppState);

  const loadDataAsync = async () => {
    try {
      const currentUser = await beezyAdminApi.loadUser();

      if (currentUser.status !== ActionResultStatus.Success) {
        setErrorMessage(currentUser.errorMessage);
        dispatch(setAppStatus(AppStatus.Error));
        return;
      }

      if (currentUser.data && currentUser.authenticatedUser) {
        if (currentUser.data.LoginName !== currentUser.authenticatedUser) {
          dispatch(setIsImpersonated(true));
        }
      }

      dispatch(setUser(currentUser.data));

      const localEntities = await beezyAdminApi.loadLocalEntities(currentUser.data);
      if (localEntities.status !== ActionResultStatus.Success) {
        setErrorMessage(localEntities.errorMessage);
        dispatch(setAppStatus(AppStatus.Error));
        return;
      }

      dispatch(setLocalEntities(localEntities.data));
    } catch (error) {
      dispatch(setAppStatus(AppStatus.Error));
      setErrorMessage("eeeeee......eeeee");
    }
  };

  useEffect(() => {
    logService.debug("status change", state.status);
  }, [state.status]);

  useEffect(() => {
    dispatch(setAppStatus(AppStatus.Loading));
    setLoadingMessage('Loading App Data');
    loadDataAsync().then(() => {
      dispatch(setAppStatus(AppStatus.Success));
    }).catch((error: any) => {
      logService.error('Load Data Error', error);
      dispatch(setAppStatus(AppStatus.Error));
    });
  }, []);

  return (
    <React.StrictMode>
      <GlobalContext.Provider value={{ user, beezyAdminApi, logService: logService, mode }}>
        <AppContext.Provider value={{ state, dispatch }}>
          <ErrorBoundary message="App Boundary" logService={logService} >
            <div className="dw-app">
              <HashRouter>
                <div className="dw-outer-container-header">
                  <div className="ms-Grid dw-container" dir="ltr">

                    <header className="ms-Grid-row">
                      <div className="ms-Grid-col ms-sm12">
                        <Header backLink={props.referrerUrl}></Header>
                      </div>
                    </header>
                  </div>
                </div>
                <div className="dw-outer-container-content">
                  <div className="ms-Grid dw-container" dir="ltr">

                    {(state.status === AppStatus.Loading ||
                      state.status === AppStatus.Empty) && (
                        <main className="ms-Grid-row">
                          <div className="ms-Grid-col ms-sm12">
                            <Loader message={loadingMessage}></Loader>
                          </div>
                        </main>
                      )}

                    {(state.status === AppStatus.Error) && (
                      <main className="ms-Grid-row">
                        <div className="ms-Grid-col ms-sm12">
                          <ErrorDetails message={errorMessage}></ErrorDetails>
                        </div>
                      </main>
                    )}

                    {(state.status === AppStatus.Success) && (
                      <div className="ms-Grid-col ms-sm12">
                        <main className="ms-Grid-row">
                          <div className="ms-Grid-col ms-sm12">
                            <Switch>
                              <Route exact path="/" component={HomePage} />
                              <Route path="/user" component={UserPage} />
                              <Route path="/local-entities" component={LocalEntitiesPage} />
                              <Route path="*">
                                <NotFoundPage></NotFoundPage>
                              </Route>
                            </Switch>
                          </div>
                        </main>
                      </div>
                    )}

                  </div>
                </div>
              </HashRouter>
            </div>
          </ErrorBoundary>
        </AppContext.Provider>
      </GlobalContext.Provider>
    </React.StrictMode>
  );
};

export default App;

