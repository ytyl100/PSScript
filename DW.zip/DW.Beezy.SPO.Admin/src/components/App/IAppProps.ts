

import { AppMode } from "../../enums";
import { IAppUser } from "../../models";
import { IBeezyAdminService, ILogService } from "../../services";

export interface IAppProps {
  
  beezyAdminService: IBeezyAdminService;
  logService: ILogService;
  description: string;
  user: IAppUser;
  mode: AppMode;  
  siteUrl?: string;
  referrerUrl?: string;
}
