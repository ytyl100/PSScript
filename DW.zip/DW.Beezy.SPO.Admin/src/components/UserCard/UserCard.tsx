import {
  DetailsList,
  DetailsListLayoutMode,
  DocumentCard,
  DocumentCardActions,
  DocumentCardDetails,
  DocumentCardImage,
  DocumentCardTitle,
  IColumn,
  IDocumentCardStyles,
  IDocumentCardTitleStyles,
  IIconProps,
  ImageFit,
  SelectionMode,
} from "office-ui-fabric-react";
import * as React from "react";

import { useEffect } from "react";
import { useGlobalContext } from "../../hooks";

import { IBeezyCurrentUser } from "../../models";


export interface IUserCardProps {
  user: IBeezyCurrentUser;
  isImersonated: boolean;
}

export const UserCard = (props: IUserCardProps) => {
  const { logService } = useGlobalContext();
  let user: IBeezyCurrentUser;

  useEffect(() => {
    logService.debug("User Card useEffect props", props);
    if (props.user) {
      user = props.user;
    }
  }, []);

  const userIconProps: IIconProps = {
    iconName: 'UserOptional',
    styles: {
      root: { color: "#DB0011", fontSize: "40px", width: "40px", height: "40px" },
    },
  };


  const cardStyles: IDocumentCardStyles = {
    root: {
      display: "inline-block",
      marginBottom: 20,
      width: "100%",
      maxWidth: "100%",
      minWidth: "100%",
    },
  };

  const cardTitleStyles: IDocumentCardTitleStyles = { root: { height: 'auto' } };


  const documentCardActions = [

  ];


  let description: string = `My Details`;
  if (props.isImersonated) {
    description += ` (Impersonated)`;
  }

  let localEntityDetails: string = '';
  if (!props.user || !props.user.LocalEntity) {
    localEntityDetails += ` - `;
  } else {
    localEntityDetails += ` ${props.user.LocalEntity.Title}`;
  }

  return (
    <div>
      <DocumentCard styles={cardStyles} onClickHref={`#/user`}>
        <DocumentCardImage
          height={100}
          imageFit={ImageFit.centerCover}
          iconProps={userIconProps}
        />
        <DocumentCardDetails>
          <DocumentCardTitle title={description} shouldTruncate />

          {props.user &&
            <>
              <DocumentCardTitle title={`Name: ${props.user.FullName}`} styles={cardTitleStyles} showAsSecondaryTitle />
              <DocumentCardTitle title={`Email: ${props.user.Email}`} styles={cardTitleStyles} showAsSecondaryTitle />
              <DocumentCardTitle title={`Local Entity: ${localEntityDetails}`} styles={cardTitleStyles} showAsSecondaryTitle />
            </>
          }

        </DocumentCardDetails>
        <DocumentCardActions actions={documentCardActions}>

        </DocumentCardActions>
      </DocumentCard>
    </div>
  );
};
