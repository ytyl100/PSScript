import {
  DetailsList,
  DetailsListLayoutMode,
  DocumentCard,
  DocumentCardActions,
  DocumentCardDetails,
  DocumentCardImage,
  DocumentCardTitle,
  IColumn,
  IDocumentCardStyles,
  IDocumentCardTitleStyles,
  IIconProps,
  ImageFit,
  SelectionMode,
} from "office-ui-fabric-react";
import * as React from "react";

import { useEffect } from "react";
import { useGlobalContext } from "../../hooks";

import { ILocalEntity, ILocalEntityExtended } from "../../models";


export interface ILocalEntitiesCardProps {
  localEntities: ILocalEntityExtended[];
}

export const LocalEntitiesCard = (props: ILocalEntitiesCardProps) => {
  const { logService } = useGlobalContext();

  useEffect(() => {
    logService.debug("Local Entities Card useEffect props:", props);
  }, []);

  const userIconProps: IIconProps = {
    iconName: 'CheckList',
    styles: {
      root: { color: "#DB0011", fontSize: "40px", width: "40px", height: "40px" },
    },
  };


  const cardStyles: IDocumentCardStyles = {
    root: {
      display: "inline-block",
      marginBottom: 20,
      width: "100%",
      maxWidth: "100%",
      minWidth: "100%",
    },
  };

  const cardTitleStyles: IDocumentCardTitleStyles = { root: { height: 'auto' } };
  
  const documentCardActions = [
    // {
    //   iconProps: { iconName: 'Share' },
    //   onClick: onActionClick.bind(this, 'share'),
    //   ariaLabel: 'share action',
    // },
    // {
    //   iconProps: { iconName: 'Pin' },
    //   onClick: onActionClick.bind(this, 'pin'),
    //   ariaLabel: 'pin action',
    // },
    // {
    //   iconProps: { iconName: 'Ringer' },
    //   onClick: onActionClick.bind(this, 'notifications'),
    //   ariaLabel: 'notifications action',
    // },
  ];


  // {props.localEntities &&
  //   <div>
  //     <div>Count: {props.localEntities.length}</div>
  //   </div>
  // }

  const description: string = `Local Entities`;

  return (

    <div>
      <DocumentCard styles={cardStyles} onClickHref={`#/local-entities`}>
        <DocumentCardImage
          height={100}
          imageFit={ImageFit.centerCover}
          iconProps={userIconProps}
        />
        <DocumentCardDetails>
          <DocumentCardTitle title={description} shouldTruncate />

          {props.localEntities &&
            <>
              <DocumentCardTitle title={`There are currently ${props.localEntities.length} Local Entities`} styles={cardTitleStyles} showAsSecondaryTitle />
            </>
          }

        </DocumentCardDetails>
        <DocumentCardActions actions={documentCardActions}>
        </DocumentCardActions>
      </DocumentCard>
    </div>
  );
};
