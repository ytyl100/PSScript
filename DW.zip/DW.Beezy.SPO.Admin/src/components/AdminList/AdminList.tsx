import { DetailsList, DetailsListLayoutMode, IColumn, SelectionMode } from "office-ui-fabric-react";
import * as React from "react";
import { IAppUser, IBeezyUser } from "../../models";


export interface IAdminListProps {
    admins: IBeezyUser[];
}

interface IAdminListItem {
    key: number;
    name: string;
    email: string;
}

export const AdminList = (props: IAdminListProps) => {
    const columns: IColumn[] = [
        {
            key: "name",
            name: "Name",
            fieldName: "name",
            minWidth: 20,
            isResizable: true,
        },
        {
            key: "email",
            name: "Email",
            fieldName: "email",
            minWidth: 320,
            isResizable: true,
        },
    ];

    const items: IAdminListItem[] = props.admins.map((admin: IBeezyUser, idx: number) => {
        return {
            key: admin.Id,
            name: admin.FullName,
            email: admin.Email,
        };
    });

    return (
        <DetailsList
            compact={true}
            items={items}
            columns={columns}
            layoutMode={DetailsListLayoutMode.justified}
            selectionMode={SelectionMode.none}
        ></DetailsList>
    );
};
