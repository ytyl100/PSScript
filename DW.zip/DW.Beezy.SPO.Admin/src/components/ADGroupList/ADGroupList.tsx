import { DetailsList, DetailsListLayoutMode, IColumn, SelectionMode } from "office-ui-fabric-react";
import * as React from "react";



export interface IADGroupListProps {
    adGroups: string[];
}

interface IADGroupListItem {
    key: number;
    name: string;
}

export const ADGroupList = (props: IADGroupListProps) => {
    const columns: IColumn[] = [
        {
            key: "name",
            name: "Name",
            fieldName: "name",
            minWidth: 80,
        },
    ];

    const items: IADGroupListItem[] = props.adGroups.map((adGroup:string, idx: number) => {
        return {
            key: idx,
            name: adGroup,
        };
    });

    return (
        <DetailsList
            compact={true}
            items={items}
            columns={columns}
            layoutMode={DetailsListLayoutMode.justified}
            selectionMode={SelectionMode.none}
        ></DetailsList>
    );
};
