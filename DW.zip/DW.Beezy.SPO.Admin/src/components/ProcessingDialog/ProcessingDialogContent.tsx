import { DefaultButton, DialogContent, DialogFooter, PrimaryButton } from 'office-ui-fabric-react';
import * as React from 'react';
import { IProcessingDialogContentProps, IProcessingDialogContentState } from '..';

import styles from './ProcessingDialogContent.module.scss';
export class ProcessingDialogContent extends React.Component<IProcessingDialogContentProps, IProcessingDialogContentState> {

  constructor(props: IProcessingDialogContentProps) {
    super(props);

    this.state = {
      message: props.title
    };
  }

  public render(): JSX.Element {
    return (
      <div className={styles.dwDialog}>
        <DialogContent title={this.props.title} subText={this.props.message} showCloseButton={this.props.canClose} onDismiss={this.props.close}></DialogContent>
      </div>
    );
  }

  // private _onColorChange = (ev: React.SyntheticEvent<HTMLElement, Event>, answer: boolean) => {
  //   this._answer = answer;
  // }
}