import * as React from 'react';
import * as ReactDOM from 'react-dom';
import { BaseDialog } from '@microsoft/sp-dialog';
import { ProcessingDialogContent } from '..';


export default class ProcessingDialog extends BaseDialog {
    constructor(public message: string, public title: string, public canClose: boolean = false) {
        super({ isBlocking: true });
    }

    public render(): void {        
        ReactDOM.render(<ProcessingDialogContent 
            canClose={this.canClose}
            close={this.close}
            message={this.message}
            title={this.title}
        />, this.domElement);
    }

    // public getConfig(): IDialogConfiguration {
    //     return { isBlocking: this.isBlocking };
    // }

    protected onAfterClose(): void {
        super.onAfterClose();

        // Clean up the element for the next dialog
        ReactDOM.unmountComponentAtNode(this.domElement);
    }
}