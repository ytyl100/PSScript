export interface IProcessingDialogContentState {
    message: string;
}