export interface IProcessingDialogContentProps {
    canClose: boolean;
    close: () => void;
    message: string;
    title: string;
}