import { IBeezyCurrentUser, ILocalEntity, ILocalEntityExtended } from "../models";
import { AppStatus } from "./state";

export enum ActionType {
    UpdateLocalEntity,
    SetLocalEntities,
    SetAppStatus,
    SetUser,
    SetIsImpersonated,
}

export interface UpdateLocalEntity{
    type: ActionType.UpdateLocalEntity;
    payload: ILocalEntityExtended;
}

export interface SetLocalEntities{
    type: ActionType.SetLocalEntities;
    payload: ILocalEntityExtended[];
}

export interface SetAppStatus {
    type:ActionType.SetAppStatus;
    payload: AppStatus;
}

export interface SetUser {
    type: ActionType.SetUser;
    payload: IBeezyCurrentUser;
}

export interface SetIsImpersonated {
    type: ActionType.SetIsImpersonated;
    payload: boolean;
}
export type AppActions = UpdateLocalEntity | SetLocalEntities | SetAppStatus | SetUser | SetIsImpersonated;

