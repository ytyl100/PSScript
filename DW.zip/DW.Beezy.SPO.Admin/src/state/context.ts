import * as React from "react";
import { AppActions } from "./actions";
import { AppState, initialAppState } from "./state";

export const AppContext = React.createContext<{
  state: AppState;
  dispatch: React.Dispatch<AppActions>;
}>({ state: initialAppState, dispatch: () => undefined });

export const useAppContext = () => React.useContext(AppContext);
