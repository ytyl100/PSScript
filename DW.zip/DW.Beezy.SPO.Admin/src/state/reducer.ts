import { IBeezyCurrentUser, ILocalEntityExtended } from "../models";
import {
  ActionType,
  AppActions,
  SetAppStatus,
  SetLocalEntities,
  SetUser,
  SetIsImpersonated,
  UpdateLocalEntity,
} from "./actions";
import { AppState, AppStatus } from "./state";

export const appReducer = (state: AppState, action: AppActions): AppState => {
  switch (action.type) {
    case ActionType.SetLocalEntities:
      return {
        ...state,
        localEntities: [...action.payload],
      };
    case ActionType.SetAppStatus:
      return {
        ...state,
        status: action.payload,
      };
    case ActionType.SetUser:
      return {
        ...state,
        user: action.payload,
      };
    case ActionType.SetIsImpersonated:
      return {
        ...state,
        isImpersonated: action.payload,
      };
    case ActionType.UpdateLocalEntity:
      const idx = state.localEntities.findIndex((t) => t.Id === action.payload.Id);

      const newArray = [...state.localEntities];
      newArray[idx] = action.payload;

      return {
        ...state,
        localEntities: newArray,
      };

    default:
      return state;
  }
};

export const setLocalEntities = (localEntities: ILocalEntityExtended[]): SetLocalEntities => ({
  type: ActionType.SetLocalEntities,
  payload: localEntities,
});

export const updateLocalEntity = (localEntity: ILocalEntityExtended): UpdateLocalEntity => ({
  type: ActionType.UpdateLocalEntity,
  payload: localEntity,
});

export const setAppStatus = (status: AppStatus): SetAppStatus => ({
  type: ActionType.SetAppStatus,
  payload: status,
});

export const setUser = (user: IBeezyCurrentUser): SetUser => ({
  type: ActionType.SetUser,
  payload: user,
});

export const setIsImpersonated = (isImpersonated: boolean): SetIsImpersonated => ({
  type: ActionType.SetIsImpersonated,
  payload: isImpersonated,
});
