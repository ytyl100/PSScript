import { IBeezyCurrentUser, ILocalEntity, ILocalEntityExtended } from "../models";

export interface AppState {
  isImpersonated: boolean;
  user: IBeezyCurrentUser;
  localEntities: ILocalEntityExtended[];
  status: AppStatus;
}

export enum AppStatus {
  Empty = "Empty",
  Loading = "Loading",
  Error = "Error",
  Success = "Success",
}

export const initialAppState: AppState = {
  isImpersonated: false,
  user: undefined,
  localEntities: [],
  status: AppStatus.Empty,
};
