export interface ILocalEntity {
    Id: number;
    Title: string;
    IsDefault: boolean;
    CurrentUserIsMember: boolean;
}