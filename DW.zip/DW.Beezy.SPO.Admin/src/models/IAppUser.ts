export interface IAppUser {
  readonly displayName: string;
  readonly email: string;
  readonly loginName: string;
}
