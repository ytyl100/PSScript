import { IBeezyUserLocalEntity } from ".";
import { IBeezyUser } from "./IBeezyUser";

export interface IBeezyCurrentUser extends IBeezyUser {
    LoginName: string;
    LocalEntity: IBeezyUserLocalEntity;
}