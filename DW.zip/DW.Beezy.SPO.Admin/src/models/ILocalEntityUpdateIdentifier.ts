import { Guid } from "@microsoft/sp-core-library";

export interface ILocalEntityUpdateIdentifier{
    targetLocalEntityId: number;
    userLoginId?:string;
}