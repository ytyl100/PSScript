export interface IBeezyUser {
    Id: number;
    FullName: string;
    Email: string;
}
