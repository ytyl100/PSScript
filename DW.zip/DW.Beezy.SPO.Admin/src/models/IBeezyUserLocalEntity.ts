export interface IBeezyUserLocalEntity {
    Id: number;
    IsDefaultLocalEntity: boolean;
    Title: string;
}