import { BeezyResultStatus } from "../enums";
import { IBeezyResultException } from "./IBeezyResultException";

export interface IBeezyResultBase {
    Status: BeezyResultStatus;
    StatusText: string;
    AuthenticatedUser: string;
    Exception: IBeezyResultException;
}

export interface IBeezyResult<T> extends IBeezyResultBase {
    ResponseItem: T;
}