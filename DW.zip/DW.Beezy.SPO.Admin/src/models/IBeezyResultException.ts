export interface IBeezyResultException {
    Reason: string;
    Function: string;
    FunctionParams: string[];
    ErrorMessage: string;
    Exception: IBeezyResultException;
}
