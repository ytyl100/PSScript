export interface ILocalEntityJoinResult {
    UserId: number;
    UserLoginName: string;
    UserFullName: string;
    SourceLocalEntityId?: number;
    SourceLocalEntityTitle: string;
    TargetLocalEntityId: number;
    TargetLocalEntityTitle: string;
}