import { IBeezyUser, ILocalEntity } from ".";

export interface ILocalEntityExtended extends ILocalEntity {
    Admins: IBeezyUser[];
    AdGroups: string[];
    DefaultLcid: string;
    Branding: string;
    HeroModuleEnabled: boolean;
    NavigationModuleEnabled: boolean;
    StoriesModuleEnabled: boolean;
    PagesModuleEnabled: boolean;
    AppsModuleEnabled: boolean;
    DiscoveryCardsModuleEnabled: boolean;
    IsMember: boolean;
    CorporateModuleId: string;
    EditorialModuleId: string;
    CanJoin: boolean;
    CanOverride: boolean;
}