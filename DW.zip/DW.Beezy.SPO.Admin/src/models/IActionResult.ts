import { ActionResultStatus } from "../enums";

export interface IActionResultBase {
    status: ActionResultStatus;
    errorMessage?: string;
    authenticatedUser?: string;
}

export interface IActionResult<T> extends IActionResultBase {
    data?: T;
}