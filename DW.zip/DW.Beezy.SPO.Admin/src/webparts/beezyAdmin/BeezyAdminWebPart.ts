import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Log, Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneCheckbox,
  PropertyPaneTextField,
  PropertyPaneToggle
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';

import * as strings from 'BeezyAdminWebPartStrings';
import { IBeezyAdminService, ITokenService, BeezyAdminService, TokenService, ILogService, LogService } from '../../services';
import { App, IAppProps } from '../../components';
import { IAppUser } from '../../models';
import { AppMode } from '../../enums';
import { ErrorUtils } from '../../utils';

export interface IBeezyAdminWebPartProps {
  description: string;
  beezyAdminApiUrl: string;
  dwLandingPageUrl: string;
  applicationId: string;
  authenticationEnabled: boolean;
  scopes: string;
}

export default class BeezyAdminWebPart extends BaseClientSideWebPart<IBeezyAdminWebPartProps> {
  private logService: ILogService = undefined;
  private appMode: AppMode = AppMode.Normal;


  protected onInit(): Promise<void> {
    this.appMode = this.getAppMode();
    this.logService = new LogService("DW Log", this.appMode);
    ErrorUtils.init(this.logService);
    return Promise.resolve();
  }

  protected get disableReactivePropertyChanges(): boolean {
      return true;
  }

  protected onAfterPropertyPaneChangesApplied(): void {
      ReactDom.unmountComponentAtNode(this.domElement);
  }

  private constructBackLinkUrl = (referrer: string): string => {
    if (referrer === "" || referrer === null || referrer === undefined) {
      return this.properties.dwLandingPageUrl;
    }

    return document.referrer;
  }

  private constructAppUser = (): IAppUser => {
    const user: IAppUser = {
      displayName: this.context.pageContext.user.displayName,
      email: this.context.pageContext.user.email,
      loginName: this.context.pageContext.user.loginName,
    };
    this.logService.debug('constructAppUser', user);
    return user;
  }

  private constructTokenServiceInstance = () : ITokenService => {
    if(!this.properties.authenticationEnabled){
      return null;
    }
    
    let scopes: string[];
    if (this.properties.scopes !== null && this.properties.scopes !== undefined && this.properties.scopes !== '') {
      scopes = this.properties.scopes.split(',');
    }    
    return new TokenService(this.logService, this.context.pageContext.aadInfo.tenantId, this.properties.applicationId, this.context.pageContext.user.email, scopes);
  }

  private beezyAdminService = (): IBeezyAdminService => {

    const tokenService: ITokenService = this.constructTokenServiceInstance();

    const beezyAdminService: IBeezyAdminService = new BeezyAdminService(
      this.context.serviceScope,
      this.context.httpClient,
      tokenService,
      this.logService,
      this.properties.beezyAdminApiUrl, 
      this.properties.authenticationEnabled,
      this.context.pageContext.user.loginName,
      this.getTargetUPN()
    );

    return beezyAdminService;
  }

  private getAppMode = (): AppMode => {
    const urlSearchParams = new URLSearchParams(window.location.search);
    const code = urlSearchParams.get('mode');
    if (code !== undefined && code !== null && code === 'debug') {
      return AppMode.Debug;
    }
    return AppMode.Normal;
  }

  private getTargetUPN = (): string => {
    const urlSearchParams = new URLSearchParams(window.location.search);
    const code = urlSearchParams.get('upn');
    if (code !== undefined && code !== null && code !== '') {
      this.logService.warn(`Impersonating ${code}`);
      return code;
    }
    return null;
  }

  public render(): void {
    const beezyAdminService: IBeezyAdminService = this.beezyAdminService();

    const appSettings: IAppProps = {
      logService: this.logService,
      beezyAdminService: beezyAdminService,
      description: this.properties.description,
      user: this.constructAppUser(),
      mode: this.appMode,
      siteUrl: this.context.pageContext.web.absoluteUrl,
      referrerUrl: this.constructBackLinkUrl(document.referrer),
    };

    const element: React.ReactElement<IAppProps> = React.createElement(App, appSettings);

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse("1.0");
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription,
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField("description", {
                  label: strings.DescriptionFieldLabel,
                }),
                PropertyPaneTextField("beezyAdminApiUrl", {
                  label: strings.BeezyAdminApiUrlFieldLabel,
                }),
                PropertyPaneTextField("dwLandingPageUrl", {
                  label: strings.DWLandingPageUrlFieldLabel,
                }),
                PropertyPaneToggle("authenticationEnabled", 
                { 
                  label: strings.AuthenticationEnabledFieldLabel, 
                }),
                PropertyPaneTextField("applicationId", {
                  label: strings.ApplicationIdFieldLabel,
                }),
                PropertyPaneTextField("scopes", {
                  label: strings.ScopesFieldLabel,
                }),
              ],
            },
          ],
        },
      ],
    };
  }
}
