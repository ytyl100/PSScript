define([], function() {
  return {
    "PropertyPaneDescription": "Description",
    "BasicGroupName": "Group Name",
    "DescriptionFieldLabel": "Description Field",
    "BeezyAdminApiUrlFieldLabel": "Beezy Admin Api Url",
    "DWLandingPageUrlFieldLabel" : "Digital Workplace Landing Page Url",
    "ApplicationIdFieldLabel":"Application Registration Id",
    "AuthenticationEnabledFieldLabel": "Authentication Enabled",    
    "ScopesFieldLabel":"Scopes",
  }
});