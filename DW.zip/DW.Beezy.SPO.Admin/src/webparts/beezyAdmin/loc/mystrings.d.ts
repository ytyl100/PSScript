declare interface IBeezyAdminWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
  BeezyAdminApiUrlFieldLabel:string;
  DWLandingPageUrlFieldLabel:string;
  ApplicationIdFieldLabel:string;
  AuthenticationEnabledFieldLabel:string;  
  ScopesFieldLabel:string;
}

declare module 'BeezyAdminWebPartStrings' {
  const strings: IBeezyAdminWebPartStrings;
  export = strings;
}
