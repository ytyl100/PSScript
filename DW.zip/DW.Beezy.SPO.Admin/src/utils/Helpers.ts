export class Helpers {
  public static DeserializeToDate(data: any): Date {
    return new Date(data);
  }

  public static async Sleep(ms:number): Promise<void>{
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}