import { IBeezyResultBase } from "../models";
import { ILogService } from "../services";

export class ErrorUtils {
    private static logService : ILogService;

    public static init = ((ls:ILogService)=>{
        ErrorUtils.logService = ls;
    });

    public static GenerateGenericErrorMessage(error: any): string {
        ErrorUtils.logService.error("Generic Error", error);
        return `App Generic Error`;
    }
    
    public static GenerateBeezyResultExceptionErrorMessage(beezyResult: IBeezyResultBase): string {
        ErrorUtils.logService.error("Beezy Error", beezyResult.Exception);
        return `App Beezy Error ${beezyResult.Exception.Reason}`;
    }

    public static GenerateHttpResponseErrorMessage(status: number, text: string): string {
        const errorMessage: string = `App Http Reponse Error ${status} - ${text}`;
        ErrorUtils.logService.error(errorMessage);
        return errorMessage;
    }
}