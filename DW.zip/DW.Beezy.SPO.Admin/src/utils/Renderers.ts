export const DateToStringRenderer = (date: Date) => {
    return date.toDateString();
};

export const BooleanRenderer = (val:boolean) : string =>  {
  if(val == null){
    return 'Not Set';
  }

  return val === true ? 'Yes' : 'No';
};