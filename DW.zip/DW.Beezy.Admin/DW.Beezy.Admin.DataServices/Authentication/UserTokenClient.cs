﻿using DW.Beezy.Admin.Common.Logging;
using Microsoft.Extensions.Logging;
using Microsoft.Identity.Client;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace DW.Beezy.Admin.DataServices.Authentication
{
    // APP REGISTRATION:
    // - Allow Public Client Flows (Manage > Authentication > Advanced Settings)
    // - Create Client Secret (Manage > Certificates & secrets)
    // - Microsoft.Graph User.Read Delegated permission (Manage > API Permissions)
    public class UserTokenClientSettings
    {
        public string TenantId { get; set; }

        public string ServiceAccountAuthAppClientId { get; set; }

        public string ServiceAccountAuthAppClientSecret { get; set; }

        public string ServiceAccount { get; set; }

        public string ServiceAccountPassword { get; set; }

        public string ProxyAddress { get; set; }
    }

    public interface ITokenClient
    {
        public Task<string> GetTokenAsync(IEnumerable<string> scopes);
    }

    public class UserTokenClient : ITokenClient
    {
        private readonly UserTokenClientSettings _settings;
        private readonly ILogger<UserTokenClient> _logger;
        private readonly IMsalHttpClientFactory _httpClientFactory;

        public UserTokenClient(UserTokenClientSettings settings, IMsalHttpClientFactory httpClientFactory, ILogger<UserTokenClient> logger)
        {
            this._logger = logger;
            _settings = settings;
            _httpClientFactory = httpClientFactory;
        }

        public async Task<string> GetTokenAsync(IEnumerable<string> scopes)
        {
            _logger.LogInformation(LoggingEvents.DW_BEEZY_ADMIN_UserTokenClient_Info, "GetTokenAsync(): Started");

            // TODO: Use dependency injection

            var app = PublicClientApplicationBuilder
                .Create(_settings.ServiceAccountAuthAppClientId)
                .WithHttpClientFactory(_httpClientFactory)
                .WithTenantId(_settings.TenantId)
                .WithExtraQueryParameters($"client_secret={_settings.ServiceAccountAuthAppClientSecret}")
                .WithLogging((level, message, containsPii) =>
                {
                    _logger.LogInformation(LoggingEvents.DW_BEEZY_ADMIN_UserTokenClient_Info, "GetTokenAsync(): Started", level, message);
                    Console.WriteLine("Error when using Public Client");
                    Console.WriteLine($"{level}: {message}");
                }, Microsoft.Identity.Client.LogLevel.Verbose, true, true)
                .Build();


            AuthenticationResult result = await app.AcquireTokenByUsernamePassword(scopes, _settings.ServiceAccount,
                new NetworkCredential(string.Empty, _settings.ServiceAccountPassword).SecurePassword).ExecuteAsync();

            _logger.LogInformation(LoggingEvents.DW_BEEZY_ADMIN_UserTokenClient_Info, $"GetTokenAsync(): Completed. Token expires on '{result.ExpiresOn.UtcDateTime}'");

            var userToken = result.AccessToken;
            return userToken;
        }
    }
}

