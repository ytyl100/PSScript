﻿using Microsoft.Identity.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace DW.Beezy.Admin.DataServices.Authentication
{
    public class HttpFactoryWithProxy : IMsalHttpClientFactory
    {
        private static HttpClient _httpClient;

        public HttpFactoryWithProxy(UserTokenClientSettings settings)
        {
            // Consider using Lazy<T> 
            if (_httpClient == null)
            {
                var httpClientHandler = new HttpClientHandler();

                if (!string.IsNullOrEmpty(settings.ProxyAddress))
                {
                    var proxy = new WebProxy
                    {
                        Address = new Uri(settings.ProxyAddress),
                        BypassProxyOnLocal = false,
                        UseDefaultCredentials = true,
                    };

                    httpClientHandler.Proxy = proxy;
                }

                _httpClient = new HttpClient(handler: httpClientHandler);            
            }
        }

        public HttpClient GetHttpClient()
        {
            return _httpClient;
        }
    }
}
