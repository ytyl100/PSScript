﻿using DW.Beezy.Admin.Common.Enums;
using DW.Beezy.Admin.Common.Exceptions;
using DW.Beezy.Admin.Common.Logging;
using DW.Beezy.Admin.Common.Models;
using DW.Beezy.Admin.DataServices.Authentication;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace DW.Beezy.Admin.DataServices
{
    public class BeezyDataServiceSettings
    {
        public string TenantName { get; set; }

        public string BeezyApiSiteName { get; set; }

        public string BeezySharePointSiteName { get; set; }
    }

    public class BeezyDataService : BaseHttpDataService, IBeezyDataService
    {
        protected BeezyDataServiceSettings _settings;
        private readonly ILogger<BeezyDataService> _logger;

        protected override string AcceptHeader => "application/json";

        protected override string Scope => $"https://{_settings.TenantName}.sharepoint.com/.default";

        protected override JToken GetJsonRoot(string json) => JToken.Parse(json);

        public BeezyDataService(ITokenClient tokenClient, HttpClient httpClient, BeezyDataServiceSettings settings, ILogger<BeezyDataService> logger) : base(tokenClient, httpClient)
        {
            this._logger = logger;
            _settings = settings;
        }

        public async Task<List<LocalEntity>> GetLocalEntities()
        {
            string functionName = "GetLocalEntities";

            try
            {
                _logger.LogInformation(LoggingEvents.DW_BEEZY_ADMIN_DataService_Info, $"BeezyDataService.{functionName}()");

                string siteCollectionUrl = $"https://{_settings.TenantName}.sharepoint.com/sites/{_settings.BeezySharePointSiteName}";
                string url = $"https://{_settings.BeezyApiSiteName}/Api/GraphQL?SPHostUrl={siteCollectionUrl}&languageId=1033";

                List<GraphQLRequestItem> request = new()
                {
                    new GraphQLRequestItem
                    {
                        OperationName = "getEntities",
                        Query = "query getEntities {\n localEntities {\n all {\n id\n title\n isDefault\n defaultLcid\n membersCount\n adGroups\n membersCount\n editorialModuleId\n corporateModuleId\n heroModuleEnabled\n storiesModuleEnabled\n navigationModuleEnabled\n pagesModuleEnabled\n appsModuleEnabled\n discoveryCardsModuleEnabled\n branding\n admins {\n email\n fullName\n id\n lastUpdated\n pictureUrl\n __typename\n      }\n __typename\n    }\n __typename\n  }\n}\n"
                    }
                };

                string payload = JsonConvert.SerializeObject(request);
                var body = new StringContent(payload, Encoding.UTF8, "application/json");

                var response = await PostAsync<List<LocalEntity>>(url, body, (json) => JObject.Parse(json)["data"]["localEntities"]["all"]);
                return response;
            }
            catch (Exception ex)
            {
                throw new BeezyDataServiceException(functionName, ex);
            }
        }

        public async Task<LocalEntity> EditLocalEntity(UpdatedLocalEntity updatedLocalEntity)
        {
            string functionName = "EditLocalEntity";
            string functionParams = JsonConvert.SerializeObject(updatedLocalEntity);

            try
            {
                _logger.LogInformation(LoggingEvents.DW_BEEZY_ADMIN_DataService_Info, $"BeezyDataService.{functionName}: {functionParams}");

                string siteCollectionUrl = $"https://{_settings.TenantName}.sharepoint.com/sites/{_settings.BeezySharePointSiteName}";
                string url = $"https://{_settings.BeezyApiSiteName}/Api/GraphQL?SPHostUrl={siteCollectionUrl}&languageId=1033";

                List<GraphQLRequestItem<UpdatedLocalEntity>> request = new()
                {
                    new GraphQLRequestItem<UpdatedLocalEntity>
                    {
                        OperationName = "editLocalEntity",
                        Variables = updatedLocalEntity,
                        Query = "mutation editLocalEntity($aDGroups: [String]!, $administratorsIds: [Int]!, $defaultLcid: Int!, $id: Int!, $heroModuleEnabled: Boolean, $navigationModuleEnabled: Boolean, $storiesModuleEnabled: Boolean, $pagesModuleEnabled: Boolean, $appsModuleEnabled: Boolean, $discoveryCardsModuleEnabled: Boolean, $title: String!, $branding: String) {\n  localEntities {\n    editLocalEntity(aDGroups: $aDGroups, administratorsIds: $administratorsIds, defaultLcid: $defaultLcid, id: $id, heroModuleEnabled: $heroModuleEnabled, navigationModuleEnabled: $navigationModuleEnabled, storiesModuleEnabled: $storiesModuleEnabled, pagesModuleEnabled: $pagesModuleEnabled, appsModuleEnabled: $appsModuleEnabled, discoveryCardsModuleEnabled: $discoveryCardsModuleEnabled, title: $title, branding: $branding) {\n      id\n      title\n      __typename\n    }\n    __typename\n  }\n}\n"
                    }
                };

                string payload = JsonConvert.SerializeObject(request);
                var body = new StringContent(payload, Encoding.UTF8, "application/json");

                var response = await PostAsync<LocalEntity>(url, body, (json) => JObject.Parse(json)["data"]["localEntities"]["editLocalEntity"]);
                return response;

            }
            catch (Exception ex)
            {
                throw new BeezyDataServiceException(functionName, functionParams, ex);
            }
        }

        public async Task<BeezyUser> GetUserByLogin(string loginName)
        {
            string functionName = "GetUserByLogin";
            string functionParams = JsonConvert.SerializeObject(new { loginName });

            try
            {
                _logger.LogInformation(LoggingEvents.DW_BEEZY_ADMIN_DataService_Info, $"BeezyDataService.{functionName}(): {functionParams}");

                string siteCollectionUrl = $"https://{_settings.TenantName}.sharepoint.com/sites/{_settings.BeezySharePointSiteName}";
                string url = $"https://{_settings.BeezyApiSiteName}/BeezyApi.svc/Users/ByLogin?LoginName={loginName}&SPHostUrl={siteCollectionUrl}&languageId=1033";

                var response = await GetAsync<BeezyUser>(url);
                return response;
            }
            catch (Exception ex)
            {
                throw new BeezyDataServiceException(functionName, functionParams, ex);
            }
        }

        public async Task<BeezyUser> GetUserExtendedById(int userId)
        {
            string functionName = "GetUserExtendedById";
            string functionParams = JsonConvert.SerializeObject(new { userId });

            try
            {
                _logger.LogInformation(LoggingEvents.DW_BEEZY_ADMIN_DataService_Info, $"BeezyDataService.{functionName}(): {functionParams}");

                string siteCollectionUrl = $"https://{_settings.TenantName}.sharepoint.com/sites/{_settings.BeezySharePointSiteName}";
                string url = $"https://{_settings.BeezyApiSiteName}/BeezyApi.svc/Users/{userId}/Extended?SPHostUrl={siteCollectionUrl}&languageId=1033";

                var response = await GetAsync<BeezyUser>(url);
                return response;
            }
            catch (Exception ex)
            {
                throw new BeezyDataServiceException(functionName, functionParams, ex);
            }
        }

        public async Task<List<BeezyUser>> GetStoriesUsers(string editorialModuleId)
        {
            string functionName = "GetStoriesUsers";
            string functionParams = JsonConvert.SerializeObject(new { editorialModuleId });

            try
            {
                _logger.LogInformation(LoggingEvents.DW_BEEZY_ADMIN_DataService_Info, $"BeezyDataService.{functionName}(): {functionParams}");

                string siteCollectionUrl = $"https://{_settings.TenantName}.sharepoint.com/sites/{_settings.BeezySharePointSiteName}";
                string url = $"https://{_settings.BeezyApiSiteName}/BeezyApi.svc/Editorials/{editorialModuleId}/Users/Search?SPHostUrl={siteCollectionUrl}&languageId=1033";

                var response = await GetAsync<List<BeezyUser>>(url);
                return response;
            }
            catch (Exception ex)
            {
                throw new BeezyDataServiceException(functionName, functionParams, ex);
            }
        }

        public async Task AddStoriesUserRole(string editorialModuleId, int userId, UserStoriesPagesRole role)
        {
            string functionName = "AddStoriesUserRole";
            string functionParams = JsonConvert.SerializeObject(new { editorialModuleId, userId, role });

            try
            {
                _logger.LogInformation(LoggingEvents.DW_BEEZY_ADMIN_DataService_Info, $"BeezyDataService.{functionName}(): {functionParams}");

                string siteCollectionUrl = $"https://{_settings.TenantName}.sharepoint.com/sites/{_settings.BeezySharePointSiteName}";
                string url = $"https://{_settings.BeezyApiSiteName}/BeezyApi.svc/Editorials/{editorialModuleId}/Users/Bulk?SPHostUrl={siteCollectionUrl}&languageId=1033";

                List<UserStoriesPagesRequest> request = new()
                {
                    new UserStoriesPagesRequest
                    {
                        Id = userId,
                        Function = (int)role
                    }
                };

                string payload = JsonConvert.SerializeObject(request);
                var body = new StringContent(payload, Encoding.UTF8, "application/json");

                var response = await PutAsync(url, body);
            }
            catch (Exception ex)
            {
                throw new BeezyDataServiceException(functionName, functionParams, ex);
            }
        }

        public async Task RemoveStoriesUserRole(string editorialModuleId, int userId)
        {
            string functionName = "RemoveStoriesUserRole";
            string functionParams = JsonConvert.SerializeObject(new { editorialModuleId, userId });

            try
            {
                _logger.LogInformation(LoggingEvents.DW_BEEZY_ADMIN_DataService_Info, $"BeezyDataService.{functionName}(): {functionParams}");

                string siteCollectionUrl = $"https://{_settings.TenantName}.sharepoint.com/sites/{_settings.BeezySharePointSiteName}";
                string url = $"https://{_settings.BeezyApiSiteName}/BeezyApi.svc/Editorials/{editorialModuleId}/Users/{userId}?SPHostUrl={siteCollectionUrl}&languageId=1033";

                var response = await DeleteAsync(url, null);
            }
            catch (Exception ex)
            {
                throw new BeezyDataServiceException(functionName, functionParams, ex);
            }
        }

        public async Task<List<BeezyUser>> GetPagesUsers(string corporateModuleId)
        {
            string functionName = "GetPagesUsers";
            string functionParams = JsonConvert.SerializeObject(new { corporateModuleId });

            try
            {
                _logger.LogInformation(LoggingEvents.DW_BEEZY_ADMIN_DataService_Info, $"BeezyDataService.{functionName}(): {functionParams}");

                string siteCollectionUrl = $"https://{_settings.TenantName}.sharepoint.com/sites/{_settings.BeezySharePointSiteName}";
                string url = $"https://{_settings.BeezyApiSiteName}/BeezyApi.svc/CorporateModules/{corporateModuleId}/Users/Search?SPHostUrl={siteCollectionUrl}&languageId=1033";

                var response = await GetAsync<List<BeezyUser>>(url);
                return response;
            }
            catch (Exception ex)
            {
                throw new BeezyDataServiceException(functionName, functionParams, ex);
            }
        }

        public async Task AddPagesUserRole(string corporateModuleId, int userId, UserStoriesPagesRole role)
        {
            string functionName = "AddPagesUserRole";
            string functionParams = JsonConvert.SerializeObject(new { corporateModuleId, userId, role });

            try
            {
                _logger.LogInformation(LoggingEvents.DW_BEEZY_ADMIN_DataService_Info, $"BeezyDataService.{functionName}(): {functionParams}");

                string siteCollectionUrl = $"https://{_settings.TenantName}.sharepoint.com/sites/{_settings.BeezySharePointSiteName}";
                string url = $"https://{_settings.BeezyApiSiteName}/BeezyApi.svc/CorporateModules/{corporateModuleId}/Users/Bulk?SPHostUrl={siteCollectionUrl}&languageId=1033";

                List<UserStoriesPagesRequest> request = new()
                {
                    new UserStoriesPagesRequest
                    {
                        Id = userId,
                        Function = (int)role
                    }
                };

                string payload = JsonConvert.SerializeObject(request);
                var body = new StringContent(payload, Encoding.UTF8, "application/json");

                var response = await PutAsync(url, body);
            }
            catch (Exception ex)
            {
                throw new BeezyDataServiceException(functionName, functionParams, ex);
            }

        }

        public async Task RemovePagesUserRole(string corporateModuleId, int userId)
        {
            string functionName = "RemovePagesUserRole";
            string functionParams = JsonConvert.SerializeObject(new { corporateModuleId, userId });

            try
            {
                _logger.LogInformation(LoggingEvents.DW_BEEZY_ADMIN_DataService_Info, $"BeezyDataService.{functionName}(): {functionParams}");

                string siteCollectionUrl = $"https://{_settings.TenantName}.sharepoint.com/sites/{_settings.BeezySharePointSiteName}";
                string url = $"https://{_settings.BeezyApiSiteName}/BeezyApi.svc/CorporateModules/{corporateModuleId}/Users/{userId}?SPHostUrl={siteCollectionUrl}&languageId=1033";

                var response = await DeleteAsync(url, null);
            }
            catch (Exception ex)
            {
                throw new BeezyDataServiceException(functionName, functionParams, ex);
            }
        }
    }
}
