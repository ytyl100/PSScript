﻿using DW.Beezy.Admin.Common.Enums;
using DW.Beezy.Admin.Common.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DW.Beezy.Admin.DataServices
{
    public interface IBeezyDataService
    {
        Task<List<LocalEntity>> GetLocalEntities();

        Task<LocalEntity> EditLocalEntity(UpdatedLocalEntity updatedLocalEntity);

        Task<BeezyUser> GetUserByLogin(string loginName);

        Task<BeezyUser> GetUserExtendedById(int userId);

        Task<List<BeezyUser>> GetStoriesUsers(string editorialModuleId);

        Task AddStoriesUserRole(string editorialModuleId, int userId, UserStoriesPagesRole role);

        Task RemoveStoriesUserRole(string editorialModuleId, int userId);

        Task<List<BeezyUser>> GetPagesUsers(string corporateModuleId);

        Task AddPagesUserRole(string corporateModuleId, int userId, UserStoriesPagesRole role);

        Task RemovePagesUserRole(string corporateModuleId, int userId);
    }
}
