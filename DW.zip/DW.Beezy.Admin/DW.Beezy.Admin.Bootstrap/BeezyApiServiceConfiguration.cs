﻿using DW.Beezy.Admin.Common.Models;
using DW.Beezy.Admin.DataServices;
using DW.Beezy.Admin.DataServices.Authentication;
using DW.Beezy.Admin.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Identity.Client;
using System;

namespace DW.Beezy.Admin.Bootstrap
{
    public static class BeezyApiServiceConfiguration
    {
        public static IServiceCollection AddBeezyService(this IServiceCollection services)
        {
            // read configuration values from local settings json & environment variables
            // NOTE - the Build Action and Copy to Output Directory properties of the JSON file must be set to Content and Copy if newer (or Copy always) respectively
            // requires Microsoft.Extensions.Configuration.Json
            var configurationSettings = new ConfigurationBuilder()
                .AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
                .AddEnvironmentVariables()
                .Build();

            // auto mapper
            services.AddAutoMapper(typeof(AutoMapperProfile));

            // see host.json for logging configuration
            services.AddLogging();

            // Admin API settings (to allow test mode with user ID specified & GET requests from browser)
            var adminApiSettings = configurationSettings.Get<AdminApiSettings>();
            services.AddSingleton(adminApiSettings);

            // requires Microsoft.Extensions.Configuration.Binder
            var userTokenClientSettings = configurationSettings.Get<UserTokenClientSettings>();
            var beezyDataServiceSettings = configurationSettings.Get<BeezyDataServiceSettings>();


            services.AddSingleton<IMsalHttpClientFactory, HttpFactoryWithProxy>();

            // user access token retrieval
            // the app registration which we are using for the username / password authentication flow required to call the beezy API
            // also contains app registration secret and username / password for the service account
            // requires Microsoft.Extensions.DependencyInjection

            services.AddSingleton<ITokenClient, UserTokenClient>();
            services.AddSingleton(userTokenClientSettings);

            // beezy data service
            // need these definitions otherwise components will share the same HttpClient (which will not work if they need to request their own access tokens)
            // this call removes the need for a separate AddTransient() call for each of the data access components
            // requires Microsoft.Extensions.DependencyInjection
            // requires Microsoft.Extensions.Http
            services.AddHttpClient<IBeezyDataService, BeezyDataService>();
            services.AddSingleton(beezyDataServiceSettings);

            // beezy service - do not set as Singleton otherwise the access token obtained in UserTokenClient & used by the HttpClient may expire
            // Transient objects are always different; a new instance is provided to every controller and every service
            // Scoped objects are the same within a request, but different across different requests
            // Singleton objects are the same for every object and every request
            services.AddTransient<IBeezyService, BeezyService>();

            return services;
        }
    }
}
