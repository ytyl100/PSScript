﻿using AutoMapper;
using DW.Beezy.Admin.Common.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DW.Beezy.Admin.Bootstrap
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<LocalEntity, UpdatedLocalEntity>()
                .ForMember(dest => dest.AdministratorsIds, opt => opt.MapFrom(src => src.Admins.Select(admin => admin.Id).ToList()));
        }
    }
}
