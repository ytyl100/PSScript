﻿using DW.Beezy.Admin.Common.Exceptions;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace DW.Beezy.Admin.API.Models
{
    // a common wrapper for all function responses 
    public enum FunctionResponseStatus
    {
        Success = 0,
        InvalidRequestError = 100,
        BeezyServiceError = 200,
        UnknownError = 300
    }

    public class AdminApiResponse<T> : AdminApiResponse
    {
        public T ResponseItem { get; set; }
    }

    public class AdminApiResponse
    {
        public AdminApiResponse()
        {
            Status = FunctionResponseStatus.Success;
        }

        public string AuthenticatedUser { get; set; }

        // this will serialize as an integer by default
        public FunctionResponseStatus Status { get; set; }

        public string StatusText
        {
            get { return Status.ToString(); }
        }

        public AdminApiResponseException Exception { get; set; }

        public AdminApiResponseException GetFromBeezyException(BeezyServiceException ex)
        {
            return GetResponseException(ex);
        }

        // iterate through all custom exceptions (based on type BeezyAdminBaseException)
        private AdminApiResponseException GetResponseException(Exception innerException)
        {
            if (innerException != null && innerException.GetType().IsAssignableTo(typeof(BeezyAdminBaseException)))
            {
                BeezyAdminBaseException ex = innerException as BeezyAdminBaseException;
                return new AdminApiResponseException
                {
                    Function = ex.Function,
                    FunctionParams = ex.FunctionParams,
                    Reason = ex.Reason,
                    ErrorMessage = ex.ToString(),
                    Exception = GetResponseException(ex.InnerException)
                };
            }
            else
                return null;
        }
    }

    public class AdminApiResponseException
    {
        public string Reason { get; set; }

        public string Function { get; set; }

        // these will be as escaped JSON - unescape & view at https://onlinejsontools.com/unescape-json
        public string FunctionParams { get; set; }

        public string ErrorMessage { get; set; }

        public AdminApiResponseException Exception { get; set; }
    }
}
