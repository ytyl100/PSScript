using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text.Json;
using System.Threading.Tasks;
using DW.Beezy.Admin.API.Extensions;
using DW.Beezy.Admin.API.Models;
using DW.Beezy.Admin.Common.Exceptions;
using DW.Beezy.Admin.Common.Logging;
using DW.Beezy.Admin.Common.Models;
using DW.Beezy.Admin.Services;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace DW.Beezy.Admin.API
{
    public class ChangeUserLocalEntity
    {
        private AdminApiSettings _settings;
        private IBeezyService _service;

        public ChangeUserLocalEntity(AdminApiSettings settings, IBeezyService service)
        {
            _settings = settings;
            _service = service;
        }
        
        [Function("ChangeUserLocalEntity")]
        public async Task<AdminApiResponse> Run([HttpTrigger(AuthorizationLevel.Anonymous, "post")] HttpRequestData req,
            FunctionContext executionContext)
        {
            // get logger
            var logger = executionContext.GetLogger("ChangeUserLocalEntity");
            logger.LogInformation(LoggingEvents.DW_BEEZY_ADMIN_ChangeUserLocalEntity_Info, "Start: Function.ChangeUserLocalEntity");

            // initialise the object to store the POST request data
            ChangeUserLocalEntityRequest requestData = null;

            // initialise the response object
            AdminApiResponse<ChangeUserLocalEntityResponse> response = new AdminApiResponse<ChangeUserLocalEntityResponse>();

            // allow testing? - default to FALSE
            bool testQueriesPermitted = _settings.TestQueriesPermitted ?? false;

            // allow operations on the default local entity? - default to FALSE
            bool allowOperationsOnDefaultLocalEntity = _settings.AllowOperationsOnDefaultLocalEntity ?? false;

            try
            {
                // get the authenticated user from the request headers
                AuthenticatedUser authUser = req.Headers.GetAuthUserFromHeaders();
                logger.LogInformation(LoggingEvents.DW_BEEZY_ADMIN_ChangeUserLocalEntity_Info, "Authenticated User: {authUser}", authUser.UserPrincipalName);

                // store the actual authenticated user before we allow it to be substituted from the POST data
                response.AuthenticatedUser = authUser.UserPrincipalName;

                // get the request body
                if (req.Body.Length > 0)
                {
                    requestData = await req.ReadFromJsonAsync<ChangeUserLocalEntityRequest>();
                    logger.LogInformation(LoggingEvents.DW_BEEZY_ADMIN_ChangeUserLocalEntity_Info, "POST Data: {data}", JsonConvert.SerializeObject(requestData));

                    if (!testQueriesPermitted && requestData.UserLoginId != null)
                    {
                        response.Status = FunctionResponseStatus.InvalidRequestError;
                        response.Exception = new AdminApiResponseException
                        {
                            Reason = "TestQueriesPermitted=FALSE"
                        };
                        logger.LogInformation(LoggingEvents.DW_BEEZY_ADMIN_GetUser_Info, "End:Function.ChangeUserLocalEntity");
                        return response;
                    }
                }
                else
                    logger.LogInformation(LoggingEvents.DW_BEEZY_ADMIN_ChangeUserLocalEntity_Info, "POST Data: EMPTY");

                // get target local entity from the POST request data
                int targetLocalEntityId = requestData?.TargetLocalEntityId ?? 0;

                if (testQueriesPermitted)
                {
                    // mock the authenticated user with the credentials supplied from the POST request data
                    authUser.UserPrincipalName = requestData?.UserLoginId ?? authUser.UserPrincipalName;

                    // override the AllowOperationsOnDefaultLocalEntity setting (only if test queries are permitted)
                    allowOperationsOnDefaultLocalEntity = requestData?.AllowOperationsOnDefaultLocalEntity ?? allowOperationsOnDefaultLocalEntity;
                }

                response.ResponseItem = await _service.ChangeUserLocalEntity(authUser.UserPrincipalName, targetLocalEntityId, allowOperationsOnDefaultLocalEntity);
                return response;
            }
            catch (BeezyServiceException ex)
            {
                // log error
                logger.LogError(LoggingEvents.DW_BEEZY_ADMIN_ChangeUserLocalEntity_Error, ex, "Error in function ChangeUserLocalEntity");

                response.Status = FunctionResponseStatus.BeezyServiceError;
                response.Exception = response.GetFromBeezyException(ex);
            }
            catch (Exception ex)
            {
                // log error
                logger.LogError(LoggingEvents.DW_BEEZY_ADMIN_ChangeUserLocalEntity_Error, ex, "Error in function ChangeUserLocalEntity");

                response.Status = FunctionResponseStatus.UnknownError;
                response.Exception = new AdminApiResponseException
                {
                    Reason = ex.Message,
                    ErrorMessage = ex.ToString()
                };
            }

            logger.LogInformation(LoggingEvents.DW_BEEZY_ADMIN_ChangeUserLocalEntity_Info, "End:Function.ChangeUserLocalEntity");
            return response;
        }
    }
}
