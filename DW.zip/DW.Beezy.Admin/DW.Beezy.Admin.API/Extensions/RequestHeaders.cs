﻿using DW.Beezy.Admin.Common.Models;
using Microsoft.Azure.Functions.Worker.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DW.Beezy.Admin.API.Extensions
{
    public static class RequestHeaders
    {
        public static AuthenticatedUser GetAuthUserFromHeaders(this HttpHeadersCollection headers)
        {
            return new AuthenticatedUser
            {
                UserPrincipalName = TryGetValue(headers, "x-ms-client-principal-name"),
                AccessToken = TryGetValue(headers, "x-ms-token-aad-access-token")
            };
        }

        private static string TryGetValue(HttpHeadersCollection headers, string name)
        {
            IEnumerable<string>? values;
            headers.TryGetValues(name, out values);
            return values?.FirstOrDefault();
        }
    }
}
