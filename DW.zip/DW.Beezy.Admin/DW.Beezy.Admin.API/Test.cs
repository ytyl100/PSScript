using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using DW.Beezy.Admin.API.Extensions;
using DW.Beezy.Admin.API.Models;
using DW.Beezy.Admin.Common.Models;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace DW.Beezy.Admin.API
{
    public class Test
    {
        [Function("Test")]
        public async Task<AdminApiResponse> Run([HttpTrigger(AuthorizationLevel.Anonymous, "get", "post")] HttpRequestData req,
            FunctionContext executionContext)
        {
            // get logger
            var logger = executionContext.GetLogger("Test");
            logger.LogInformation("Test: Start");

            // initialise the object to store the POST request data
            ChangeUserLocalEntityRequest requestData = null;

            // initialise the response object
            AdminApiResponse<ChangeUserLocalEntityRequest> response = new AdminApiResponse<ChangeUserLocalEntityRequest>();

            try
            {
                // get the request body
                if (req.Body.Length > 0)
                {
                    requestData = await req.ReadFromJsonAsync<ChangeUserLocalEntityRequest>();
                    logger.LogInformation("POST Data: {data}", JsonConvert.SerializeObject(requestData));
                }
                else
                    logger.LogInformation("POST Data: EMPTY");

                // get the authenticated user from the request headers
                AuthenticatedUser authUser = req.Headers.GetAuthUserFromHeaders();
                logger.LogInformation("Authenticated User: {authUser}", authUser.UserPrincipalName);

                // use the exception item to pass back some additional data for testing
                response.AuthenticatedUser = authUser.UserPrincipalName;
                response.ResponseItem = requestData;
                response.Exception = new AdminApiResponseException
                {
                    Reason = requestData != null ? JsonConvert.SerializeObject(requestData) : "POST Data: EMPTY"
                };
            }
            catch (Exception ex)
            {
                response.Status = FunctionResponseStatus.UnknownError;
                response.Exception = new AdminApiResponseException
                {
                    ErrorMessage = ex.ToString()
                };
            }

            logger.LogInformation("Test: End");
            return response;
        }
    }
}
