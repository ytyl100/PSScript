using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using DW.Beezy.Admin.API.Extensions;
using DW.Beezy.Admin.API.Models;
using DW.Beezy.Admin.Common.Exceptions;
using DW.Beezy.Admin.Common.Logging;
using DW.Beezy.Admin.Common.Models;
using DW.Beezy.Admin.Services;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;

namespace DW.Beezy.Admin.API
{
    public class GetUser
    {
        private AdminApiSettings _settings;
        private IBeezyService _service;

        public GetUser(AdminApiSettings settings, IBeezyService service)
        {
            _settings = settings;
            _service = service;
        }

        [Function("GetUser")]
        public async Task<AdminApiResponse<BeezyUser>> Run([HttpTrigger(AuthorizationLevel.Anonymous, "get", "post")] HttpRequestData req,
            FunctionContext executionContext)
        {
            // get logger
            var logger = executionContext.GetLogger("GetUser");
            logger.LogInformation(LoggingEvents.DW_BEEZY_ADMIN_GetUser_Info, "Start: Function.GetUser");

            // initialise the response object
            AdminApiResponse<BeezyUser> response = new AdminApiResponse<BeezyUser>();

            // allow testing? - default to FALSE
            bool testQueriesPermitted = _settings.TestQueriesPermitted ?? false;

            try
            {
                // get the authenticated user from the request headers
                var authUser = req.Headers.GetAuthUserFromHeaders();
                logger.LogInformation(LoggingEvents.DW_BEEZY_ADMIN_GetUser_Info, "Authenticated User {authUser}", authUser.UserPrincipalName);

                // store the actual authenticated user before we allow it to be substituted from the query string
                response.AuthenticatedUser = authUser.UserPrincipalName;

                // get the request query string
                var query = System.Web.HttpUtility.ParseQueryString(req.Url.Query);
                if (!testQueriesPermitted && query["userLoginId"] != null)
                {
                    response.Status = FunctionResponseStatus.InvalidRequestError;
                    response.Exception = new AdminApiResponseException
                    {
                        Reason = "TestQueriesPermitted=FALSE"
                    };
                    logger.LogInformation(LoggingEvents.DW_BEEZY_ADMIN_GetUser_Info, "End:Function.GetUser");
                    return response;
                }

                if (testQueriesPermitted)
                {
                    // for local debug testing allow the user to be specified in the query string
                    // e.g. http://localhost:7071/api/GetUser?userLoginId=jim.griffiths@dwdev365.onmicrosoft.com
                    authUser.UserPrincipalName = query["userLoginId"] ?? authUser.UserPrincipalName;
                }

                response.ResponseItem = await _service.GetUser(authUser.UserPrincipalName);
            }
            catch (BeezyServiceException ex)
            {
                // log error
                logger.LogError(LoggingEvents.DW_BEEZY_ADMIN_GetUser_Error, ex, "Error in function GetUser");

                response.Status = FunctionResponseStatus.BeezyServiceError;
                response.Exception = response.GetFromBeezyException(ex);
            }
            catch (Exception ex)
            {
                // log error
                logger.LogError(LoggingEvents.DW_BEEZY_ADMIN_GetUser_Error, ex, "Error in function GetUser");

                response.Status = FunctionResponseStatus.UnknownError;
                response.Exception = new AdminApiResponseException
                {
                    Reason = ex.Message,
                    ErrorMessage = ex.ToString()
                };
            }

            logger.LogInformation(LoggingEvents.DW_BEEZY_ADMIN_GetUser_Info, "End:Function.GetUser");
            return response;
        }
    }
}
