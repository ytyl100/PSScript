using System;
using System.IO;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Net;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using DW.Beezy.Admin.Services;
using DW.Beezy.Admin.Common.Models;
using DW.Beezy.Admin.API.Models;
using DW.Beezy.Admin.Common.Logging;
using DW.Beezy.Admin.Common.Exceptions;
using DW.Beezy.Admin.API.Extensions;

namespace DW.Beezy.Admin.API.v3
{
    public class GetLocalEntities
    {
        private AdminApiSettings _settings;
        private IBeezyService _service;

        public GetLocalEntities(AdminApiSettings settings, IBeezyService service)
        {
            _settings = settings;
            _service = service;
        }

        [Function("GetLocalEntities")]
        public async Task<AdminApiResponse<List<LocalEntity>>> Run([HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] HttpRequestData req,
            FunctionContext executionContext)
        {
            // get logger
            var logger = executionContext.GetLogger("GetLocalEntities");
            logger.LogInformation(LoggingEvents.DW_BEEZY_ADMIN_GetLocalEntities_Info, "Start: Function.GetLocalEntities");

            // initialise the response object
            AdminApiResponse<List<LocalEntity>> response = new AdminApiResponse<List<LocalEntity>>();

            try
            {
                // get the authenticated user from the request headers
                var authUser = req.Headers.GetAuthUserFromHeaders();
                logger.LogInformation(LoggingEvents.DW_BEEZY_ADMIN_GetLocalEntities_Info, "Authenticated User {authUser}", authUser.UserPrincipalName);
                response.AuthenticatedUser = authUser.UserPrincipalName;

                response.ResponseItem = await _service.GetLocalEntities(_settings.AllowOperationsOnDefaultLocalEntity ?? false, _settings.TestQueriesPermitted ?? false);
            }
            catch (BeezyServiceException ex)
            {
                // log error
                logger.LogError(LoggingEvents.DW_BEEZY_ADMIN_GetLocalEntities_Error, ex, "Error in function GetLocalEntities");

                response.Status = FunctionResponseStatus.BeezyServiceError;
                response.Exception = response.GetFromBeezyException(ex);
            }
            catch (Exception ex)
            {
                // log error
                logger.LogError(LoggingEvents.DW_BEEZY_ADMIN_GetLocalEntities_Error, ex, "Error in function GetLocalEntities");

                response.Status = FunctionResponseStatus.UnknownError;
                response.Exception = new AdminApiResponseException
                {
                    Reason = ex.Message,
                    ErrorMessage = ex.ToString()
                };
            }

            logger.LogInformation(LoggingEvents.DW_BEEZY_ADMIN_GetLocalEntities_Info, "End:Function.GetLocalEntities");
            return response;
        }
    }
}
