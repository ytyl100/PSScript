﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DW.Beezy.Admin.Services.Tests
{
    public class BeezyServiceTestData_Current_User_Of_Non_Default_Local_Entity : IEnumerable<object[]>
    {
        // string loginName, int targetLocalEntityId
        private static IEnumerable<object[]> Data()
        {
            yield return new object[] { "testuser.03@hsbc.com", 1 };
            yield return new object[] { "testuser.03@hsbc.com", 2 };
            yield return new object[] { "testuser.03@hsbc.com", 4 };
        }

        public IEnumerator<object[]> GetEnumerator() => Data().GetEnumerator();

        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
    }

    public class BeezyServiceTestData_New_User : IEnumerable<object[]>
    {
        // string loginName, int targetLocalEntityId
        private static IEnumerable<object[]> Data()
        {
            yield return new object[] { "newuser.01@hsbc.com", 1 };
            yield return new object[] { "newuser.01@hsbc.com", 2 };
            yield return new object[] { "newuser.01@hsbc.com", 3 };
            yield return new object[] { "newuser.01@hsbc.com", 4 };
        }

        public IEnumerator<object[]> GetEnumerator() => Data().GetEnumerator();

        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
    }
}