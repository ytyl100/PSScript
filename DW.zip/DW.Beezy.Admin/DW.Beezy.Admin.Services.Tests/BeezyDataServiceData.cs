﻿using DW.Beezy.Admin.Common.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DW.Beezy.Admin.Services.Tests
{
    public static class BeezyDataServiceData
    {
        public static List<BeezyUser> GetUsers(List<LocalEntity> localEntities)
        {
            return new List<BeezyUser>
            {
                GetBeezyUser(1, "globaladmin.01@hsbc.com", localEntities),
                GetBeezyUser(2, "localadmin.02@hsbc.com", localEntities),
                GetBeezyUser(3, "localadmin.03@hsbc.com", localEntities),
                GetBeezyUser(4, "localadmin.04@hsbc.com", localEntities),
                GetBeezyUser(101, "testuser.01@hsbc.com", localEntities),
                GetBeezyUser(102, "testuser.02@hsbc.com", localEntities),
                GetBeezyUser(103, "testuser.03@hsbc.com", localEntities),
                GetBeezyUser(200, "newuser.01@hsbc.com", localEntities)
            };
        }

        private static BeezyUser GetBeezyUser(int userId, string loginName, List<LocalEntity> localEntities)
        {
            var defaultLocalEntity = localEntities.Single(le => le.IsDefault);
            var localEntity = localEntities.SingleOrDefault(le => le.Admins.Select(a => a.Id).Contains(userId)) ?? defaultLocalEntity;

            return new BeezyUser
            {
                Id = userId,
                LoginName = loginName,
                LocalEntity = new BeezyUserLocalEntity
                {
                    Id = localEntity.Id,
                    IsDefaultLocalEntity = localEntity.IsDefault,
                    Title = localEntity.Title
                }
            };
        }

        public static List<LocalEntity> GetLocalEntities()
        {
            return new List<LocalEntity>
            {
                // global entity
                new LocalEntity
                {
                    Id = 1,
                    IsDefault = true,
                    Title = "Default",
                    EditorialModuleId = "101",
                    CorporateModuleId = "201",
                    Admins = new List<LocalEntityAdmin>
                    {
                        new LocalEntityAdmin { Id = 1 }
                    }
                },
                new LocalEntity
                {
                    Id = 2,
                    IsDefault = false,
                    Title = "Berlin",
                    EditorialModuleId = "102",
                    CorporateModuleId = "202",
                    Admins = new List<LocalEntityAdmin>
                    {
                        new LocalEntityAdmin { Id = 2 },
                        new LocalEntityAdmin { Id = 102 }
                    }
                },
                new LocalEntity
                {
                    Id = 3,
                    IsDefault = false,
                    Title = "Canada",
                    EditorialModuleId = "103",
                    CorporateModuleId = "203",
                    Admins = new List<LocalEntityAdmin>
                    {
                        new LocalEntityAdmin { Id = 3 },
                        new LocalEntityAdmin { Id = 103 }
                    }
                },
                // local entity with only a single admin
                new LocalEntity
                {
                    Id = 4,
                    IsDefault = false,
                    Title = "Australia",
                    EditorialModuleId = "104",
                    CorporateModuleId = "204",
                    Admins = new List<LocalEntityAdmin>
                    {
                        new LocalEntityAdmin { Id = 4 }
                    }
                }
            };
        }
    }
}
