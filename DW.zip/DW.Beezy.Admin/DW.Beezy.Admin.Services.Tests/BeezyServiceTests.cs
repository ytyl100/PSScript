using AutoMapper;
using DW.Beezy.Admin.Bootstrap;
using DW.Beezy.Admin.Common.Enums;
using DW.Beezy.Admin.Common.Exceptions;
using DW.Beezy.Admin.Common.Models;
using DW.Beezy.Admin.DataServices;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace DW.Beezy.Admin.Services.Tests
{
    public class BeezyServiceTests
    {
        private readonly IBeezyService _beezyService;

        private readonly Mock<IBeezyDataService> _beezyDataServiceMock;
        private readonly Mock<ILogger<BeezyService>> _loggerMock;
        private readonly IMapper _autoMapper;

        private readonly List<BeezyUser> users;
        private readonly List<LocalEntity> localEntities;

        public BeezyServiceTests()
        {
            var mappingConfig = new MapperConfiguration(mc =>
            {
                mc.AddProfile(new AutoMapperProfile());
            });
            _autoMapper = mappingConfig.CreateMapper();

            // TODO: Use the DI framework to create the service
            _beezyDataServiceMock = new Mock<IBeezyDataService>();
            _loggerMock = new Mock<ILogger<BeezyService>>();
            _beezyService = new BeezyService(_beezyDataServiceMock.Object, _loggerMock.Object, _autoMapper);

            // populate mock data service data
            localEntities = BeezyDataServiceData.GetLocalEntities();
            users = BeezyDataServiceData.GetUsers(localEntities);

            // arrange mock data service functions - see https://docs.educationsmediagroup.com/unit-testing-csharp/moq/method-calls
            _beezyDataServiceMock.Setup(mock => mock.GetLocalEntities()).ReturnsAsync(localEntities);
            _beezyDataServiceMock.Setup(mock => mock.GetUserByLogin(It.IsAny<string>())).ReturnsAsync((string loginName) => users.Single(user => user.LoginName == loginName));
            _beezyDataServiceMock.Setup(mock => mock.GetUserExtendedById(It.IsAny<int>())).ReturnsAsync((int id) => users.Single(user => user.Id == id));
            _beezyDataServiceMock.Setup(mock => mock.EditLocalEntity(It.IsAny<UpdatedLocalEntity>())).ReturnsAsync((UpdatedLocalEntity le) => new LocalEntity { Id = le.Id, Title = le.Title });

            // arrange stories - assume all admin users for a local entity are also stories users
            _beezyDataServiceMock.Setup(mock => mock.GetStoriesUsers(It.IsAny<string>()))
                .ReturnsAsync((string editorialModuleId) => users.Where(user => localEntities
                    .Single(le => le.EditorialModuleId == editorialModuleId)
                    .Admins.Select(admin => admin.Id).Contains(user.Id)).ToList());
            _beezyDataServiceMock.Setup(mock => mock.AddStoriesUserRole(It.IsAny<string>(), It.IsAny<int>(), It.IsAny<UserStoriesPagesRole>()));
            _beezyDataServiceMock.Setup(mock => mock.RemoveStoriesUserRole(It.IsAny<string>(), It.IsAny<int>()));

            // arrange pages - assume all admin users for a local entity are also pages users
            _beezyDataServiceMock.Setup(mock => mock.GetPagesUsers(It.IsAny<string>()))
                .ReturnsAsync((string corporateModuleId) => users.Where(user => localEntities
                    .Single(le => le.CorporateModuleId == corporateModuleId)
                    .Admins.Select(admin => admin.Id).Contains(user.Id)).ToList());
            _beezyDataServiceMock.Setup(mock => mock.AddPagesUserRole(It.IsAny<string>(), It.IsAny<int>(), It.IsAny<UserStoriesPagesRole>()));
            _beezyDataServiceMock.Setup(mock => mock.RemovePagesUserRole(It.IsAny<string>(), It.IsAny<int>()));
        }

        [Theory]
        [ClassData(typeof(BeezyServiceTestData_Current_User_Of_Non_Default_Local_Entity))]
        public async Task ChangeUserLocalEntity_Current_User_Of_Non_Default_Local_Entity(string loginName, int targetLocalEntityId)
        {
            var user = users.Single(user => user.LoginName == loginName);
            var currentLocalEntity = localEntities.Single(le => le.Id == user.LocalEntity.Id);
            var targetLocalEntity = localEntities.Single(le => le.Id == targetLocalEntityId);

            // act - allowing operations on default local entity
            Func<Task<ChangeUserLocalEntityResponse>> act = () => _beezyService.ChangeUserLocalEntity(loginName, targetLocalEntityId, true);
            var response = await act();

            // assert - add user to target local entity
            _beezyDataServiceMock.Verify(mock => mock.EditLocalEntity(It.Is<UpdatedLocalEntity>(le =>
                le.Id == targetLocalEntityId &&
                le.AdministratorsIds.Contains(user.Id) &&
                targetLocalEntity.Admins.All(admin => le.AdministratorsIds.Contains(admin.Id))
            )), Times.Once);

            // assert - remove user from current local entity
            _beezyDataServiceMock.Verify(mock => mock.EditLocalEntity(It.Is<UpdatedLocalEntity>(le =>
                le.Id == currentLocalEntity.Id &&
                !le.AdministratorsIds.Contains(user.Id) &&
                currentLocalEntity.Admins.Where(admin => admin.Id != user.Id).All(admin => le.AdministratorsIds.Contains(admin.Id))
            )), Times.Once);

            // assert - remove stories & pages roles
            _beezyDataServiceMock.Verify(mock => mock.RemoveStoriesUserRole(currentLocalEntity.EditorialModuleId, user.Id), Times.Once, "Failed to call RemoveStoriesUserRole() on current local entity");
            _beezyDataServiceMock.Verify(mock => mock.RemovePagesUserRole(currentLocalEntity.CorporateModuleId, user.Id), Times.Once, "Failed to call RemovePagesUserRole() on current local entity");

            // assert - add stories & pages roles
            _beezyDataServiceMock.Verify(mock => mock.AddStoriesUserRole(targetLocalEntity.EditorialModuleId, user.Id, UserStoriesPagesRole.Editor), Times.Once, "Failed to call AddStoriesUserRole() on target local entity");
            _beezyDataServiceMock.Verify(mock => mock.AddPagesUserRole(targetLocalEntity.CorporateModuleId, user.Id, UserStoriesPagesRole.Editor), Times.Once, "Failed to call AddPagesUserRole() on target local entity");
        }

        [Theory]
        [ClassData(typeof(BeezyServiceTestData_New_User))]
        public async Task ChangeUserLocalEntity_New_User(string loginName, int targetLocalEntityId)
        {
            var user = users.Single(user => user.LoginName == loginName);
            var currentLocalEntity = localEntities.Single(le => le.Id == user.LocalEntity.Id);
            var targetLocalEntity = localEntities.Single(le => le.Id == targetLocalEntityId);

            // act - allowing operations on default local entity
            Func<Task<ChangeUserLocalEntityResponse>> act = () => _beezyService.ChangeUserLocalEntity(loginName, targetLocalEntityId, true);
            var response = await act();

            // assert - add user to target local entity
            _beezyDataServiceMock.Verify(mock => mock.EditLocalEntity(It.Is<UpdatedLocalEntity>(le =>
                le.Id == targetLocalEntityId &&
                le.AdministratorsIds.Contains(user.Id) &&
                targetLocalEntity.Admins.All(admin => le.AdministratorsIds.Contains(admin.Id)) &&
                le.AdministratorsIds.Count == targetLocalEntity.Admins.Count + 1
            )), Times.Once);

            // assert - DO NOT remove stories & pages roles
            _beezyDataServiceMock.Verify(mock => mock.RemoveStoriesUserRole(It.IsAny<string>(), It.IsAny<int>()), Times.Never, "Should not call RemoveStoriesUserRole() on current local entity");
            _beezyDataServiceMock.Verify(mock => mock.RemovePagesUserRole(It.IsAny<string>(), It.IsAny<int>()), Times.Never, "Should not call RemovePagesUserRole() on current local entity");

            // assert - add stories & pages roles
            _beezyDataServiceMock.Verify(mock => mock.AddStoriesUserRole(targetLocalEntity.EditorialModuleId, user.Id, UserStoriesPagesRole.Editor), Times.Once, "Failed to call AddStoriesUserRole() on target local entity");
            _beezyDataServiceMock.Verify(mock => mock.AddPagesUserRole(targetLocalEntity.CorporateModuleId, user.Id, UserStoriesPagesRole.Editor), Times.Once, "Failed to call AddPagesUserRole() on target local entity");
        }

        [Fact]
        public async Task Prevent_Local_Entity_Switch_For_Global_Admin()
        {
            // arrange
            string adminUserLoginName = "globaladmin.01@hsbc.com";
            int targetLocalEntityId = 2;

            // act
            Func<Task<ChangeUserLocalEntityResponse>> act = () => _beezyService.ChangeUserLocalEntity(adminUserLoginName, targetLocalEntityId, true);

            // assert
            BeezyServiceException exception = await Assert.ThrowsAsync<BeezyServiceException>(act);

            // the thrown exception can be used for even more detailed assertions
            Assert.StartsWith("It is not permitted to perform operations on global admins", exception.Reason);
        }

        [Fact]
        public async Task Confirm_Target_Local_Entity_Exists()
        {
            // arrange
            string adminUserLoginName = "testuser.01@hsbc.com";
            int targetLocalEntityId = 1000;

            // act
            Func<Task<ChangeUserLocalEntityResponse>> act = () => _beezyService.ChangeUserLocalEntity(adminUserLoginName, targetLocalEntityId, true);

            // assert
            BeezyServiceException exception = await Assert.ThrowsAsync<BeezyServiceException>(act);

            // the thrown exception can be used for even more detailed assertions
            Assert.StartsWith("The requested local entity ID", exception.Reason);
        }

        [Fact]
        public async Task Prevent_Removing_The_Last_Admin_From_Local_Entity()
        {
            // arrange
            string adminUserLoginName = "localadmin.04@hsbc.com";
            int targetLocalEntityId = 2;

            // act
            Func<Task<ChangeUserLocalEntityResponse>> act = () => _beezyService.ChangeUserLocalEntity(adminUserLoginName, targetLocalEntityId, false);

            // assert
            BeezyServiceException exception = await Assert.ThrowsAsync<BeezyServiceException>(act);

            // the thrown exception can be used for even more detailed assertions
            Assert.Contains("since it is the only administrator for this local entity", exception.Reason);
        }

        [Theory]
        [InlineData(2, false)]
        [InlineData(3, true)]
        public async Task Prevent_Target_Local_Entity_Same_As_Current_Unless_Target_Is_Default_Local_Entity(int targetLocalEntityId, bool isPrevented)
        {
            // arrange
            string adminUserLoginName = "testuser.03@hsbc.com";

            // act
            Func<Task<ChangeUserLocalEntityResponse>> act = () => _beezyService.ChangeUserLocalEntity(adminUserLoginName, targetLocalEntityId, false);

            // assert
            if (isPrevented)
            {
                BeezyServiceException exception = await Assert.ThrowsAsync<BeezyServiceException>(act);

                // the thrown exception can be used for even more detailed assertions
                Assert.StartsWith("User entity is already set as the requested local entity", exception.Reason);
            }
            else
            {
                var response = await act();
            }
        }

        [Theory]
        [InlineData(1, true, false)]
        [InlineData(1, false, true)]
        [InlineData(2, true, false)]
        [InlineData(2, false, false)]
        [InlineData(3, true, false)]
        [InlineData(3, false, false)]
        [InlineData(4, true, false)]
        [InlineData(4, false, false)]
        public async Task Prevent_Target_Local_Entity_IsDefault_Unless_Overridden(int targetLocalEntityId, bool allowOperationsOnDefaultLocalEntity, bool isPrevented)
        {
            // arrange
            string adminUserLoginName = "testuser.01@hsbc.com";

            // act
            Func<Task<ChangeUserLocalEntityResponse>> act = () => _beezyService.ChangeUserLocalEntity(adminUserLoginName, targetLocalEntityId, allowOperationsOnDefaultLocalEntity);

            // assert
            if (isPrevented)
            {
                BeezyServiceException exception = await Assert.ThrowsAsync<BeezyServiceException>(act);

                // the thrown exception can be used for even more detailed assertions
                Assert.StartsWith("Operation not permitted. The requested local entity ID", exception.Reason);
            }
            else
            {
                var response = await act();
            }
        }
    }
}
