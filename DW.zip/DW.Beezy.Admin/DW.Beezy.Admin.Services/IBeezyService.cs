﻿using DW.Beezy.Admin.Common.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DW.Beezy.Admin.Services
{
    public interface IBeezyService
    {
        Task<List<LocalEntity>> GetLocalEntities(bool allowOperationsOnDefaultLocalEntity, bool canOverride);

        Task<BeezyUser> GetUser(string loginName);

        Task<ChangeUserLocalEntityResponse> ChangeUserLocalEntity(string loginName, int targetLocalEntityId, bool allowOperationsOnDefaultLocalEntity);
    }
}
