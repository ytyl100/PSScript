﻿using AutoMapper;
using DW.Beezy.Admin.Common.Enums;
using DW.Beezy.Admin.Common.Exceptions;
using DW.Beezy.Admin.Common.Logging;
using DW.Beezy.Admin.Common.Models;
using DW.Beezy.Admin.DataServices;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DW.Beezy.Admin.Services
{
    public class BeezyService : IBeezyService
    {
        private readonly IBeezyDataService _beezyDataService;
        private readonly ILogger<BeezyService> _logger;
        private readonly IMapper _mapper;

        public BeezyService(IBeezyDataService beezyDataService, ILogger<BeezyService> logger, IMapper mapper)
        {
            this._beezyDataService = beezyDataService;
            this._logger = logger;
            this._mapper = mapper;
        }

        public string FunctionToTest(int num)
        {
            return string.Empty;
        }

        public async Task<List<LocalEntity>> GetLocalEntities(bool allowOperationsOnDefaultLocalEntity, bool canOverride)
        {
            string functionName = "GetLocalEntities";

            try
            {
                _logger.LogInformation(LoggingEvents.DW_BEEZY_ADMIN_Service_Info, $"BeezyService.{functionName}()");

                List<LocalEntity> localEntities = await _beezyDataService.GetLocalEntities();

                localEntities.ForEach(le =>
                {
                    // CanJoin is always true for local entities apart from the default local entity
                    le.CanJoin = le.IsDefault ? allowOperationsOnDefaultLocalEntity : true;
                    le.CanOverride = canOverride;
                });

                return localEntities;
            }
            catch (BeezyServiceException ex)
            {
                // rethrow so we preserve the custom error information
                throw;
            }
            catch (Exception ex)
            {
                throw new BeezyServiceException(functionName, ex);
            }
        }

        public async Task<BeezyUser> GetUser(string loginName)
        {
            string functionName = "GetUser";
            string functionParams = JsonConvert.SerializeObject(new { loginName });

            try
            {
                _logger.LogInformation(LoggingEvents.DW_BEEZY_ADMIN_Service_Info, $"BeezyService.{functionName}(): {functionParams}");

                // validate the login name
                if (string.IsNullOrEmpty(loginName))
                    throw new BeezyServiceException(functionName, functionParams, $"User is not specified or authenticated!");

                // get the user ID
                var user = await _beezyDataService.GetUserByLogin(loginName);

                // validate the user has been found
                if (user == null)
                    throw new BeezyServiceException(functionName, functionParams, $"User {loginName} does not exist!");

                // get extended user info
                return await _beezyDataService.GetUserExtendedById(user.Id);
            }
            catch (BeezyServiceException ex)
            {
                // rethrow so we preserve the custom error information
                throw;
            }
            catch (Exception ex)
            {
                throw new BeezyServiceException(functionName, functionParams, ex);
            }
        }

        public async Task<ChangeUserLocalEntityResponse> ChangeUserLocalEntity(string loginName, int targetLocalEntityId, bool allowOperationsOnDefaultLocalEntity)
        {
            string functionName = "ChangeUserLocalEntity";
            string functionParams = JsonConvert.SerializeObject(new { loginName, targetLocalEntityId, allowOperationsOnDefaultLocalEntity });

            try
            {
                _logger.LogInformation(LoggingEvents.DW_BEEZY_ADMIN_Service_Info, $"BeezyService.{functionName}(): {functionParams}");

                // get the user
                var currentUser = await GetUser(loginName);

                // get local entities
                var localEntities = await _beezyDataService.GetLocalEntities();

                // get the current local entity
                var currentUserLocalEntityId = currentUser.LocalEntity?.Id;
                var currentLocalEntity = localEntities.SingleOrDefault(le => le.Id == currentUserLocalEntityId);

                // get the target local entity
                var targetLocalEntity = localEntities.SingleOrDefault(le => le.Id == targetLocalEntityId);

                // validate that the user is not a global admin
                if (localEntities.Any(le => le.IsDefault && le.Admins.Any(admin => admin.Id == currentUser.Id)))
                    throw new BeezyServiceException(functionName, functionParams, $"It is not permitted to perform operations on global admins. User '{currentUser.LoginName}' is a global admin!!");

                // validate the target local entity
                if (targetLocalEntity == null)
                    throw new BeezyServiceException(functionName, functionParams, $"The requested local entity ID={targetLocalEntityId} does not exist!");

                // validate the target local entity is NOT the default local entity (global)
                if (targetLocalEntity.IsDefault && !allowOperationsOnDefaultLocalEntity)
                    throw new BeezyServiceException(functionName, functionParams, $"Operation not permitted. The requested local entity ID={targetLocalEntityId} is the default local entity!");

                // validate that this user isn't the only local entity admin (the beezy API will throw an error if we try to remove all admins from a local entity)
                if (currentLocalEntity.Admins.Count == 1 && currentLocalEntity.Admins.First().Id == currentUser.Id)
                    throw new BeezyServiceException(functionName, functionParams, $"The user '{currentUser.LoginName}' cannot be removed from local entity '{currentLocalEntity.Title}' since it is the only administrator for this local entity!");

                // validate that current local entity is not the same as the target local entity
                if (currentUserLocalEntityId == targetLocalEntityId)
                {
                    if (targetLocalEntity.IsDefault)
                    {
                        // allow to request to set to default local entity even if the user local entity is already shown as the default local entity
                        // this allows us to add the stories & pages rights for the default local entity for non global admin users
                        currentLocalEntity = null;
                    }
                    else
                    {
                        throw new BeezyServiceException(functionName, functionParams, $"User entity is already set as the requested local entity '{targetLocalEntity.Title}'!");
                    }
                }

                _logger.LogWarning(LoggingEvents.DW_BEEZY_ADMIN_Service_Warning, $"BeezyService.{functionName}(): Updating local entity to '{JsonConvert.SerializeObject(targetLocalEntity)}' for user {JsonConvert.SerializeObject(currentUser)}!");

                // remove user from the current local entity (unless it is the default local entity)
                (LocalEntity Result, bool Success) localEntityUserRemoved = (null, false);
                if (currentLocalEntity != null && (!currentLocalEntity.IsDefault || allowOperationsOnDefaultLocalEntity))
                {
                    // remove the user as Stories & Pages writer or editor - must be done before the user is removed as an admin
                    await RemoveUserStoriesAndPagesRole(currentUser, currentLocalEntity);

                    // remove user from the current local entity (unless it is the default local entity)
                    if (!currentLocalEntity.IsDefault)
                    {
                        localEntityUserRemoved = await RemoveUserFromLocalEntity(currentUser, currentLocalEntity);
                        if (localEntityUserRemoved.Success)
                        {
                            _logger.LogInformation(LoggingEvents.DW_BEEZY_ADMIN_Service_Info, $"BeezyService.{functionName}(): User {currentUser.LoginName} has been removed as administrator for the local entity '{currentLocalEntity.Title}'");
                        }
                        else
                        {
                            string userDetails = JsonConvert.SerializeObject(currentUser);
                            _logger.LogWarning(LoggingEvents.DW_BEEZY_ADMIN_Service_Warning, $"BeezyService.{functionName}(): User {currentUser.LoginName} is not an administrator for the local entity '{currentLocalEntity.Title}' that is specified for them! User details are {userDetails}");

                            // NOTE - remediation seems to be to add the user as admin to this local entity and then remove them
                            // otherwise we get a 400: Bad Request error for the GraphQL call to add them to the new entity
                        }
                    }
                }

                // add user to the target local entity (get operation status using a tuple)
                (LocalEntity Result, bool Success) localEntityUserAdded = await AddUserToLocalEntity(currentUser, targetLocalEntity);
                if (!localEntityUserAdded.Success)
                {
                    _logger.LogInformation(LoggingEvents.DW_BEEZY_ADMIN_Service_Info, $"BeezyService.{functionName}(): User {currentUser.LoginName} has been added as administrator for the local entity '{targetLocalEntity.Title}'");
                }
                else
                {
                    string userDetails = JsonConvert.SerializeObject(currentUser);
                    _logger.LogWarning(LoggingEvents.DW_BEEZY_ADMIN_Service_Warning, $"BeezyService.{functionName}(): User {currentUser.LoginName} is already an administrator for the requested local entity '{targetLocalEntity.Title}'! User details are {userDetails}");
                }

                // add the user as Stories & Pages writer or editor - must be done after the user is added as an admin
                await AddUserAsStoriesAndPagesEditor(currentUser, targetLocalEntity);

                return new ChangeUserLocalEntityResponse
                {
                    UserId = currentUser.Id,
                    UserFullName = currentUser.FullName,
                    UserLoginName = currentUser.LoginName,
                    SourceLocalEntityId = currentLocalEntity?.Id,
                    SourceLocalEntityTitle = currentLocalEntity?.Title,
                    TargetLocalEntityId = targetLocalEntity.Id,
                    TargetLocalEntityTitle = targetLocalEntity.Title
                };
            }
            catch (BeezyServiceException ex)
            {
                // rethrow so we preserve the custom error information
                throw;
            }
            catch (Exception ex)
            {
                throw new BeezyServiceException(functionName, functionParams, ex);
            }
        }

        private async Task<(LocalEntity, bool)> RemoveUserFromLocalEntity(BeezyUser currentUser, LocalEntity currentLocalEntity)
        {
            // validate that the current user is an admin of the current legal entity
            if (currentLocalEntity.Admins.Any(admin => admin.Id == currentUser.Id))
            {
                // remove user from the current local entity
                // create the request item - only the AdministratorsIds will be updated
                UpdatedLocalEntity updatedLocalEntityForRemovedUser = _mapper.Map<LocalEntity, UpdatedLocalEntity>(currentLocalEntity);
                updatedLocalEntityForRemovedUser.AdministratorsIds.Remove(currentUser.Id);

                // update current local entity
                var localEntityUserRemoved = await _beezyDataService.EditLocalEntity(updatedLocalEntityForRemovedUser);
                return (localEntityUserRemoved, true);
            }
            else
                return (null, false);
        }

        private async Task RemoveUserStoriesAndPagesRole(BeezyUser currentUser, LocalEntity currentLocalEntity)
        {
            // get the stories users (so that we can confirm whether the user needs to be removed)
            var storiesUsers = await _beezyDataService.GetStoriesUsers(currentLocalEntity.EditorialModuleId);
            if (storiesUsers.Any(user => user.Id == currentUser.Id))
            {
                // remove the user as Stories writer or editor - must be done while the user is still an admin
                await _beezyDataService.RemoveStoriesUserRole(currentLocalEntity.EditorialModuleId, currentUser.Id);
            }

            // get the pages users (so that we can confirm whether the user needs to be removed)
            var pagesUsers = await _beezyDataService.GetPagesUsers(currentLocalEntity.CorporateModuleId);
            if (pagesUsers.Any(user => user.Id == currentUser.Id))
            {
                // remove the user as Pages writer or editor - must be done while the user is still an admin
                await _beezyDataService.RemovePagesUserRole(currentLocalEntity.CorporateModuleId, currentUser.Id);
            }
        }

        private async Task<(LocalEntity, bool)> AddUserToLocalEntity(BeezyUser currentUser, LocalEntity targetLocalEntity)
        {
            // validate that the current user is NOT already an admin of the target legal entity
            if (!targetLocalEntity.Admins.Any(admin => admin.Id == currentUser.Id))
            {
                // create the request item - only the AdministratorsIds will be updated
                UpdatedLocalEntity updatedLocalEntityForAddedUser = _mapper.Map<LocalEntity, UpdatedLocalEntity>(targetLocalEntity);
                updatedLocalEntityForAddedUser.AdministratorsIds.Add(currentUser.Id);

                // update target local entity
                var localEntityUserAdded = await _beezyDataService.EditLocalEntity(updatedLocalEntityForAddedUser);
                return (localEntityUserAdded, true);
            }
            else
                return (null, false);
        }

        private async Task AddUserAsStoriesAndPagesEditor(BeezyUser currentUser, LocalEntity targetLocalEntity)
        {
            // this does not throw any errors if the user already has a role
            await _beezyDataService.AddStoriesUserRole(targetLocalEntity.EditorialModuleId, currentUser.Id, UserStoriesPagesRole.Editor);
            await _beezyDataService.AddPagesUserRole(targetLocalEntity.CorporateModuleId, currentUser.Id, UserStoriesPagesRole.Editor);
        }
    }
}
