﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DW.Beezy.Admin.Common.Exceptions
{
    public class BeezyDataServiceException : BeezyAdminBaseException
    {
        public BeezyDataServiceException(string function) :
            base(function)
        {
        }

        public BeezyDataServiceException(string function, string functionParams, string reason) :
            base(function, functionParams, reason)
        {
        }

        public BeezyDataServiceException(string function, Exception innerException) :
            base(function, innerException)
        {
        }

        public BeezyDataServiceException(string function, string functionParams, Exception innerException) :
            base(function, functionParams, innerException)
        {
        }
    }
}
