﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DW.Beezy.Admin.Common.Exceptions
{
    public class BeezyServiceException : BeezyAdminBaseException
    {
        public BeezyServiceException(string function) :
            base(function)
        {
        }

        public BeezyServiceException(string function, string functionParams, string reason) :
            base(function, functionParams, reason)
        {
        }

        public BeezyServiceException(string function, Exception innerException) :
            base(function, innerException)
        {
        }

        public BeezyServiceException(string function, string functionParams, Exception innerException) :
            base(function, functionParams, innerException)
        {
        }
    }
}
