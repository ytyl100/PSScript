﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DW.Beezy.Admin.Common.Exceptions
{
    public class BeezyAdminBaseException : Exception
    {
        public string Function { get; set; }

        public string FunctionParams { get; set; }

        public string Reason { get; set; }

        public BeezyAdminBaseException(string function) :
            base($"Error in {function}()")
        {
            Function = function;
            Reason = $"An unexpected error occurred in {function}()";
        }

        public BeezyAdminBaseException(string function, string functionParams, string reason) :
            base($"Error in {function}() with parameters '{functionParams}'. {reason}")
        {
            Function = function;
            FunctionParams = functionParams;
            Reason = reason;
        }

        public BeezyAdminBaseException(string function, Exception innerException) :
            base($"Error in {function}()", innerException)
        {
            Function = function;
            Reason = $"An unexpected error occurred in {function}()";
        }

        public BeezyAdminBaseException(string function, string functionParams, Exception innerException) :
            base($"Error in {function}() with parameters '{functionParams}'", innerException)
        {
            Function = function;
            FunctionParams = functionParams;
            Reason = $"An unexpected error occurred in {function}()";
        }
    }
}
