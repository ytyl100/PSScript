﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DW.Beezy.Admin.Common.Enums
{
    public enum UserStoriesPagesRole
    {
        Writer = 2,
        Editor = 3
    }
}
