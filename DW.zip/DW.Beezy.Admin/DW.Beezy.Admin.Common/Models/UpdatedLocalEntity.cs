﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DW.Beezy.Admin.Common.Models
{
    public class UpdatedLocalEntity
    {
        public int Id { get; set; }

        public string Title { get; set; }

        public List<int> AdministratorsIds { get; set; }

        [JsonProperty("aDGroups")]
        public List<string> AdGroups { get; set; }

        public int DefaultLcid { get; set; }

        public string Branding { get; set; }

        public bool HeroModuleEnabled { get; set; }

        public bool NavigationModuleEnabled { get; set; }

        public bool StoriesModuleEnabled { get; set; }

        public bool PagesModuleEnabled { get; set; }

        public bool AppsModuleEnabled { get; set; }

        public bool DiscoveryCardsModuleEnabled { get; set; }
    }
}
