﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DW.Beezy.Admin.Common.Models
{
    public class UserStoriesPagesRequest
    {
        public int Id { get; set; }

        public int Function { get; set; }
    }
}
