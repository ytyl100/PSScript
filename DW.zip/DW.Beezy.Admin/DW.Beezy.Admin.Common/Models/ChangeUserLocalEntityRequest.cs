﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DW.Beezy.Admin.Common.Models
{
    public class ChangeUserLocalEntityRequest
    {
        public string UserLoginId { get; set; }

        public int? TargetLocalEntityId { get; set; }

        public bool? AllowOperationsOnDefaultLocalEntity { get; set; }
    }
}
