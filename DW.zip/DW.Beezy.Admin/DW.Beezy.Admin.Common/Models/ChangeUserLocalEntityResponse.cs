﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DW.Beezy.Admin.Common.Models
{
    public class ChangeUserLocalEntityResponse
    {
        public int UserId { get; set; }

        public string UserLoginName { get; set; }

        public string UserFullName { get; set; }

        public int? SourceLocalEntityId { get; set; }

        public string SourceLocalEntityTitle { get; set; }

        public int TargetLocalEntityId { get; set; }

        public string TargetLocalEntityTitle { get; set; }
    }
}
