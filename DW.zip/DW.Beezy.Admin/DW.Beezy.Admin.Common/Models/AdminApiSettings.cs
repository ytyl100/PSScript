﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DW.Beezy.Admin.Common.Models
{
    public class AdminApiSettings
    {
        public bool? TestQueriesPermitted { get; set; }

        public bool? AllowOperationsOnDefaultLocalEntity { get; set; }
    }
}
