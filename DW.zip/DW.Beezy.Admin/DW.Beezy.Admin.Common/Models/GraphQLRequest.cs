﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DW.Beezy.Admin.Common.Models
{
    public class GraphQLRequestItem<T> : GraphQLRequestItem
    {
        public T Variables { get; set; }
    }

    public class GraphQLRequestItem
    {
        public string OperationName { get; set; }

        public string Query { get; set; }
    }
}
