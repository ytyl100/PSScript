﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DW.Beezy.Admin.Common.Models
{
    public class LocalEntity
    {
        public bool CanJoin { get; set; }

        public bool CanOverride { get; set; }

        public int Id { get; set; }

        public string Title { get; set; }

        public bool IsDefault { get; set; }

        public List<LocalEntityAdmin> Admins { get; set; }

        public List<string> AdGroups { get; set; }

        public int DefaultLcid { get; set; }

        public string Branding { get; set; }

        public string EditorialModuleId { get; set; }

        public string CorporateModuleId { get; set; }

        public bool HeroModuleEnabled { get; set; }

        public bool NavigationModuleEnabled { get; set; }

        public bool StoriesModuleEnabled { get; set; }

        public bool PagesModuleEnabled { get; set; }

        public bool AppsModuleEnabled { get; set; }

        public bool DiscoveryCardsModuleEnabled { get; set; }
    }

    public class LocalEntityAdmin
    {
        public int Id { get; set; }

        public string FullName { get; set; }

        public string Email { get; set; }
    }
}
