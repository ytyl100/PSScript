﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DW.Beezy.Admin.Common.Logging
{
    // can use a search string of 'DW_BEEZY_ADMIN' to find our custom events (since the event name is written to the EventName field in app insights)
    public static class LoggingEvents
    {
        public static EventId DW_BEEZY_ADMIN_GetUser_Info =>
            new EventId(1000, "DW_BEEZY_ADMIN_GetUser_Info");

        public static EventId DW_BEEZY_ADMIN_GetUser_Error =>
            new EventId(1100, "DW_BEEZY_ADMIN_GetUser_Error");

        public static EventId DW_BEEZY_ADMIN_GetLocalEntities_Info =>
            new EventId(2000, "DW_BEEZY_ADMIN_GetLocalEntities_Info");

        public static EventId DW_BEEZY_ADMIN_GetLocalEntities_Error =>
            new EventId(2100, "DW_BEEZY_ADMIN_GetLocalEntities_Error");

        public static EventId DW_BEEZY_ADMIN_ChangeUserLocalEntity_Info =>
            new EventId(3000, "DW_BEEZY_ADMIN_ChangeUserLocalEntity_Info");

        public static EventId DW_BEEZY_ADMIN_ChangeUserLocalEntity_Error =>
            new EventId(3100, "DW_BEEZY_ADMIN_ChangeUserLocalEntity_Error");

        public static EventId DW_BEEZY_ADMIN_Service_Info =>
            new EventId(10000, "DW_BEEZY_ADMIN_Service_Info");

        public static EventId DW_BEEZY_ADMIN_Service_Warning =>
            new EventId(10100, "DW_BEEZY_ADMIN_Service_Warning");

        public static EventId DW_BEEZY_ADMIN_Service_Error =>
            new EventId(10200, "DW_BEEZY_ADMIN_Service_Error");

        public static EventId DW_BEEZY_ADMIN_DataService_Info =>
            new EventId(20000, "DW_BEEZY_ADMIN_DataService_Info");

        public static EventId DW_BEEZY_ADMIN_DataService_Warning =>
            new EventId(20100, "DW_BEEZY_ADMIN_DataService_Warning");

        public static EventId DW_BEEZY_ADMIN_DataService_Error =>
            new EventId(20200, "DW_BEEZY_ADMIN_DataService_Error");

        public static EventId DW_BEEZY_ADMIN_UserTokenClient_Info =>
            new EventId(30000, "DW_BEEZY_ADMIN_UserTokenClient_Info");
    }
}
