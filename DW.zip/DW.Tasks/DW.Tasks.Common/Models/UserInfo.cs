﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace DW.Tasks.Common.Models
{
    public class UserInfo
    {
        [JsonProperty("userName")]
        public string UserName { get; set; }

        [JsonProperty("email")]
        public string Email { get; set; }
    }
}
