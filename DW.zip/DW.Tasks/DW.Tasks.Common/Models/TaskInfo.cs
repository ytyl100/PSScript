﻿using System;
using DW.Tasks.Common.Enums;
using Newtonsoft.Json;

namespace DW.Tasks.Common.Models
{
    public class TaskInfo
    {
        [JsonProperty("id")]
        public Guid Id { get; set; }

        [JsonProperty("assignedTo")]
        public UserInfo AssignedTo { get; set; }

        [JsonProperty("taskId")]
        public int TaskId { get;  set; }
     
        [JsonProperty("taskNumber")]
        public string TaskNumber { get; set; }

        [JsonProperty("app")]
        public AppInfo App { get; set; }

        [JsonProperty("title")]
        public string Title { get;  set; }

        [JsonProperty("description")]
        public string Description { get; set; }

        [JsonProperty("region")]
        public string Region { get; set; }

        [JsonProperty("status")]
        public TaskStatus Status { get; set; }

        [JsonProperty("dueDate")]
        public DateTime DueDate { get; set; }

        [JsonProperty("created")]
        public DateTime Created { get; set; }

        [JsonProperty("createdBy")]
        public UserInfo CreatedBy { get; set; }

    }
}
