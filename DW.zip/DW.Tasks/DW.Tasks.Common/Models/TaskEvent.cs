﻿using DW.Tasks.Common.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace DW.Tasks.Common.Models
{
    public class TaskEvent
    {
        public Guid Id { get; set; }

        public string Upn { get; set; }

        public TaskEventType EventType { get; set; }
    }
}
