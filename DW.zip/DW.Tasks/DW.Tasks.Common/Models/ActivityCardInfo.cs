﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DW.Tasks.Common.Models
{
    public class ActivityCardInfo
    {
        public Guid Id { get; set; }

        public string ActivityId { get; set; }

        public string Upn { get; set; }
    }
}
