﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace DW.Tasks.Common.Models
{
    public class AppInfo
    {
        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("code")]
        public string Code { get; set; }

        [JsonProperty("taskUrl")]
        public string TaskUrl { get; set; }
    }
}
