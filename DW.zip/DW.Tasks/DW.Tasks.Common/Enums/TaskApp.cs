﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DW.Tasks.Common.Enums
{
    public enum TaskApp
    {
        ITID,
        HR,
        Fusion,
        Clarity
    }
}
