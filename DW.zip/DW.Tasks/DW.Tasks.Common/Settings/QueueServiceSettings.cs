﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DW.Tasks.Common.Settings
{
    public class QueueServiceSettings
    {
        public string QueueConnectionString { get; set; }

        public string QueueName { get; set; }
    }
}
