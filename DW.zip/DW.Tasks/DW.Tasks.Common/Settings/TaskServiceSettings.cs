﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DW.Tasks.Common.Settings
{
    public class TaskServiceSettings
    {
        public TaskServiceSettings()
        {
            return;
        }
        public string CosmosDBConnectionString { get; set; }

        public string CosmosDatabaseId { get; set; }

        public string TasksContainerId { get; set; }

        public string QueueConnectionString { get; set; }

        public string TasksQueueName { get; set; }
    }
}
