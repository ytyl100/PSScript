﻿using DW.Tasks.Business.Services;
using DW.Tasks.Common.Extensions;
using DW.Tasks.Common.Models;
using DW.Tasks.Manager.Console.Utils;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DW.Tasks.Manager.Console
{
    public interface ITaskController
    {
        Task<bool> Run(string name, string email);
        Task<TaskInfo> GetTask(string email, Guid id);

        Task<TaskInfo> UpdateTask(TaskInfo task, Common.Enums.TaskStatus status);

    }
    public class TaskController : ITaskController
    {
        private readonly ITaskService _taskService;
        public TaskController(ITaskService taskService)
        {
            this._taskService = taskService;
        }

        public async Task<TaskInfo> GetTask(string email, Guid id)
        {
            var res = await this._taskService.GetTaskAsync(email, id);
            return res;
        }

        public async Task<bool> Run(string name, string email)
        {
            //var list = await this._taskService.GetTasksAsync(email);

            //list.ForEach(l => System.Console.WriteLine(l.Id));


            var generator = new TaskGenerator(email, name);
            var list = new List<TaskInfo>();

            list.AddRange(generator.CreateTasks(Common.Enums.TaskApp.ITID, 3));
            list.AddRange(generator.CreateTasks(Common.Enums.TaskApp.Clarity, 9));
            //list.AddRange(generator.CreateTasks(Common.Enums.TaskApp.HR, 9));
            //list.AddRange(generator.CreateTasks(Common.Enums.TaskApp.Fusion, 1));

            await Task.Run(async () =>
            {
                await list.ForEachAsync(4, async res =>
                {
                    try
                    {
                        await this._taskService.CreateTaskAsync(res);
                    }
                    catch (Exception exception)
                    {
                        System.Console.WriteLine(exception.Message);
                    }
                });
            });


            return await Task.FromResult<bool>(true);
        }

        public async Task<TaskInfo> UpdateTask(TaskInfo task, Common.Enums.TaskStatus status)
        {
            var res = await _taskService.UpdateTaskStatus(task, Common.Enums.TaskStatus.Closed);
            return res;
        }
    }
}
