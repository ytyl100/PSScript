﻿using DW.Tasks.Bootstrap;
using DW.Tasks.Common.Settings;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace DW.Tasks.Manager.Console
{
    public static class DependencyInjector
    {
        public static IServiceProvider GetServiceProvider()
        {
            ServiceCollection services = new ServiceCollection();

            return services
                .AddLogging()
                .AddTasksManager()
                .AddSingleton<ITaskController, TaskController>()
                .BuildServiceProvider();
        }
    }
}
