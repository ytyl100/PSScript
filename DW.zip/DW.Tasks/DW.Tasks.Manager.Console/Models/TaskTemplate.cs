﻿using DW.Tasks.Common.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace DW.Tasks.Manager.Console.Models
{
    public class TaskTemplate
    {
        public TaskApp App { get; set; }
        public string Title { get; set; }

        public string Description { get; set; }
        public TaskTemplate(TaskApp app, string title, string description)
        {
            App = app;
            Title = title;
            Description = description;
        }
    }
}
