﻿using Microsoft.Extensions.DependencyInjection;
using DW.Tasks.Bootstrap;
using System;
using DW.Tasks.Business.Services;
using System.IO;
using DW.Tasks.Common.Settings;
using System.Threading.Tasks;

namespace DW.Tasks.Manager.Console
{
    class Program
    {
        private static IServiceProvider serviceProvider;

        static async Task Main(string[] args)
        {
            serviceProvider = DependencyInjector.GetServiceProvider();            
            ITaskController taskController = serviceProvider.GetService<ITaskController>();
            //await taskController.Run("Test User 01", "test.user01@dwdev365.onmicrosoft.com");


            //await taskController.Run("Jim Griffiths", "jim.griffiths@dwdev365.onmicrosoft.com");
            var t = await taskController.GetTask("remco.roo@dwdev365.onmicrosoft.com", new Guid("3010249c-ba8b-40f8-94cb-aa3715978640"));
            var t1 = await taskController.UpdateTask(t, Common.Enums.TaskStatus.Closed);
            System.Console.WriteLine(t.Title);

            System.Console.WriteLine("ended...");
                       
        }
    }
}
