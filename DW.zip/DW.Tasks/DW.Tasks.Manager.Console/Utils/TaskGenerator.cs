﻿
using DW.Tasks.Common.Enums;
using DW.Tasks.Common.Models;
using DW.Tasks.Manager.Console.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DW.Tasks.Manager.Console.Utils
{
    public class TaskGenerator
    {
        private List<TaskTemplate> _templates = new List<TaskTemplate>();
        private List<string> _regions = new List<string>() { "Africa", "Asia", "Oceania", "North America", "South America" };
        private List<UserInfo> _users = new List<UserInfo>();
        private UserInfo _currentUser = null;// new UserInfo() { Email = "remco.roo@dwdev365.onmicrosoft.com", UserName = "Remco Roo" };


        public TaskGenerator(string email, string userName)
        {
            this._currentUser = new UserInfo { Email = email, UserName = userName };

            _templates.Add(new TaskTemplate(TaskApp.Clarity, "Clarity Task {0}", "Clarity Task {0} Description"));
            _templates.Add(new TaskTemplate(TaskApp.Fusion, "Fusion Task {0}", "Fusion Task {0} Description"));
            _templates.Add(new TaskTemplate(TaskApp.HR, "HR Task {0}", "HR Task {0} Description"));
            _templates.Add(new TaskTemplate(TaskApp.ITID, "AD - Account Group Membership", "Active Directory - Account Group Membership request"));
            _templates.Add(new TaskTemplate(TaskApp.ITID, "Staff Internet Proxy Request", "Staff Internet Proxy URL ALLOW Request"));
            _templates.Add(new TaskTemplate(TaskApp.ITID, "SYSTRAN - ADLDS Access Request", "SYSTRAN - ADLDS Access Request"));
            _templates.Add(new TaskTemplate(TaskApp.ITID, "NuGet5 installation request", "NuGet5 installation request"));


            _users.Add(new UserInfo() { UserName = "Test User 1", Email = "Test.User1@dwdev365.sharepoint.com" });
            _users.Add(new UserInfo() { UserName = "Test User 2", Email = "Test.User1@dwdev365.sharepoint.com" });
            _users.Add(new UserInfo() { UserName = "Test User 3", Email = "Test.User1@dwdev365.sharepoint.com" });
            _users.Add(new UserInfo() { UserName = "Test User 4", Email = "Test.User1@dwdev365.sharepoint.com" });
            _users.Add(new UserInfo() { UserName = "Test User 5", Email = "Test.User1@dwdev365.sharepoint.com" });
        }

        public List<TaskInfo> CreateTasks(TaskApp app, int numberOfTasks)
        {
            var tasks = new List<TaskInfo>();

            for (int i = 1; i <= numberOfTasks; i++)
            {
                tasks.Add(CreateTask(app, i));
            }
            return tasks;
        }

        private TaskTemplate GetRandomTemplate(TaskApp app, int taskId)
        {
            var templatesForApp = _templates.FindAll(t => t.App == app);
            if (templatesForApp.Count == 0)
            {
                return new TaskTemplate(app, "Missing template title", "Missing template description");
            }
            if (templatesForApp.Count == 1)
            {
                return templatesForApp[0];
            }
            else
            {
                var rnd = new Random();
                var idx = rnd.Next(templatesForApp.Count);
                return templatesForApp[idx];
            }
        }

        private UserInfo GetRandomUser()
        {
            var random = new Random();
            var idx = random.Next(_users.Count);
            return _users[idx];
        }

        private string GetRandomRegion()
        {
            var random = new Random();
            var idx = random.Next(_regions.Count);
            return _regions[idx];
        }

        private DateTime GetRandomDate(int margin)
        {
            var random = new Random();
            var idx = random.Next(margin);
            return DateTime.Now.AddDays(idx);
        }


        private string GetTaskNumber(TaskApp app, int taskId)
        {
            switch (app)
            {
                case TaskApp.Clarity:
                    return String.Format("CL0000{0}", taskId);
                case TaskApp.Fusion:
                    return String.Format("FU0000{0}", taskId);
                case TaskApp.HR:
                    return String.Format("HR0000{0}", taskId);
                case TaskApp.ITID:
                    return String.Format("IT0000{0}", taskId);
                default:
                    return "000000";
            }
        }
        private AppInfo GetAppInfo(TaskApp app)
        {
            var appInfo = new AppInfo();

            switch (app)
            {
                case TaskApp.Clarity:
                    appInfo.Code = "clarity";
                    appInfo.Name = "Clarity";
                    appInfo.TaskUrl = "https://www.bbc.co.uk";
                    break;
                case TaskApp.Fusion:
                    appInfo.Code = "fusion";
                    appInfo.Name = "Fusion";
                    appInfo.TaskUrl = "https://www.bbc.co.uk";
                    break;
                case TaskApp.HR:
                    appInfo.Code = "hr";
                    appInfo.Name = "HR";
                    appInfo.TaskUrl = "https://www.bbc.co.uk";
                    break;
                case TaskApp.ITID:
                    appInfo.Code = "itid";
                    appInfo.Name = "ITID";
                    appInfo.TaskUrl = "https://www.bbc.co.uk";
                    break;
            }
            return appInfo;

        }
        public TaskInfo CreateTask(TaskApp app, int taskId)
        {
            var appInfo = GetAppInfo(app);
            var template = GetRandomTemplate(app, taskId);


            return new TaskInfo()
            {
                Id = Guid.NewGuid(),
                TaskId = taskId,
                TaskNumber = GetTaskNumber(app, taskId),
                Created = DateTime.Now.AddDays(-10),
                CreatedBy = GetRandomUser(),
                Title = String.Format(template.Title, taskId),
                Description = String.Format(template.Description, taskId),
                Region = GetRandomRegion(),
                App = appInfo,
                AssignedTo = _currentUser,
                DueDate = GetRandomDate(30),
                Status = Common.Enums.TaskStatus.Open
            };
        }
    }
}
