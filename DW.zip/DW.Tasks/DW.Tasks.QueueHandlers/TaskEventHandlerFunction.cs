using System;
using System.Linq;
using System.Threading.Tasks;
using DW.Tasks.Business.Services;
using DW.Tasks.Common.Enums;
using DW.Tasks.Common.Models;
using DW.Tasks.DataService.Services;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;

namespace DW.Tasks.QueueHandlers
{
    public class TaskEventHandlerFunction
    {
        private readonly IActivityCardService _activityCardService;

        public TaskEventHandlerFunction(IActivityCardService activityCardService)
        {
            _activityCardService = activityCardService;
        }

        // Azure Cosmos DB input binding
        // see https://docs.microsoft.com/en-us/azure/azure-functions/functions-bindings-cosmosdb-v2-input?tabs=csharp
        [FunctionName("TaskEventHandlerFunction")]
        public async Task Handle(
            [QueueTrigger("%TasksQueueName%"), StorageAccount("AzureWebJobsStorage")] TaskEvent taskEvent,
            [CosmosDB(
                databaseName: "%CosmosDatabaseId%",
                collectionName: "%TasksContainerId%",
                ConnectionStringSetting = "CosmosDBConnectionString",
                Id = "{Id}",
                PartitionKey = "{Upn}")] TaskInfo task,
            ILogger log)
        {
            log.LogInformation($"C# Queue trigger function processed Id={taskEvent?.Id} Key={taskEvent?.Upn}");

            if (task == null)
            {
                log.LogInformation($"Task item not found");
                return;
            }

            log.LogInformation($"Found Task item, Title={task.Title}");

            switch (taskEvent.EventType)
            {
                case TaskEventType.Added:
                    await _activityCardService.CreateActivityCardAsync(task);
                    break;

                case TaskEventType.Updated:
                case TaskEventType.Deleted:
                    await _activityCardService.DeleteActivityCardAsync(task);
                    break;
            }
        }
    }
}
