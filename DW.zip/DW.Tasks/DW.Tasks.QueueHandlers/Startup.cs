﻿using DW.Tasks.Bootstrap;
using DW.Tasks.Business.Services;
using DW.Tasks.DataService.Authentication;
using DW.Tasks.DataService.Services;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

// To register the method, add the FunctionsStartup assembly attribute that specifies the type name used during startup
// Add nuget package Microsoft.Azure.Functions.Extensions
[assembly: FunctionsStartup(typeof(DW.Tasks.QueueHandlers.Startup))]

namespace DW.Tasks.QueueHandlers
{
    public class Startup : FunctionsStartup
    {
        //private IConfigurationRoot configurationSettings;

        public Startup()
        {
            // read configuration values from local settings json & environment variables
            //configurationSettings = new ConfigurationBuilder()
            //    .AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
            //    .AddEnvironmentVariables()
            //    .Build();
        }

        public override void Configure(IFunctionsHostBuilder builder)
        {
            // startup config is now in the bootstrap project
            // see host.json for logging config
            builder.Services.AddTasksQueueHandler();

            // TODO: remove this later when the tasks watcher mock is not required
            builder.Services.AddTasksWatcherMock();
        }
    }
}
