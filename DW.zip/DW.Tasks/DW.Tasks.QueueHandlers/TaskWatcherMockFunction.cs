using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using DW.Tasks.Common.Models;
using DW.Tasks.Business.Services;
using System.Net.Http;
using System.Net;
using System.Text;

namespace DW.Tasks.QueueHandlers
{
    public class TaskWatcherMockFunction
    {
        private readonly ITaskService _taskService;

        public TaskWatcherMockFunction(ITaskService taskService)
        {
            _taskService = taskService;
        }

        // mock insert task into cosmos DB & send event to queue
        [FunctionName("TaskWatcherMockInsertFunction")]
        public async Task<HttpResponseMessage> Insert(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            // deserialize to a TaskInfo item
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            TaskInfo task = JsonConvert.DeserializeObject<TaskInfo>(requestBody);

            // set a guid
            task.Id = Guid.NewGuid();

            try
            {
                var taskCreated = await _taskService.CreateTaskAsync(task);

                var json = JsonConvert.SerializeObject(taskCreated, Formatting.Indented);
                return new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new StringContent(json, Encoding.UTF8, "application/json")
                };
            }
            catch (Exception ex)
            {
                return new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent(ex.ToString(), Encoding.UTF8, "text/plain")
                };
            }
        }

        // mock update task status in cosmos DB & send event to queue
        [FunctionName("TaskWatcherMockUpdateFunction")]
        public async Task<HttpResponseMessage> Update(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            // deserialize to a TaskUpdateIdentifier item
            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            TaskUpdateIdentifier taskIdentifier = JsonConvert.DeserializeObject<TaskUpdateIdentifier>(requestBody);

            try
            {
                var task = await _taskService.GetTaskAsync(taskIdentifier.Upn, taskIdentifier.Id);
                var updatedTask = await _taskService.UpdateTaskStatus(task, Common.Enums.TaskStatus.Closed);

                var json = JsonConvert.SerializeObject(updatedTask, Formatting.Indented);
                return new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new StringContent(json, Encoding.UTF8, "application/json")
                };
            }
            catch (Exception ex)
            {
                return new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent(ex.ToString(), Encoding.UTF8, "text/plain")
                };
            }
        }
    }
}
