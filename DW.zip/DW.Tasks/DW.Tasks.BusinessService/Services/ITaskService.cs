﻿using DW.Tasks.Common.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DW.Tasks.Business.Services
{
    public interface ITaskService
    {
        Task<TaskInfo> UpdateTaskStatus(TaskInfo task, Common.Enums.TaskStatus status);

        Task<List<TaskInfo>> GetTasksAsync(string email);
        Task<TaskInfo> GetTaskAsync(string email, Guid id);

        Task<TaskInfo> CreateTaskAsync(TaskInfo task);
    }
}
