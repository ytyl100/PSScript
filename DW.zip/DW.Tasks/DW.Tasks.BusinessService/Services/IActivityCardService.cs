﻿using DW.Tasks.Common.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DW.Tasks.Business.Services
{
    public interface IActivityCardService
    {
        Task<ActivityCardInfo> CreateActivityCardAsync(TaskInfo task);

        Task DeleteActivityCardAsync(TaskInfo task);
    }
}
