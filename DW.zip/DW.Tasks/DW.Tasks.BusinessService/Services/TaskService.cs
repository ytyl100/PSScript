﻿
using DW.Tasks.Common.Enums;
using DW.Tasks.Common.Models;
using DW.Tasks.DataService.Services;
using DW.Tasks.QueueService.Repositories;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;


namespace DW.Tasks.Business.Services
{
    public class TaskService : ITaskService
    {
        private readonly ILogger<TaskService> _logger;
        private readonly ITaskDataService _dataService;
        private readonly IQueueRepository<TaskEvent> _taskQueueService;

        public TaskService(ITaskDataService dataService, IQueueRepository<TaskEvent> taskQueueService, ILogger<TaskService> logger)
        {
            this._logger = logger;
            this._taskQueueService = taskQueueService;
            this._dataService = dataService;
        }

        public async Task<TaskInfo> CreateTaskAsync(TaskInfo task)
        {
            this._logger.LogWarning("Creating Task for app:{0} and id:{1}", task.App.Code, task.TaskId);
            await _dataService.CreateTaskAsync(task);

            var taskEvent = new TaskEvent { Id = task.Id, Upn = task.AssignedTo.Email, EventType = TaskEventType.Added };
            await _taskQueueService.SendAsync(taskEvent);

            return task;
        }

        public async Task<TaskInfo> GetTaskAsync(string email, Guid id)
        {
            var res = await this._dataService.GetTaskAsync(email, id);
            return res;
            //return await Task.FromResult<TaskInfo>(null);
            //return await Task.FromResult(new TaskGenerator(user).CreateTask(TaskApp.Clarity, taskId));
        }

        public async Task<List<TaskInfo>> GetTasksAsync(string email)
        {
            this._logger.LogWarning("Getting tasks for user: {0}", email);
            var res = await this._dataService.GetTasksAsync(email);
            this._logger.LogWarning("Number Of Tasks: {0} for user : {1}", res.Count, email);
            return res;
        }

        public async Task<TaskInfo> UpdateTaskStatus(TaskInfo task, Common.Enums.TaskStatus status)
        {
            task.Status = status;
            var res = await this._dataService.UpdateTaskAsync(task);

            var taskEvent = new TaskEvent { Id = task.Id, Upn = task.AssignedTo.Email, EventType = TaskEventType.Updated };
            await _taskQueueService.SendAsync(taskEvent);

            return res;
        }
    }
}
