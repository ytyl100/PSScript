﻿using DW.Tasks.Common.Models;
using DW.Tasks.DataService.Services;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DW.Tasks.Business.Services
{
    public class ActivityCardService : IActivityCardService
    {
        private readonly IBeezyCardDataService _beezyCardDataService;
        private readonly IActivityCardDataService _activityCardDataService;
        private readonly ILogger<ActivityCardService> _logger;

        public ActivityCardService(IBeezyCardDataService beezyCardDataService, IActivityCardDataService activityCardDataService, ILogger<ActivityCardService> logger)
        {
            this._logger = logger;
            this._beezyCardDataService = beezyCardDataService;
            this._activityCardDataService = activityCardDataService;
        }

        public async Task<ActivityCardInfo> CreateActivityCardAsync(TaskInfo task)
        {
            //string activityId = await _beezyCardService.CreateActivityCard(user.UserPrincipalName, "ServiceNow", "SERVICE NOW", $"Test activity card created for {user.DisplayName} ({user.EmployeeId})", "", cardLinkUrl);
            string activityId = await _beezyCardDataService.CreateActivityCard(task.AssignedTo.Email, task.App.Code, task.App.Name, task.Title, task.Description, task.App.TaskUrl);
            _logger.LogWarning($"Activity card with ID={activityId} Created for User '{task.AssignedTo.Email}'");

            // add the activity card details to cosmos DB
            var activityCard = new ActivityCardInfo { Id = task.Id, ActivityId = activityId, Upn = task.AssignedTo.Email };
            return await _activityCardDataService.CreateActivityCardAsync(activityCard);
        }

        public async Task DeleteActivityCardAsync(TaskInfo task)
        {
            // lookup the activity id for this task from the ActivityCards container
            //var activityCardsForUser = await _activityCardDataService.GetActivityCardsAsync(task.AssignedTo.Email);
            //var activityCardToDelete = activityCardsForUser.SingleOrDefault(c => c.Id == task.Id);
            var activityCardToDelete = await _activityCardDataService.GetActivityCardAsync(task.AssignedTo.Email, task.Id);

            if (activityCardToDelete != null)
            {
                // delete this activity using the beezy API
                await _beezyCardDataService.DeleteActivity(activityCardToDelete.ActivityId);
                _logger.LogWarning($"Activity card with ID={activityCardToDelete.ActivityId} Deleted for User '{activityCardToDelete.Upn}'");

                // delete the entry from the ActivityCards container
                await _activityCardDataService.DeleteActivityCardAsync(activityCardToDelete);
            }
        }
    }
}
