﻿using DW.Tasks.Common.Models;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace DW.Tasks.DataService.Services
{
    public interface ITaskDataService
    {
        Task<List<TaskInfo>> GetTasksAsync(string email);

        Task<TaskInfo> CreateTaskAsync(TaskInfo task);

        Task<TaskInfo> GetTaskAsync(string email, Guid id);

        Task<TaskInfo> UpdateTaskAsync(TaskInfo task);
    }
}
