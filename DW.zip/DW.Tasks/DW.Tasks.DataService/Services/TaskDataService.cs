﻿
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
using DW.Tasks.Common.Models;
using Microsoft.Azure.Cosmos;
using Microsoft.Azure.Cosmos.Fluent;
using Microsoft.Extensions.Logging;
using DW.Tasks.Common.Settings;
using Microsoft.Azure.Cosmos.Linq;

namespace DW.Tasks.DataService.Services
{
    public class TaskDataService : ITaskDataService
    {
        private CosmosClient _client;
        private Container _container;
        private readonly TaskServiceSettings _settings;
        private readonly ILogger<TaskDataService> _logger;
        
        public TaskDataService(TaskServiceSettings settings, ILogger<TaskDataService> logger)
        {
            this._logger = logger;
            this._settings = settings;
            this._client = new CosmosClientBuilder(_settings.CosmosDBConnectionString).WithSerializerOptions(new CosmosSerializationOptions { PropertyNamingPolicy = CosmosPropertyNamingPolicy.CamelCase }).Build();
            _container = this._client.GetContainer(_settings.CosmosDatabaseId, _settings.TasksContainerId);
        }
        public async Task<List<TaskInfo>> GetTasksAsync(string email)
        {
            this._logger.LogWarning("DS GetTasksAsync");

            var q = _container.GetItemLinqQueryable<TaskInfo>();
            var iterator = q.Where(p => p.AssignedTo.Email == email).ToFeedIterator();
            var res = await iterator.ReadNextAsync();

            return res.ToList();
            //var q = container.GetItemLinqQueryable<Person>();
            //var iterator = q.Where(p => p.Name == "Name").ToFeedIterator();
            //var results = await iterator.ReadNextAsync();

            //var res = _container.GetItemLinqQueryable<TaskInfo>(true).ToList<TaskInfo>();
            //List<TaskInfo> res = _container.GetItemLinqQueryable<TaskInfo>(allowSynchronousQueryExecution: true).Where(p => p.AssignedTo.Email == email).ToList();
            //return await Task.FromResult(res);
        }

        public async Task<TaskInfo> CreateTaskAsync(TaskInfo task)
        {
            this._logger.LogWarning("Creating Cosmos Task for app:{0} and id:{1}", task.App.Code, task.TaskId);
            var res = await this._container.CreateItemAsync(task);
            return res;
        }

        public async Task<TaskInfo> GetTaskAsync(string email, Guid id)
        {
            this._logger.LogInformation("Getting Comsos Task for user: {0} and id {1}", email, id);
            try
            {
                ItemResponse<TaskInfo> response = await this._container.ReadItemAsync<TaskInfo>(id.ToString(), new PartitionKey(email));
                return response.Resource;

            }
            catch (CosmosException ex) when (ex.StatusCode == System.Net.HttpStatusCode.NotFound)
            {
                return null;
            }
        }

        public async Task<TaskInfo> UpdateTaskAsync(TaskInfo task)
        {
            var res = await this._container.UpsertItemAsync<TaskInfo>(task, new PartitionKey(task.AssignedTo.Email));
            return res;            
        }
    }
}
