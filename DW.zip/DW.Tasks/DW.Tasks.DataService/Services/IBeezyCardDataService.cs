﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DW.Tasks.DataService.Services
{
    public interface IBeezyCardDataService
    {
        Task<string> CreateActivityCard(string user, string tag, string title, string message1, string message2, string link);

        Task<string> DeleteActivity(string activityId);
    }
}
