﻿using DW.Tasks.Common.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DW.Tasks.DataService.Services
{
    public interface IActivityCardDataService
    {
        Task<List<ActivityCardInfo>> GetActivityCardsAsync(string upn);

        Task<ActivityCardInfo> GetActivityCardAsync(string upn, Guid id);

        Task<ActivityCardInfo> CreateActivityCardAsync(ActivityCardInfo activityCard);

        Task DeleteActivityCardAsync(ActivityCardInfo activityCard);
    }
}
