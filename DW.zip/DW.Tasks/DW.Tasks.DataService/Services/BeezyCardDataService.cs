﻿using DW.Tasks.DataService.Authentication;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace DW.Tasks.DataService.Services
{
    public class BeezyCardDataServiceSettings
    {
        public string TenantName { get; set; }

        public string BeezyApiSiteName { get; set; }

        public string BeezySharePointSiteName { get; set; }
    }

    public class BeezyCardDataService : BaseHttpDataService, IBeezyCardDataService
    {
        protected BeezyCardDataServiceSettings _settings;
        private readonly ILogger<BeezyCardDataService> _logger;

        protected override string AcceptHeader => "application/json";

        protected override string Scope => $"https://{_settings.TenantName}.sharepoint.com/.default";

        protected override JToken GetJsonRoot(string json) => JToken.Parse(json);

        public BeezyCardDataService(ITokenClient tokenClient, HttpClient httpClient, BeezyCardDataServiceSettings settings, ILogger<BeezyCardDataService> logger) : base(tokenClient, httpClient)
        {
            this._logger = logger;
            _settings = settings;
        }

        public async Task<string> CreateActivityCard(string user, string tag, string title, string message1, string message2, string link)
        {
            string siteCollectionUrl = $"https://{_settings.TenantName}.sharepoint.com/sites/{_settings.BeezySharePointSiteName}";
            string url = $"https://{_settings.BeezyApiSiteName}.azurewebsites.net/BeezyApi.svc/Workflow/ActionCard?SPHostUrl={siteCollectionUrl}&languageId=1033";

            // create template string
            var template = "{\"$schema\":\"http://adaptivecards.io/schemas/adaptive-card.json\",\"type\":\"AdaptiveCard\",\"version\":\"1.0\",\"brandBorderColor\":\"#F29330\",\"body\":[{\"type\":\"Container\",\"items\":[{\"type\":\"ColumnSet\",\"columns\":[{\"type\":\"Column\",\"width\":\"auto\",\"items\":[{\"type\":\"Image\",\"size\":\"small\",\"url\":\"https://public.beezy.net/design/actions/workday.png\"}]},{\"type\":\"Column\",\"width\":\"stretch\",\"verticalContentAlignment\":\"center\",\"items\":[{\"type\":\"TextBlock\",\"text\":\""
                + title + "\",\"weight\":\"bolder\",\"wrap\":true,\"color\":\"accent\",\"size\":\"small\"}]}]}]},{\"type\":\"Container\",\"items\":[{\"type\":\"TextBlock\",\"weight\":\"bolder\",\"text\":\""
                + message1 + "\",\"wrap\":true,\"color\":\"accent\"},{\"type\":\"TextBlock\",\"text\":\""
                + message2 + "\",\"wrap\":true,\"color\":\"accent\"}]}],\"actions\":[{\"type\":\"Action.OpenUrl\",\"title\":\"View\",\"url\":\""
                + link + "\"}]}";

            // encode so that we can include this JSON string within the JSON body
            string encodedTemplate = System.Web.HttpUtility.JavaScriptStringEncode(template);

            // NOTE {{ and }} escaped for interpolated string
            string payload = $"{{\"Template\":\"{encodedTemplate}\", \"Users\": \"{user}\", \"Tags\": \"{tag}\"}}";
            var body = new StringContent(payload, Encoding.UTF8, "application/json");

            var response = await PostAsync(url, body);
            return response;
        }

        public async Task<string> DeleteActivity(string activityId)
        {
            string siteCollectionUrl = $"https://{_settings.TenantName}.sharepoint.com/sites/{_settings.BeezySharePointSiteName}";
            string url = $"https://{_settings.BeezyApiSiteName}.azurewebsites.net/BeezyApi.svc/Activities?SPHostUrl={siteCollectionUrl}&languageId=1033";

            // NOTE: activityId is passed as an integer
            // NOTE {{ and }} escaped for interpolated string
            string payload = $"{{\"Id\":{activityId}}}";
            var body = new StringContent(payload, Encoding.UTF8, "application/json");

            var response = await DeleteAsync(url, body);
            return response;
        }
    }
}
