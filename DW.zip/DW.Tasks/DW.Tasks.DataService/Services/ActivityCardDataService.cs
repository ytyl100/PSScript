﻿using DW.Tasks.Common.Models;
using Microsoft.Azure.Cosmos;
using Microsoft.Azure.Cosmos.Fluent;
using Microsoft.Azure.Cosmos.Linq;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DW.Tasks.DataService.Services
{
    public class ActivityCardDataServiceSettings
    {
        public string CosmosDBConnectionString { get; set; }

        public string CosmosDatabaseId { get; set; }

        public string ActivityCardsContainerId { get; set; }
    }

    public class ActivityCardDataService : IActivityCardDataService
    {
        private CosmosClient _client;
        private Container _container;
        private readonly ActivityCardDataServiceSettings _settings;
        private readonly ILogger<ActivityCardDataService> _logger;

        public ActivityCardDataService(ActivityCardDataServiceSettings settings, ILogger<ActivityCardDataService> logger)
        {
            this._logger = logger;
            this._settings = settings;
            this._client = new CosmosClientBuilder(_settings.CosmosDBConnectionString).WithSerializerOptions(new CosmosSerializationOptions { PropertyNamingPolicy = CosmosPropertyNamingPolicy.CamelCase }).Build();
            _container = this._client.GetContainer(_settings.CosmosDatabaseId, _settings.ActivityCardsContainerId);
        }

        public async Task<List<ActivityCardInfo>> GetActivityCardsAsync(string upn)
        {
            this._logger.LogWarning("GetActivityCardsAsync");

            var q = _container.GetItemLinqQueryable<ActivityCardInfo>();
            var iterator = q.Where(p => p.Upn == upn).ToFeedIterator();
            var res = await iterator.ReadNextAsync();

            return res.ToList();
        }

        public async Task<ActivityCardInfo> GetActivityCardAsync(string upn, Guid id)
        {
            this._logger.LogWarning("GetActivityCardAsync");

            try
            {
                ItemResponse<ActivityCardInfo> response = await this._container.ReadItemAsync<ActivityCardInfo>(id.ToString(), new PartitionKey(upn));
                return response.Resource;

            }
            catch (CosmosException ex) when (ex.StatusCode == System.Net.HttpStatusCode.NotFound)
            {
                return null;
            }
        }

        public async Task<ActivityCardInfo> CreateActivityCardAsync(ActivityCardInfo activityCard)
        {
            this._logger.LogWarning("Creating Cosmos Activity Card for activity id:{0} and id:{1}", activityCard.ActivityId, activityCard.Id);
            var res = await this._container.CreateItemAsync(activityCard);
            return res;
        }

        public async Task DeleteActivityCardAsync(ActivityCardInfo activityCard)
        {
            this._logger.LogWarning("Deleting Cosmos Activity Card for activity id:{0} and id:{1}", activityCard.ActivityId, activityCard.Id);
            var response = await this._container.DeleteItemAsync<ActivityCardInfo>(activityCard.Id.ToString(), new PartitionKey(activityCard.Upn));
        }
    }
}
