﻿using DW.Tasks.Business.Services;
using DW.Tasks.Common.Models;
using DW.Tasks.Common.Settings;
using DW.Tasks.DataService.Authentication;
using DW.Tasks.DataService.Services;
using DW.Tasks.QueueService.Repositories;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace DW.Tasks.Bootstrap
{
    public static class TasksQueueHandlersServiceConfiguration
    {
        public static IServiceCollection AddTasksQueueHandler(this IServiceCollection services)
        {
            // read configuration values from local settings json & environment variables
            var configurationSettings = new ConfigurationBuilder()
                .AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
                .AddEnvironmentVariables()
                .Build();

            // see host.json for logging configuration
            services.AddLogging();
            
            // activity card service - business layer
            services.AddSingleton<IActivityCardService, ActivityCardService>();

            // activity card data service - interaction with cosmos DB
            var activityCardDataServiceSettings = configurationSettings.Get<ActivityCardDataServiceSettings>();
            services.AddSingleton<IActivityCardDataService, ActivityCardDataService>();
            services.AddSingleton(activityCardDataServiceSettings);

            // beezy data service
            // need these definitions otherwise these components will share the same HttpClient (which will not work as they need to request their own access tokens)
            // this call removes the need for a separate AddTransient() call for each of the data access components
            // requires NuGet extension Microsoft.Extensions.Http (version 2) - this is included in Microsoft.Azure.WebJobs.Extensions.DurableTask
            var beezyCardDataServiceSettings = configurationSettings.Get<BeezyCardDataServiceSettings>();
            services.AddHttpClient<IBeezyCardDataService, BeezyCardDataService>();
            services.AddSingleton(beezyCardDataServiceSettings);

            // user access token retrieval
            // the app registration which we are using for the username / password authentication flow required to call the beezy API
            // also contains app registration secret and username / password for the service account
            var userTokenClientSettings = configurationSettings.Get<UserTokenClientSettings>();
            services.AddSingleton<ITokenClient, UserTokenClient>();
            services.AddSingleton(userTokenClientSettings);

            return services;
        }

        public static IServiceCollection AddTasksWatcherMock(this IServiceCollection services)
        {
            // read configuration values from local settings json & environment variables
            var configurationSettings = new ConfigurationBuilder()
                .AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
                .AddEnvironmentVariables()
                .Build();

            var taskSettings = configurationSettings.Get<TaskServiceSettings>();
            services.AddSingleton(taskSettings);

            services.AddSingleton<ITaskDataService, TaskDataService>();
            services.AddSingleton<ITaskService, TaskService>();
            services.AddSingleton<IQueueRepository<TaskEvent>, QueueRepository<TaskEvent>>();

            return services;
        }
    }
}
