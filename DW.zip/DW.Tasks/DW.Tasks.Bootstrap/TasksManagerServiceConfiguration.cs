﻿using DW.Tasks.Business.Services;
using DW.Tasks.Common.Models;
using DW.Tasks.Common.Settings;
using DW.Tasks.DataService.Services;
using DW.Tasks.QueueService.Repositories;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace DW.Tasks.Bootstrap
{
    public static class TasksManagerServiceConfiguration
    {
        public static IServiceCollection AddTasksManager(this IServiceCollection services)
        {
            // read configuration values from local settings json & environment variables
            var configurationSettings = new ConfigurationBuilder()
                .AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
                .AddEnvironmentVariables()
                .Build();

            var taskSettings = configurationSettings.Get<TaskServiceSettings>();
            services.AddSingleton(taskSettings);

            services.AddSingleton<ITaskDataService, TaskDataService>();
            services.AddSingleton<ITaskService, TaskService>();
            services.AddSingleton<IQueueRepository<TaskEvent>, QueueRepository<TaskEvent>>(); 

            return services;
        }
    }
}
