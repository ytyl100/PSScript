﻿using System;
using DW.Tasks.Bootstrap;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;


// To register the method, add the FunctionsStartup assembly attribute that specifies the type name used during startup
// Add nuget package Microsoft.Azure.Functions.Extensions
[assembly: FunctionsStartup(typeof(DW.Tasks.Manager.Startup))]

namespace DW.Tasks.Manager
{
    public class Startup : FunctionsStartup
    {
        //private IConfigurationRoot configurationSettings;

        public Startup()
        {
            //var builder = new ConfigurationBuilder().Build();
            //configurationSettings = new ConfigurationBuilder().Build();
            //TasksManagerServiceConfiguration.AddTasksManager(configurationSettings.)
            //            TasksManagerServiceConfiguration.AddTasksManager(new ConfigurationBuilder().Build())
            //// read configuration values from local settings json & environment variables
            //configurationSettings = new ConfigurationBuilder()
            //    .AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
            //    .AddEnvironmentVariables()
            //    .Build();
        }

        // NOTE: the following settings should be defined in the function app configuration using a key vault reference
        // NOTE: this requires function app authentication to key vault using a system managed identity
        // AppRegistrationClientSecret: @Microsoft.KeyVault(SecretUri=https://kv-beezy-card-manager.vault.azure.net/secrets/AppRegistrationClientSecret/)
        // ServiceAccount: @Microsoft.KeyVault(SecretUri=https://kv-beezy-card-manager.vault.azure.net/secrets/ServiceAccount/)
        // ServiceAccountPassword: @Microsoft.KeyVault(SecretUri=https://kv-beezy-card-manager.vault.azure.net/secrets/ServiceAccountPassword/)
        public override void Configure(IFunctionsHostBuilder builder)
        {
            // startup config is now in the bootstrap project
            // see host.json for logging config
            builder.Services.AddTasksManager();
        }
    }
}
