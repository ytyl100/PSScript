﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace DW.Tasks.Manager.Utils
{
    public static class DWLogger
    {
        public static void Log(ILogger logger, string message)
        {
            logger.LogWarning(message);
        }

        public static void LogHeaders(ILogger log, IHeaderDictionary headers)
        {
            var dict = headers.ToDictionary(header => header.Key, header => new[] { header.Value }, StringComparer.OrdinalIgnoreCase);
            foreach(var dic in dict)
            {
                log.LogWarning(dic.Key);
                foreach(var val in dic.Value)
                {
                    log.LogWarning(val.ToString());
                }
            }
            return;
        }
    }
}
