using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using DW.Tasks.Manager.Utils;
using System.Collections.Generic;
using DW.Tasks.Business.Services;

namespace DW.Tasks.Manager
{
    public class GetTasks
    {
        private readonly ITaskService _taskService;
        private readonly ILogger<GetTasks> _logger;

        public GetTasks(ITaskService taskService, ILogger<GetTasks> logger)
        {
            _logger = logger;
            _taskService = taskService;
        }

        [FunctionName("GetTasks")]
        public async Task<HttpResponseMessage> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] HttpRequest req)
        {
            _logger.LogInformation("GetTasks HTTP trigger function processed a request.");

            string authHeader = req.Headers["Authorization"];
            if (String.IsNullOrEmpty(authHeader))
            {
                authHeader = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Im5PbzNaRHJPRFhFSzFqS1doWHNsSFJfS1hFZyIsImtpZCI6Im5PbzNaRHJPRFhFSzFqS1doWHNsSFJfS1hFZyJ9.eyJhdWQiOiJodHRwczovL2Z1bmMtc3lzdGVtLXRhc2stbWFuYWdlci5henVyZXdlYnNpdGVzLm5ldCIsImlzcyI6Imh0dHBzOi8vc3RzLndpbmRvd3MubmV0LzYwZjAwNDhlLTEzYTctNGM0MC04ZjQ0LTcxNDRhMDA3NGNjZS8iLCJpYXQiOjE2Mjk3OTc0MzQsIm5iZiI6MTYyOTc5NzQzNCwiZXhwIjoxNjI5ODAxMzM0LCJhY3IiOiIxIiwiYWlvIjoiQVRRQXkvOFRBQUFBOHJ1RHZKaUQvQTF1a0srekhPVUtrMUF6Vm9RMTBPaExZaTVvSnRXN1dOTGVyS0NnWHhQZGlnNmlWdEVGeVo3KyIsImFtciI6WyJwd2QiXSwiYXBwaWQiOiI3NGE4NzA0ZS1mNWU2LTQwMDItYWI3MS05MDlhMTI0Yjk0MGMiLCJhcHBpZGFjciI6IjAiLCJmYW1pbHlfbmFtZSI6IlJvbyIsImdpdmVuX25hbWUiOiJSZW1jbyIsImlwYWRkciI6Ijg2LjE4NS4xNDAuMTUzIiwibmFtZSI6IlJlbWNvIFJvbyIsIm9pZCI6IjM3YzE1NDc2LWMxZjAtNDY0MS05M2E3LTZhY2MyZWRhZGIzMCIsInJoIjoiMC5BUzhBamdUd1lLY1RRRXlQUkhGRW9BZE16azV3cUhUbTlRSkFxM0dRbWhKTGxBd3ZBUGsuIiwic2NwIjoidXNlcl9pbXBlcnNvbmF0aW9uIiwic3ViIjoiR2tLZ25QLURvWG1hdVRWWjBEQzQ5ak4yZzdoa1FVZzIteDhSVWFJQjZKUSIsInRpZCI6IjYwZjAwNDhlLTEzYTctNGM0MC04ZjQ0LTcxNDRhMDA3NGNjZSIsInVuaXF1ZV9uYW1lIjoicmVtY28ucm9vQGR3ZGV2MzY1Lm9ubWljcm9zb2Z0LmNvbSIsInVwbiI6InJlbWNvLnJvb0Bkd2RldjM2NS5vbm1pY3Jvc29mdC5jb20iLCJ1dGkiOiJnYXo0WGZvQmgwT2N0SEdvMVpKN0FBIiwidmVyIjoiMS4wIn0.QE0uLd8IS3OPe2_TdyZtN-C2CaHRjHNb-kEto-vdWJdHP6nHWzvVi_WorYEEYluhy5rAHS0S-oG8GVh_eDXJrGVJ8Be8kvlfu8h_yLxAJw4TaSlKOvUgSMW0o57GFmbkbrpMIZeKyScQjIwXSNLwtetWlIOxQj5R58KEeMm5OICER8Bj9TCc90JIR1DUKEEPTJhqD8plFJRv1ZAbu0eXqFF4TtdBwhGgsNxSKsi-ElCn6G5py4D5a6LfeaBQH7ztafG8uAnstGgrazN0Tn3i7nsTvyKEmqY12hafHP6mtrBghdNawbayAu4N67Ug5VVtkT7MFIP-SGS91bp8ZLVSog";
            }

            string user = string.Empty;

            if (req.Headers.ContainsKey("X-MS-CLIENT-PRINCIPAL-NAME"))
            {
                var sv = req.Headers["X-MS-CLIENT-PRINCIPAL-NAME"];
                if(sv.Count == 1)
                {
                    user = sv[0];
                }
            }

            if (String.IsNullOrEmpty(user))
            {
                user = "test.abc@dwdev.onmicrosoft.com";
            }

            try
            {
                DWLogger.Log(_logger, authHeader);


                DWLogger.LogHeaders(_logger, req.Headers);

                var tasks = await _taskService.GetTasksAsync(user);
                
                var json = JsonConvert.SerializeObject(tasks, Formatting.Indented);

                return new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new StringContent(json, Encoding.UTF8, "application/json")
                };
            }
            catch (Exception exception)
            {
                _logger.LogCritical(exception, "TODO");
                return new HttpResponseMessage(HttpStatusCode.InternalServerError);
            }
        }
    }
}
