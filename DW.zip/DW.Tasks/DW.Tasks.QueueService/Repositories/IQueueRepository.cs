﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DW.Tasks.QueueService.Repositories
{
    public interface IQueueRepository<T>
    {
        Task<bool> SendAsync(T item);
    }
}
