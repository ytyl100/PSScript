﻿using Azure.Storage.Queues;
using DW.Tasks.Common.Settings;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DW.Tasks.QueueService.Repositories
{
    public class QueueRepository<T> : IQueueRepository<T>
    {
        private readonly QueueClient _client;
        private readonly ILogger<QueueRepository<T>> _logger;
        private readonly TaskServiceSettings _settings;

        public QueueRepository(ILogger<QueueRepository<T>> logger, TaskServiceSettings settings)
        {
            this._logger = logger;
            this._settings = settings;
            this._client = new QueueClient(_settings.QueueConnectionString, _settings.TasksQueueName);
        }

        public async Task<bool> SendAsync(T item)
        {            
            string itemToJson = Base64Encode(JsonConvert.SerializeObject(item));
            _logger.LogWarning("Item to json {0}", itemToJson);

            var result = await _client.SendMessageAsync(itemToJson);
            _logger.LogWarning("Send Message to Queue Result Message Id: {0}", result.Value.MessageId);
            return true;
        }

        private static string Base64Encode(string plainText)
        {
            var plainTextBytes = Encoding.UTF8.GetBytes(plainText);
            return Convert.ToBase64String(plainTextBytes);
        }
    }
}
