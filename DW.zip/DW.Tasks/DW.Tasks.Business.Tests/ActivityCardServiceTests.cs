﻿using Xunit;
using Microsoft.Extensions.DependencyInjection;
using System.Threading.Tasks;
using DW.Tasks.Business.Services;
using DW.Tasks.DataService.Services;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;
using DW.Tasks.Common.Models;

namespace DW.Tasks.Business.Tests
{
    public class ActivityCardServiceTests
    {
        private readonly Mock<IActivityCardDataService> activityCardDataServiceMock;
        private readonly Mock<IBeezyCardDataService> beezyCardDataServiceMock;

        IServiceProvider serviceProvider;
        IActivityCardService activityCardService;

        public ActivityCardServiceTests()
        {
            activityCardDataServiceMock = new Mock<IActivityCardDataService>();

            beezyCardDataServiceMock = new Mock<IBeezyCardDataService>();

            serviceProvider = DependencyInjector.GetActivityCardServiceProvider(activityCardDataServiceMock.Object, beezyCardDataServiceMock.Object);
            activityCardService = serviceProvider.GetService<IActivityCardService>();
        }

        [Fact]
        public async Task CreateActivityCardAsync()
        {
            // mock CreateActivityCard() in the beezy card data service to return a specific activity ID
            string beezyActivityId = "12345";
            beezyCardDataServiceMock.Setup(mock => mock.CreateActivityCard(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
                .ReturnsAsync(beezyActivityId);

            var taskInfo = TestDataGenerator.GetTaskInfo_StatusOpen();
            var activtyCardInfo = await activityCardService.CreateActivityCardAsync(taskInfo);

            beezyCardDataServiceMock.Verify(x => x.CreateActivityCard(
                taskInfo.AssignedTo.Email,
                taskInfo.App.Code,
                taskInfo.App.Name,
                taskInfo.Title,
                taskInfo.Description,
                taskInfo.App.TaskUrl),
                Times.Once,
                "CreateActivityCard() must be called once in beezy card data service");

            activityCardDataServiceMock.Verify(x => x.CreateActivityCardAsync(It.Is<ActivityCardInfo>(activityCardInfo =>
                activityCardInfo.Id == taskInfo.Id &&
                activityCardInfo.Upn == taskInfo.AssignedTo.Email &&
                activityCardInfo.ActivityId == beezyActivityId
            )),
            Times.Once,
            "CreateActivityCardAsync() must be called once in activity card data service. It must pass the Activity ID returned by the previous call to CreateActivityCard() in beezy card data service");
        }

        [Fact]
        public async Task DeleteActivityCardAsync()
        {
            // mock GetActivityCardAsync() in the activity card data service to return an activity card with a specific activity ID
            string beezyActivityId = "12345";
            activityCardDataServiceMock.Setup(mock => mock.GetActivityCardAsync(It.IsAny<string>(), It.IsAny<Guid>()))
                .ReturnsAsync(new ActivityCardInfo { ActivityId = beezyActivityId });

            var taskInfo = TestDataGenerator.GetTaskInfo_StatusOpen();
            await activityCardService.DeleteActivityCardAsync(taskInfo);

            beezyCardDataServiceMock.Verify(x => x.DeleteActivity(beezyActivityId),
                Times.Once,
                "DeleteActivity() must be called once in beezy card data service. It must pass the Activity ID returned by the call to GetActivityCardAsync() in activity card data service");

            activityCardDataServiceMock.Verify(x => x.DeleteActivityCardAsync(It.Is<ActivityCardInfo>(ac => ac.ActivityId == beezyActivityId)),
                Times.Once,
                "DeleteActivityCardAsync() must be called once in activity card data service. It must pass the Activity ID returned by the call to GetActivityCardAsync() in activity card data service");
        }

        [Fact]
        public async Task DeleteActivityCardAsync_ActivityCardNotFound()
        {
            // mock GetActivityCardAsync() in the activity card data service to return a null activity card
            activityCardDataServiceMock.Setup(mock => mock.GetActivityCardAsync(It.IsAny<string>(), It.IsAny<Guid>()))
                .ReturnsAsync((ActivityCardInfo)null);

            var taskInfo = TestDataGenerator.GetTaskInfo_StatusOpen();
            await activityCardService.DeleteActivityCardAsync(taskInfo);

            beezyCardDataServiceMock.Verify(x => x.DeleteActivity(It.IsAny<string>()),
                Times.Never,
                "DeleteActivity() must NOT be called in beezy card data service");

            activityCardDataServiceMock.Verify(x => x.DeleteActivityCardAsync(It.IsAny<ActivityCardInfo>()),
                Times.Never,
                "DeleteActivityCardAsync() must NOT be called in activity card data service");
        }
    }
}
