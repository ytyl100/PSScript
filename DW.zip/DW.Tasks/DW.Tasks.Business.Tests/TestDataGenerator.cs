﻿using DW.Tasks.Common.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DW.Tasks.Business.Tests
{
    public class TestDataGenerator
    {
        public static Guid TaskInfo_TaskId = Guid.NewGuid();
        public static string TaskInfo_Title = "Task Title";
        public static string TaskInfo_Description = "Task Description";
        public static string TaskInfo_App_Code = "snow";
        public static string TaskInfo_App_Name = "Service Now";
        public static string TaskInfo_App_TaskUrl = "http://servicenow";
        public static string TaskInfo_AssignedTo_Email = "jim.griffiths@dwdev365.onmicrosoft.com";

        public static TaskInfo GetTaskInfo_StatusOpen(Guid taskId = default(Guid), string taskTitle = null, string taskDescription = null, string appCode = null, string appName = null, string appTaskUrl = null, string assignedToEmail = null)
        {
            return new TaskInfo
            {
                Id = (taskId != Guid.Empty) ? taskId : TaskInfo_TaskId,
                Title = taskTitle ?? TaskInfo_Title,
                Description = taskDescription ?? TaskInfo_Description,
                App = new AppInfo
                {
                    Code = appCode ?? TaskInfo_App_Code,
                    Name = appName ?? TaskInfo_App_Name,
                    TaskUrl = appTaskUrl ?? TaskInfo_App_TaskUrl
                },
                AssignedTo = new UserInfo
                {
                    Email = assignedToEmail ?? TaskInfo_AssignedTo_Email
                },
                Status = Common.Enums.TaskStatus.Open
            };
        }
    }
}
