﻿using System;
using System.Collections.Generic;
using System.Text;
using Xunit;
using Microsoft.Extensions.DependencyInjection;
using System.Threading.Tasks;
using Moq;
using DW.Tasks.Business.Services;
using DW.Tasks.DataService.Services;
using DW.Tasks.QueueService.Repositories;
using DW.Tasks.Common.Models;
using DW.Tasks.Common.Enums;

namespace DW.Tasks.Business.Tests
{
    public class TaskServiceTests
    {
        private readonly Mock<ITaskDataService> taskDataServiceMock;
        private readonly Mock<IQueueRepository<TaskEvent>> queueRepositoryMock;

        IServiceProvider serviceProvider;
        ITaskService taskService;

        public TaskServiceTests()
        {
            taskDataServiceMock = new Mock<ITaskDataService>();
            taskDataServiceMock.Setup(mock => mock.GetTasksAsync(It.IsAny<string>())).ReturnsAsync(new List<TaskInfo>());
            taskDataServiceMock.Setup(mock => mock.UpdateTaskAsync(It.IsAny<TaskInfo>())).ReturnsAsync(new TaskInfo());

            queueRepositoryMock = new Mock<IQueueRepository<TaskEvent>>();

            serviceProvider = DependencyInjector.GetTaskServiceProvider(taskDataServiceMock.Object, queueRepositoryMock.Object);
            taskService = serviceProvider.GetService<ITaskService>();
        }

        [Fact]
        public async Task GetTasksAsync()
        {
            var tasks = await taskService.GetTasksAsync(TestDataGenerator.TaskInfo_AssignedTo_Email);

            taskDataServiceMock.Verify(x => x.GetTasksAsync(TestDataGenerator.TaskInfo_AssignedTo_Email),
                Times.Once,
                "GetTasksAsync() must be called once in the task data service");

            queueRepositoryMock.Verify(x => x.SendAsync(It.IsAny<TaskEvent>()),
                Times.Never,
                "SendAsync() must NOT be called in the queue repository");
        }

        [Fact]
        public async Task CreateTaskAsync()
        {
            var taskInfo = TestDataGenerator.GetTaskInfo_StatusOpen();
            var tasks = await taskService.CreateTaskAsync(taskInfo);

            taskDataServiceMock.Verify(x => x.CreateTaskAsync(taskInfo),
                Times.Once,
                "CreateTaskAsync() must be called once in the task data service");

            queueRepositoryMock.Verify(x => x.SendAsync(It.Is<TaskEvent>(taskEvent =>
                taskEvent.Id == taskInfo.Id &&
                taskEvent.Upn == taskInfo.AssignedTo.Email &&
                taskEvent.EventType == TaskEventType.Added)),
                Times.Once,
                "SendAsync() must be called once in the queue repository with the Task Event Type set to Added");
        }

        [Theory]
        [InlineData(Common.Enums.TaskStatus.Approved)]
        [InlineData(Common.Enums.TaskStatus.Rejected)]
        public async Task UpdateTaskAsync(Common.Enums.TaskStatus taskStatus)
        {
            var taskInfo = TestDataGenerator.GetTaskInfo_StatusOpen();
            var tasks = await taskService.UpdateTaskStatus(taskInfo, taskStatus);

            taskDataServiceMock.Verify(x => x.UpdateTaskAsync(It.Is<TaskInfo>(taskInfo =>
                taskInfo.Status == taskStatus)),
                Times.Once,
                "UpdateTaskAsync() must be called once in the task data service");

            queueRepositoryMock.Verify(x => x.SendAsync(It.Is<TaskEvent>(taskEvent =>
                taskEvent.Id == taskInfo.Id &&
                taskEvent.Upn == taskInfo.AssignedTo.Email &&
                taskEvent.EventType == TaskEventType.Updated)),
                Times.Once,
                "SendAsync() must be called once in the queue repository with the Task Event Type set to Updated");
        }
    }
}
