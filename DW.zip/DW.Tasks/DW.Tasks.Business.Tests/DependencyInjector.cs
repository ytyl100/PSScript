﻿using DW.Tasks.Bootstrap;
using DW.Tasks.Business.Services;
using DW.Tasks.Common.Models;
using DW.Tasks.Common.Settings;
using DW.Tasks.DataService.Services;
using DW.Tasks.QueueService.Repositories;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace DW.Tasks.Business.Tests
{
    public static class DependencyInjector
    {
        public static IServiceProvider GetServiceProvider()
        {
            ServiceCollection services = new ServiceCollection();

            return services
                .AddLogging()
                .AddTasksManager()
                .BuildServiceProvider();
        }

        public static IServiceProvider GetTaskServiceProvider(ITaskDataService mockTaskDataService, IQueueRepository<TaskEvent> mockQueueRepository)
        {
            ServiceCollection services = new ServiceCollection();

            // read configuration values from local settings json & environment variables
            var configurationSettings = new ConfigurationBuilder()
                .AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
                .AddEnvironmentVariables()
                .Build();

            var taskSettings = configurationSettings.Get<TaskServiceSettings>();
            services.AddSingleton(taskSettings);

            services.AddSingleton<ITaskService, TaskService>();
            services.AddSingleton(mockTaskDataService);
            services.AddSingleton(mockQueueRepository);

            return services
                .AddLogging()
                .BuildServiceProvider();
        }

        public static IServiceProvider GetActivityCardServiceProvider(IActivityCardDataService mockActivityCardDataServiceMock, IBeezyCardDataService mockBeezyCardDataServiceMock)
        {
            ServiceCollection services = new ServiceCollection();

            // read configuration values from local settings json & environment variables
            var configurationSettings = new ConfigurationBuilder()
                .AddJsonFile("local.settings.json", optional: true, reloadOnChange: true)
                .AddEnvironmentVariables()
                .Build();

            var taskSettings = configurationSettings.Get<TaskServiceSettings>();
            services.AddSingleton(taskSettings);

            services.AddSingleton<IActivityCardService, ActivityCardService>();
            services.AddSingleton(mockActivityCardDataServiceMock);
            services.AddSingleton(mockBeezyCardDataServiceMock);

            return services
                .AddLogging()
                .BuildServiceProvider();
        }
    }
}
