declare interface IDashboardApplicationCustomizerStrings {
  Title: string;
}

declare module 'DashboardApplicationCustomizerStrings' {
  const strings: IDashboardApplicationCustomizerStrings;
  export = strings;
}
