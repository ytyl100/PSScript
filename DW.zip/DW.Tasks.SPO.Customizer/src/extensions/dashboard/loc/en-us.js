define([], function() {
  return {
    "Title": "DashboardApplicationCustomizer"
  }
});