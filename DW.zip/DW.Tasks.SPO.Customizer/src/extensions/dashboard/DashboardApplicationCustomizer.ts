import { override } from '@microsoft/decorators';
import { Log } from '@microsoft/sp-core-library';
import {
  BaseApplicationCustomizer
} from '@microsoft/sp-application-base';
import { Dialog } from '@microsoft/sp-dialog';

import * as strings from 'DashboardApplicationCustomizerStrings';

const LOG_SOURCE: string = 'DashboardApplicationCustomizer';

/**
 * If your command set uses the ClientSideComponentProperties JSON input,
 * it will be deserialized into the BaseExtension.properties object.
 * You can define an interface to describe it.
 */
export interface IDashboardApplicationCustomizerProperties {
  cssfile: string;
  pages: string[];
}

/** A Custom Action which can be run during execution of a Client Side Application */
export default class DashboardApplicationCustomizer
  extends BaseApplicationCustomizer<IDashboardApplicationCustomizerProperties> {

  @override
  public onInit(): Promise<void> {
    Log.info(LOG_SOURCE, `Initialized ${strings.Title}`);

    // let message: string = this.properties.cssfile;
    // if (!message) {
    //   message = '(No properties were provided.)';
    // }

    // Dialog.alert(`Hello from ${strings.Title}:\n\n${message}`);

    console.warn('properties....:', this.properties, this);
    const pagePathToLowerCase: string = (window.location.origin + window.location.pathname).toLowerCase();

    if (this.properties.cssfile == null || this.properties.cssfile == '' || this.properties.pages == null || this.properties.pages.length === 0) {
      console.warn('Properties empty or not found: ', this.properties);
      return Promise.resolve();
    }

    const cssFile: string = `${this.context.pageContext.site.absoluteUrl}${this.properties.cssfile}`;
    const pagesToLowerCase: string[] = this.properties.pages.map((page: string) => `${this.context.pageContext.site.absoluteUrl}${page}`.toLowerCase());

    // check if page needs to have css injected
    if (pagesToLowerCase.indexOf(pagePathToLowerCase) === -1) {
      return Promise.resolve();
    }

    // check if extension should be disabled for this page request  
    const searchParams: URLSearchParams = new URLSearchParams(window.location.search);

    if (searchParams.has('disableDWExtension')) {
      console.warn('Extension disabled');
      return Promise.resolve();
    }

    // inject the style sheet
    const head: any = document.getElementsByTagName("head")[0] || document.documentElement;
    let customStyle: HTMLLinkElement = document.createElement("link");
    customStyle.href = cssFile;
    customStyle.rel = "stylesheet";
    customStyle.type = "text/css";
    head.insertAdjacentElement("beforeEnd", customStyle);

    return Promise.resolve();
  }
}
